<?php

interface Deliverable
{
    function caseCount();
    function totalWeight();
}
?>
