<?php
  print "Now carry out the actions...";
?>
