<!DOCTYPE HTML PUBLIC
                 "-//W3C//DTD HTML 4.01 Transitional//EN"
                 "http://www.w3.org/TR/html401/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>Explore Wines</title>
</head>
<body bgcolor="#ffffff">
Explore all our 
<a href="example.6-13.php?regionName=All&amp;wineType=All"> wines</a>
<br>Explore our 
<a href="example.6-13.php?regionName=All&amp;wineType=Red"> red wines</a>
<br>Explore our 
<a href="example.6-13.php?regionName=Riverland&amp;wineType=Red"> premium
 reds from the Riverland</a>
<br>
<a href="index.html">Home</a></body>
</html>
