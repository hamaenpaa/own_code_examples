<!DOCTYPE HTML PUBLIC
                 "-//W3C//DTD HTML 4.01 Transitional//EN"
                 "http://www.w3.org/TR/html401/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>Explore Wines in a Region</title>
</head>
<body bgcolor="white">
  <form action="example.6-11.php" method="GET">
    <br>Enter a region to browse :
    <input type="text" name="regionName" value="All"> 
      (type All to see all regions)
    <br><input type="submit" value="Show wines">
  </form>
  <br><a href="index.html">Home</a>
</body>
</html>
