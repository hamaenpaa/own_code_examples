<!DOCTYPE HTML PUBLIC
                 "-//W3C//DTD HTML 4.01 Transitional//EN"
                 "http://www.w3.org/TR/html401/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>One Component Test Page</title>
</head>
<body>
<br><a href="example.6-15.php?input=item1">Add Item 1</a>
<br><a href="example.6-15.php?input=item2">Add Item 2</a>
<br><a href="example.6-15.php?input=item3">Add Item 3</a>
<br><a href="example.6-15.php?input=item4">Add Item 4</a>
<br><a href="example.6-15.php?input=item5">Add Item 5</a>
</body>
</html>
