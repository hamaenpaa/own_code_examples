// OutputDebugRemover.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{
	FILE *fr,*fw;
	fr = fopen(argv[1],"r");
	fw = fopen(argv[2],"w");
	char seekedBegin[200];
	strcpy(seekedBegin, "#ifdef ");
	strcat(seekedBegin, argv[3]);
	int lenSeekedBegin = strlen(seekedBegin);
	char sline[400];
	bool bInsideRemoveSection = false;
	while (fgets(sline, 399, fr) != NULL)
	{
		if (bInsideRemoveSection)
		{
			if (strncmp(sline, "#endif", 6) == 0)
			{
				bInsideRemoveSection = false;
			}
		}
		else
		{
			if (strncmp(sline, seekedBegin, lenSeekedBegin) == 0)
			{
				bInsideRemoveSection = true;				
			}
			else
			{
				fprintf(fw, "%s", sline);		   
			}
		}
	}
	fclose(fr);
    fclose(fw);
	return 0;
}
