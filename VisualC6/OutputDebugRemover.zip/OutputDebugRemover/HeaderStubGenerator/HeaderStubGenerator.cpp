// HeaderStubGenerator.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>

bool isSpaceBegin(CString& strLine, int indexToWhich)
{
	printf("isSpaceBegin, strLine: %s, indexToWhich: %d\n", strLine.GetBuffer(0),
		indexToWhich);
	bool bSpaceBegin = true;
	for(int index=0; index < indexToWhich; ++index)
	{
		char c = strLine.GetAt(index);
		printf("c: %d ", c);
		if (c > 32)
		{
			printf("bSpaceBegin = false\n", c);
			bSpaceBegin = false;
			break;
		}
	}
	printf("\n");
	return bSpaceBegin;
}

#define MINIMUMACCEPTEDROWLENGTH 1

int main(int argc, char* argv[])
{
	FILE *fr,*fw;
	fr = fopen(argv[1],"r");
	fw = fopen(argv[2],"w");
	char sline[400];
	bool bInsideRemoveSection = false;
	while (fgets(sline, 399, fr) != NULL)
	{
		CString strLine = sline;
		if (bInsideRemoveSection)
		{
			if (strLine.Find("*/", 0) != -1)
			{
				bInsideRemoveSection = false;
			}
		}
		else
		{
			int sectionSeparator = strLine.Find("/*", 0);
			int lineCommentSeparator = strLine.Find("//", 0);
			if (sectionSeparator != -1)
			{
				if ((sectionSeparator < lineCommentSeparator) || 
					(lineCommentSeparator == -1))
				{
					bool bSpaceBegin = isSpaceBegin(strLine, sectionSeparator);
					if (bSpaceBegin)
					{
						bInsideRemoveSection = true;				
					}
					else
					{
						int len = strLine.GetLength();
						if (len > MINIMUMACCEPTEDROWLENGTH)
						{
							fprintf(fw, "%s", sline);
						}
					}
				}
			}
			else
			{
				int lineCommentSeparator = strLine.Find("//", 0);
				if (lineCommentSeparator != -1)
				{
					bool bSpaceBegin = isSpaceBegin(strLine, lineCommentSeparator);
					if (!bSpaceBegin)
					{
						fprintf(fw, "%s", sline);
					}
				}
				else
				{
					int len = strLine.GetLength();
					if (len > MINIMUMACCEPTEDROWLENGTH)
					{
						fprintf(fw, "%s", sline);
					}
				}
			}
		}
	}
	fclose(fr);
    fclose(fw);
	return 0;
}
