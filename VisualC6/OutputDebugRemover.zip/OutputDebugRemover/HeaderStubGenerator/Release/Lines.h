#ifndef CLINES_H 
#define CLINES_H 1

#include "Line.h"
#include "Helper.h"
#include "GeneralStatus.h"
#include "PhoneNumberList.h"
#include "IndexList.h"

#include "Output.h"

/***********************************************
*                                              *
* xxxxxxxxxxx                                  *
*                                              *
* xxxxxxxxxxx                                  *
*                                              *
***********************************************/
class CLines
{
private:
	//
	COutput* m_pOutput;

#ifdef TESTFILES
	// row counter for test file rows.
	long m_lReadCounter;

	// buffer used to put text into test file.
	CString m_fileBuffer;

	/*
	Adds message to test file buffer and if bFinal is true
	adds the rest immediately to test file.

	@param message
	@param bFinal
	*/
	void addTestMessage(CString message, bool bFinal=false);
#endif
	// Pointer to the helper class used for parsing strings.
	CHelper* m_pHelper;

	// Pointer to the general status class used for example for
	// getting current time etc.
	CGeneralStatus* m_pStatus;

	// Pointer to the phonenumbers list for finding the names
	// of the calls coming to phonelines.
	CPhoneNumberList* m_phoneNumbers;

	// FastChooses based on which names are seeked for phonenumbers
	// on phone lines.
	CFastChooses* m_pFastChooses;

	// Array of the CLine phoneline objects
	CObArray m_lines;

	/*
	Gets list of hold lines and checks if some of them contain
	given callRef. Hold line with same callref is set to current.
	This method is only used as latest step in checkTalking
	method. Returns index of the hold line that is set to current
	or -1, if nothing is done.

	@param callRef
	@param terminal
	@return
	*/
	int checkIfTalkingMeansHoldOff(CString callRef, CString terminal);
public:
#ifdef TESTFILES
	/*
	Debug method for getting info about all phonelines for example
	for test files.
	*/
	void checkLines();
#endif
	/*
	Initializes members from given pointers and creates 2 CLine
	objects.

	@param pHelper
	@param pStatus
	@param phoneNumbers
	@param pFastChooses
	@param pOutput
	*/
	CLines(CHelper* pHelper, CGeneralStatus* pStatus, 
		CPhoneNumberList* phoneNumbers, CFastChooses* pFastChooses,
		COutput* pOutput);

	/*
	Deletes 2 CLine objects contained.
	*/
	~CLines();

	/*
	Calls clear method for each of CLine objects contained.
	*/
	void clearAllLines();

	/*
	Gets list of not free lines and return TRUE if there was some.

	@param indexlist
	@param bNotHold
	@return
	*/
	BOOL GetUsedLines(CIndexList& indexlist, bool bNotHold=false);

	/*
	Gets list of free lines and return TRUE if there was some.

	@param indexlist
	@return
	*/
	BOOL getFreeLines(CIndexList& indexList);

	/*
	Gets list of lines with held call and return TRUE if there was some.

	@param list
	@return
	*/
	BOOL getHeldLines(CIndexList& list);

	/*
	Gets list of lines with hold call and return TRUE if there was some.

	@param indexlist
	@return
	*/
	BOOL getHoldLines(CIndexList& indexList);

	/*
	Gets list of lines with coming call and return TRUE if there was some.

	@param indexlist
	@return
	*/
	BOOL getComingLines(CIndexList& indexList);

	/*
	Gets list of lines with calls that are stoppable.

	@param indexlist
	*/
	void getStoppableLines(CIndexList& indexList);

	/*
	Gets the index of the first phoneline that has coming or own
	call with the given callRef. Returns -1 if none is found.

  	@param terminal
	@param callRef
	@return
	*/
	int getComingOrOwnCall(CString terminal, CString callRef);

	/*
	Gets the index of the first phoneline that has been marked current.
	Suppose: there is only one current call for the terminal.
	Returns -1 if none is found.

	@return
	*/
	int getCurrentCall();

	/*
	Gets the index of the first phoneline that is marked to have self
	started call. Returns -1 if none is found.

	@return
	*/
	int getOwnCallLine();

	/*
	Finds the index of the phoneline with given callRef. 
	Suppose: callRef can belong to only one call.
	Returns -1, if callref is for none of the phonelines.

	@param compCallRef
	@return
	*/
	int findCallRef(CString compCallRef);

	/*
	Gets the list of indexes of the phonelines that correspond
	to one terminal. Remember one terminal can have many calls.
	Peculiar is anyway that somebody will talk with same terminal
	on 2 phonelines.

	@param compTerminal
	@param indexList
	*/
	void findTerminal(CString compTerminal, CIndexList& indexList);

	/*
	If the callRef is found from the lines, the index returned is
	for the line with the callRef if the call is also not current.
	If not current call is not found with callref, it is then
	seeked with terminal. If line with the terminal that is 
	not current is found, its index is returned. If neither of
	these methods work, -1 is returned. This method is only called 
	by CCTIDoc::checkConnectionFailed.

	@param callRef
	@param terminal
	@return
	*/
	int findFirstNotCurrentLine(CString callRef, CString terminal);

	/*
	Check call that comes to the terminal of the client and adds
	coming call to phonelines. Call is accepted only if the callref
	is not already found from the phonelines. Method will not add
	to coming calls with same callref. If coming call is to be added,
	it is added to first free line found with method getFreeLines.
	It is set to coming, its number is set to terminal and if
	transferedNumber is nonempty moving property of the line is set true.
	AddNumber of the phoneline is set to transferedNumber and 
	TransferingFromThisLine is set to false, because call is coming to
	this line. This method is only called by CCTIDoc::checkConnecting.

	@param callRef
	@param terminal
	@param transferedNumber
	*/
	void checkComingCall(CString callRef, CString terminal, 
		CString transferedNumber);

	/*
	Finds the phoneline with the terminal given and if it is found,
	sets its callref to the given one and addNumber to transferedNumber.
	That line is also set with transfering true and transferingFromThisLine
	false. This method is only called by CCTIDoc::checkConnecting.

	@param callRef
	@param terminal
	@param transferedNumber
	*/
	void checkTransferingToThisLine(CString callRef, CString terminal, 
		CString transferedNumber);

	/*
	Finds the phoneline with the terminal given and if it is found,
	sets its callref to the given one and addNumber to movedNumber.
	That line is also set with moving true and movingFromThisLine
	true. This method is only called by both CCTIDoc::checkConnecting
	and CCTIDoc::checkAlerting.

	@param callRef
	@param terminal
	@param thisLineNumber
	*/
	void checkTransferingFromThisLine(CString callRef, CString terminal,
		CString thisLineNumber);

	/*
	Finds the phoneline with the terminal given and if it is not found,
	first free line is found and it is set with property coming call,
	its callRef is set to the given one, number is set to terminal,
	AddNumber to transferedNumber. If transferedNumber is nonempty, transfering
	property is set true and callType to transfered. If the free line
	is occupied, true is returned and false otherwise.
	This method is only called by CCTIDoc::checkAlerting.

	@param callRef
	@param terminal
	@param transferedNumber
	@return
	*/
	bool checkAlertingThisTerminal(CString callRef, CString terminal,
		CString transferedNumber);

	/*
	Sets all phonelines with property not moving from this line.
	This method is called by CCTIFormView::OnTimer when
	message about moving call is shown long enough.
	*/
	void setAllLinesNotTransferingFrom();
	
	/*
	Gets the terminal from terminal1 and terminal2 that is not
	the terminal of the client, if one of them is the terminal
	of the client, otherwise empty string is returned. If
	own terminal is one of the terminals, bOwnWith is set true.

	@param terminal1
	@param terminal2
	@param bOwnWith
	@return
	*/
	CString getForeignTerminal(CString terminal1, CString terminal2, 
		bool& bOwnWith);

	/*
	Seeks first own call that is not current or hold and if it is found
	its number is set to foreignTerminal and callref to the given one.
	If then that kind of phoneline is not found, free line with
	nonempty foreign number as number, is set with property ownCall
	and callref to the given one. Then if not even such a line is found,
	free line with no number is set with the above properties.

	@param foreignTerminal
	@param callRef
	@param sTransferedNumber
	*/
	void SetCallRefOfOwnCall(CString foreignTerminal, CString callRef, 
		CString sTransferedNumber); // XXX

	/*
	If the terminal is the terminal of the client and callRef is nonempty, 
	line with the given callref is seeked and if it found, its hold property 
	is set to bHoldOn. If hold property of some line is set to true,
	also setHoldLine method of general status is set so that waiting of 
	the hold command completion can be stopped, if it is done. This method
	is called only by CCTIDoc::checkHold.

	@param terminal
	@param callRef
	@param bHoldOn
	*/
	void setHold(CString terminal, CString callRef, bool bHoldOn /* = true*/);

	/*
	If the terminal is the terminal of the client and callRef is nonempty, 
	line with the given callref is seeked and if it found, its held property 
	is set to bHeldOn. This method is called only by CCTIDoc::checkHeld.

	@param terminal
	@param callRef
	@param bHeldOn
	*/
	void setHeld(CString terminal, CString callRef, bool bHeldOn);

	/*
	Finds phoneline with the given callref and it is nonempty and found,
	line is set free. If line to be terminated contained coming call,
	bComingTerminated is set true. Index of the terminated line is
	returned and -1, if nothing was done. This method is called only by 
	CCTIDoc::checkTerminated.

	@param otherCallRef
	@param bComingTerminated
	@return
	*/
	int checkTerminated(CString otherCallRef, bool& bComingTerminated);

	/*
	Finds first coming or own call line with method getComingOrOwnCall.
	If terminal is terminal of the client and line was found, callRef
	is set to the line, current property is set true and hold property
	false. If the terminal is not the terminal of the client and line 
	was found, held property of the line is set false and if the line
	was not hold it is set current. Last method checkIfTalkingMeansHoldOff
	is called with given parameters. If the index returned by 
	getComingOrOwnCall and checkIfTalkingMeansHoldOff both return
	proper index != -1, return value is the return value of 
	checkIfTalkingMeansHoldOff. In other case it is the return value of
	getComingOrOwnCall.

	@param callRef
	@param terminal
	@return
	*/
	int checkTalking(CString callRef, CString terminal);

	/*
	Sets DND property for all free phonelines that have terminal as 
	nonempty number to bDNDOn. Called only by CCTIDoc::checkDND.

	@param terminal
	@param bDNDOn
	*/
	void setDND(CString terminal, bool bDNDOn);

	/*
	Sets in service property for all phonelines that have terminal as 
	nonempty number to bInService. Called only by CCTIDoc::checkInService.

	@param terminal
	@param bInService
	*/
	void SetInService(CString terminal, bool bInService);

	/*
	Sets the hook for the phonelines that have terminal as given
	to bHook. Called only by CCTIDoc::checkHook.

	@param terminal
	@param bHook
	*/
	void setHookOfTerminal(CString terminal, bool bHook);

	/*
	Gets the phoneline of the index and NULL if it is not existing.

	@param iLine
	@return
	*/
	CLine* getLine(int iLine);

	/*
	Gets the number of phonelines.

	@return
	*/
	int getNumberOf();
};

#endif