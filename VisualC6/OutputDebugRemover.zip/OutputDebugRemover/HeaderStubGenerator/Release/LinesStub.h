#ifndef CLINES_H 
#define CLINES_H 1
#include "Line.h"
#include "Helper.h"
#include "GeneralStatus.h"
#include "PhoneNumberList.h"
#include "IndexList.h"
#include "Output.h"
class CLines
{
private:
	COutput* m_pOutput;
#ifdef TESTFILES
	long m_lReadCounter;
	CString m_fileBuffer;
	void addTestMessage(CString message, bool bFinal=false);
#endif
	CHelper* m_pHelper;
	CGeneralStatus* m_pStatus;
	CPhoneNumberList* m_phoneNumbers;
	CFastChooses* m_pFastChooses;
	CObArray m_lines;
	int checkIfTalkingMeansHoldOff(CString callRef, CString terminal);
public:
#ifdef TESTFILES
	void checkLines();
#endif
	CLines(CHelper* pHelper, CGeneralStatus* pStatus, 
		CPhoneNumberList* phoneNumbers, CFastChooses* pFastChooses,
		COutput* pOutput);
	~CLines();
	void clearAllLines();
	BOOL GetUsedLines(CIndexList& indexlist, bool bNotHold=false);
	BOOL getFreeLines(CIndexList& indexList);
	BOOL getHeldLines(CIndexList& list);
	BOOL getHoldLines(CIndexList& indexList);
	BOOL getComingLines(CIndexList& indexList);
	void getStoppableLines(CIndexList& indexList);
	int getComingOrOwnCall(CString terminal, CString callRef);
	int getCurrentCall();
	int getOwnCallLine();
	int findCallRef(CString compCallRef);
	void findTerminal(CString compTerminal, CIndexList& indexList);
	int findFirstNotCurrentLine(CString callRef, CString terminal);
	void checkComingCall(CString callRef, CString terminal, 
		CString transferedNumber);
	void checkTransferingToThisLine(CString callRef, CString terminal, 
		CString transferedNumber);
	void checkTransferingFromThisLine(CString callRef, CString terminal,
		CString thisLineNumber);
	bool checkAlertingThisTerminal(CString callRef, CString terminal,
		CString transferedNumber);
	void setAllLinesNotTransferingFrom();
	
	CString getForeignTerminal(CString terminal1, CString terminal2, 
		bool& bOwnWith);
	void SetCallRefOfOwnCall(CString foreignTerminal, CString callRef, 
		CString sTransferedNumber); // XXX
	void setHold(CString terminal, CString callRef, bool bHoldOn /* = true*/);
	void setHeld(CString terminal, CString callRef, bool bHeldOn);
	int checkTerminated(CString otherCallRef, bool& bComingTerminated);
	int checkTalking(CString callRef, CString terminal);
	void setDND(CString terminal, bool bDNDOn);
	void SetInService(CString terminal, bool bInService);
	void setHookOfTerminal(CString terminal, bool bHook);
	CLine* getLine(int iLine);
	int getNumberOf();
};
#endif