// CTIDoc.cpp : implementation of the CCTIDoc class
//

#include "stdafx.h"
#include "CTI.h"

#include "CTIDoc.h"
#include "CTIFormView.h"
#include "MainFrm.h"

// #define TESTFILES 1

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// #define OUTPUTDEBUGPHONECALLEVENTS 1
// #define OUTPUTDEBUGSERVERCOMMANDS 1
// #define OUTPUTDEBUGCHECKCONNECTING 1
// #define OUTPUTDEBUGCHECKALERTING 1
// #define OUTPUTDEBUGCHECKTALKING 1
// #define OUTPUTDEBUGCHECKCONNECTIONFAILED 1
// #define OUTPUTDEBUGCHECKTERMINATED 1
// #define OUTPUTDEBUGPING 1
// #define OUTPUTDEBUGREDIRECTCOMMANDS 1
// #define OUTPUTDEBUGCREATINGCONNECTION 1
// #define OUTPUTDEBUGUNINITIALIZE 1
// #define OUTPUTDEBUGINITIALIZEDNS	1
// #define OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE 1
// #define OUTPUTDEBUGSENDLOGINCOMMAND 1
// #define OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND 1
// #define OUTPUTDEBUGSENDGETHISTORYCOMMAND	1
// #define OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND 1
// #define OUTPUTDEBUGSENDGETTRANSFERSCOMMAND 1
// #define OUTPUTDEBUGSENDHOLDCOMMAND 1
// #define OUTPUTDEBUGSENDHOLDOFFCOMMAND 1
// #define OUTPUTDEBUGSENDANSWERCOMMAND	1
// #define OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREDIRECT 1
// #define OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING 1
// #define OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT 1
// #define OUTPUTDEBUGSENDCALLCOMMAND 1
// #define OUTPUTDEBUGSENDENDCOMMAND 1
// #define OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND 1
// #define OUTPUTDEBUGSENDGETDETAILSCOMMAND 1
// #define OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDSETTRANSFER 1
// #define OUTPUTDEBUGSENDJOINCALLS 1
// #define OUTPUTDEBUGSENDPING 1
// #define OUTPUTDEBUGSENDDNDCOMMAND 1
// #define OUTPUTDEBUGACQUIRETRANSFERS 1
// #define OUTPUTDEBUGCHECKOK 1
// #define OUTPUTDEBUGCHECKHOOK 1
// #define OUTPUTDEBUGCHECKTALKING 1
// #define OUTPUTDEBUGCHECKALERTING	1
// #define OUTPUTDEBUGCHECKCONNECTING 1
// #define OUTPUTDEBUGCHECKTERMINATED 1
// #define OUTPUTDEBUGCHECKCONNECTIONFAILED 1
// #define OUTPUTDEBUGCHECKHOLD 1
// #define OUTPUTDEBUGCHECKDND 1
// #define OUTPUTDEBUGCHECKINSERVICE 1
// #define OUTPUTDEBUGCHECKERROR 1
// #define OUTPUTDEBUGADDPHONENUMBER 1
// #define OUTPUTDEBUGADDPHONECALL 1
// #define OUTPUTDEBUGCHECKINCOMINGTRANSFER 1
// #define OUTPUTDEBUGPHONENUMBERSEND 1
// #define OUTPUTDEBUGINCOMINGTRANSFEREND 1
// #define OUTPUTDEBUGHISTORYEND 1
// #define OUTPUTDEBUGPING 1
// #define OUTPUTDEBUGPINGRESPONSE 1
// #define OUTPUTDEBUGINFORMPASSWORDCHANGED 1
// #define OUTPUTDEBUGSOCKETERROR 1
// #define OUTPUTDEBUGEVENTMESSAGE 1
// #define OUTPUTDEBUGSETPREFIX 1
// #define OUTPUTDEBUGSETAPPLICATIONUPDATE 1
// #define OUTPUTDEBUGCALLTRANSFERCOMMANDSANDEVENTS 1
// #define OUTPUTDEBUGDESTRUCTOR 1
/////////////////////////////////////////////////////////////////////////////
// CCTIDoc

IMPLEMENT_DYNCREATE(CCTIDoc, CDocument)

BEGIN_MESSAGE_MAP(CCTIDoc, CDocument)
	//{{AFX_MSG_MAP(CCTIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CCTIDoc::informOperationForPing()
{
	if (m_pStatus)
	{
		m_pStatus->m_iLastOperationTime = m_pStatus->m_iTime;
	}
}


void CCTIDoc::FinalizeServerOperation()
{
	if (m_pStatus)
	{
		if (m_pStatus->IsLoginCompleted())
		{
			updateView();
		}
	}
	informOperationForPing();
}


void CCTIDoc::setViewAsTopMostWindow()
{
	if (m_pStatus)
	{
		m_pStatus->m_bSetAsForeGroundWindow = true;
	}
}


void CCTIDoc::updateView(bool bInitialCommandsCompleted)
{
/*
#ifdef TESTFILES
	addTestMessage("updateView");
#endif
*/
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
		pView->Update(bInitialCommandsCompleted);
		pView = NULL;
	}
}


HRESULT CCTIDoc::SendCTIMessage(char* message)
{
#ifdef TESTFILES
	CString testMessage = "SendCTIMessage";
	addTestMessage(testMessage);
	testMessage = message;
	addTestMessage(testMessage);
#endif
	CString sMessage = message;
	HRESULT hr = E_FAIL;
	_bstr_t bstrMessage = message;
	if (m_pICTIConnection)
	{
		hr = m_pICTIConnection->SendCTIMessage(bstrMessage);
	}
	return hr;
}


#ifdef TESTFILES
void CCTIDoc::addTestMessage(CString message, bool bFinal)
{
	CString fmessage;
	char counter[80];
	ltoa(m_lReadCounter, counter, 10);
	CString strCounter = counter;
	fmessage = "[" + strCounter;
	fmessage += "]:";
	fmessage += message;
	fmessage += "\n";
	m_fileBuffer += fmessage;
	if (bFinal || m_fileBuffer.GetLength() > 255)
	{
		FILE *fp;
		fp = fopen("c:\\Test\\CTIDoc.txt","a");
		fprintf(fp, "%s", m_fileBuffer.GetBuffer(0));
		fclose(fp);
		m_fileBuffer = "";
	}
	++m_lReadCounter;
}
#endif


#ifdef TESTFILES
void CCTIDoc::sendCommandTestMessage(CString commandName, int iLine)
{
	char lineNumber[6];
	itoa(iLine, lineNumber, 10);
	CString testMessage = commandName;
	testMessage += lineNumber;
	addTestMessage(testMessage);
}
#endif

#ifdef TESTFILES
void CCTIDoc::addTestEventMessage(CString message, char* terminal,
	char* callRef)
{
	CString testMessage = message;
	addTestMessage(testMessage);
	testMessage = "Terminal: ";
	testMessage += terminal;
	testMessage += " callRef: ";
	testMessage += callRef;
	addTestMessage(testMessage);
}
#endif


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc construction/destruction

CCTIDoc::CCTIDoc()
{
#ifdef TESTFILES
	m_lReadCounter = 0;
	m_fileBuffer = "";
	addTestMessage("Doc constructed");
#endif
	m_pOutput = new COutput();
    m_pStatus = new CGeneralStatus(m_pOutput);
    m_pHelper = new CHelper(m_pOutput);
    m_pTransferRules = new CTransferRules(m_pOutput);
    m_pFastChooses = new CFastChooses(m_pOutput);
    m_pCallList = new CPhoneCallsList(m_pOutput);
	m_pCallList->setStatus(m_pStatus);
    m_pPhoneNumberList = new CPhoneNumberList(m_pOutput);
    m_pLines = new CLines(m_pHelper, m_pStatus, m_pPhoneNumberList, 
		m_pFastChooses, m_pOutput);
    m_pRepresentatives = new CRepresentatives(
		m_pHelper, m_pStatus, m_pOutput);
    m_pOlderCalls = new COlderCallList(m_pOutput);
	m_pCommand = new CCTICommand(m_pOutput);
    m_pInitFile = new CInitFile(m_pStatus, m_pHelper, m_pRepresentatives, 
		m_pTransferRules, m_pFastChooses, m_pOlderCalls, m_pCallList,
		m_pPhoneNumberList, "CTI.ini", m_pOutput);
//	m_pStatus->m_mainWndMode = eNoConnection;
    m_pICTICom = NULL;
	m_pICTIConnection = NULL;
	m_bRepresentativeAnswered = FALSE;
	m_callRefOfAnsweredRepresentative = "";
}


CCTIDoc::~CCTIDoc()
{
	this->UnInitialize();
	DeletePointers();
	delete m_pOutput;
}


void CCTIDoc::DeletePointers()
{
	if (m_pInitFile)
	{
		delete m_pInitFile;
		m_pInitFile = NULL;
	}
	if (m_pCommand)
	{
		delete m_pCommand;
		m_pCommand = NULL;
	}
	if (m_pOlderCalls)
	{
		delete m_pOlderCalls;
		m_pOlderCalls = NULL;
	}
	if (m_pRepresentatives)
	{
		delete m_pRepresentatives;
		m_pRepresentatives = NULL;
	}
	if (m_pLines)
	{
		delete m_pLines;
		m_pLines = NULL;
	}
	if (m_pPhoneNumberList)
	{
		delete m_pPhoneNumberList;
		m_pPhoneNumberList = NULL;
	}
	if (m_pCallList)
	{
		delete m_pCallList;
		m_pCallList = NULL;
	}
	if (m_pFastChooses)
	{
		delete m_pFastChooses;
		m_pFastChooses = NULL;
	}
	if (m_pTransferRules)
	{
		delete m_pTransferRules;
		m_pTransferRules = NULL;
	}
	if (m_pHelper)
	{
		delete m_pHelper;
		m_pHelper = NULL;
	}
	if (m_pStatus)
	{
		m_bConnection = m_pStatus->m_bConnection;
		delete m_pStatus;
		m_pStatus = NULL;
	}
}


HRESULT CCTIDoc::UnInitialize()
{
	HRESULT hr = S_OK;
	bool bConnection = false;
	if (m_pStatus)
	{
		bConnection = m_pStatus->m_bConnection;
	}
	else
	{
		bConnection = m_bConnection;
	}
	if (bConnection)
	{
		if (m_pICTIConnection)
		{
			hr = m_pICTIConnection->UnInitialize();	
			m_pICTIConnection->Release();
			m_pICTIConnection = NULL;
		}
			
		if (m_pICTICom)
		{
			hr = m_pICTICom->Stop();
			m_pICTICom->Release();
			m_pICTICom = NULL;
			if (m_pStatus)
			{
				m_pStatus->m_bConnection = false;
				m_pStatus->m_bLoginCompleted = false;
				m_pStatus->m_bLoginOrSetPasswordRequestSendAfterGettingConnection = false;
			}
		}
	}
	return hr;
}


HRESULT CCTIDoc::InitializeDNS(int& iError)
{
	HRESULT hr = S_OK;
	if (m_pStatus)
	{
		if (!(m_pStatus->m_bConnection))
		{
			WSADATA wsaData;
			if(WSAStartup(MAKEWORD(1,1), &wsaData) != NULL)
			{
#ifdef TESTFILES
				addTestMessage("WSAStartup failed");
#endif
				hr = E_FAIL;
				iError = 1;
			}
			else
			{
				HOSTENT *pHostEnt;
				struct sockaddr_in sin;
				if (pHostEnt = gethostbyname("www.elisa.fi"))
				{
					pHostEnt = NULL;
					m_pStatus->m_bCableOn = true;
					if (pHostEnt = gethostbyname(m_pStatus->m_fullProviderName.GetBuffer(0)))
					{
						memcpy(&sin.sin_addr, pHostEnt->h_addr_list[0], 
							pHostEnt->h_length);
						m_bstrIP = inet_ntoa(sin.sin_addr);
						m_pStatus->m_bServerFound = true; 
					}
					else
					{
						hr = E_FAIL;
						m_pStatus->m_bServerFound = false;
						iError = 2;
					}
				}
				else
				{
					hr = E_FAIL;
					m_pStatus->m_bCableOn = false;
					iError = 1;
				}
			}
		}
	}
	return hr;
}


HRESULT CCTIDoc::InitializeConnection()
{
	HRESULT hr = S_OK;
	if (m_pStatus)
	{
		if (!(m_pStatus->m_bConnection))
		{
			if (!m_pICTIConnection)
			{
				try
				{
					hr = CoCreateInstance(CLSID_CTIConnectionCom, 
						NULL, CLSCTX_INPROC_SERVER,
						IID_ICTIConnectionCom, (void**)&m_pICTIConnection );
				}
				catch( .../*CException &e*/ )
				{
				}
			}
			if (m_pICTIConnection)
			{
				char serverPort[10];
				itoa(m_pStatus->m_serverPort, serverPort, 10);
				CString port = serverPort;
#ifdef TESTFILES
				addTestMessage("Port: " + port);
#endif
				if ((port == "InitializeConnection") || (port == "0"))
				{
					port = "6666";
				}
				hr = m_pICTIConnection->Initialize(m_bstrIP,
					_bstr_t(port), false);	
			}
		}

		if (FAILED (hr) && m_pICTIConnection)
		{
			m_pICTIConnection->UnInitialize();
			m_pICTIConnection->Release();
			m_pICTIConnection = NULL;
		}

		if (SUCCEEDED(hr))
		{
			if (!m_pICTICom)
			{
				try
				{
#ifdef TESTFILES
					addTestMessage("Create CTICom");
#endif
					hr = CoCreateInstance(CLSID_CTICom, 
						NULL, CLSCTX_INPROC_SERVER,
						IID_ICTICom, (void**)&m_pICTICom );
				}
				catch( ...) // CException &e
				{
				}
			}
		}
		
		if (SUCCEEDED(hr))
		{
			if (m_pICTICom)
			{
#ifdef TESTFILES
				addTestMessage("Start CTICom");
#endif
				hr = m_pICTICom->Start((IUnknown*) m_pICTIConnection, (IUnknown*) this, 
					(IUnknown*)m_pOutput);
				if (SUCCEEDED(hr))
				{
					m_pStatus->m_bConnection = true;
					m_pPhoneNumberList->clear();
				}
			}
		}
		if (FAILED(hr) && m_pICTICom)
		{
#ifdef TESTFILES
			addTestMessage("Stop CTICom");
#endif
			m_pICTICom->Stop();
			m_pICTICom->Release();
			m_pICTICom = NULL;
		}
	}
	return hr;
}


int CCTIDoc::readInitFile(CString filename)
{
	int retval = -1;
	if (m_pInitFile)
	{
		retval = m_pInitFile->readInitFile(filename);
	}
	if (retval == -1)
	{
	}
	else
	{
	}
	return retval;
}


int CCTIDoc::writeInitFile(CString filename)
{
	if (m_pInitFile)
	{
		int iRetVal = m_pInitFile->writeInitFile(filename);
		return iRetVal;
	}
	else 
	{
		return -1;
	}
}


HRESULT CCTIDoc::WaitForResponse(bool &bLoginOk, bool &bSetPassword)
{
	HRESULT hr = S_OK;
	bool bResponseReceived = false;
	bool bTempLogin = false;
	bool bTempSetPassword = false;
	if (m_pStatus)
	{
		for(int i = 0; i < 10; ++i)
		{
			bool bConnectionTryingWithSamePassword = false;
			POSITION pos = this->GetFirstViewPosition();
			CCTIFormView *pView = (CCTIFormView*) this->GetNextView(pos);
			if (pView)
			{
				bConnectionTryingWithSamePassword = 
					pView->m_bConnectionTryingWithSamePassword;
			}
			if (bConnectionTryingWithSamePassword)
			{
				Sleep(500);
			}
			else
			{
				Sleep(2000);
			}
			m_pStatus->GetLoginInfo(bResponseReceived, bTempLogin, bTempSetPassword);
			if (bResponseReceived)
			{
				bLoginOk = bTempLogin;
				bSetPassword = bTempSetPassword;
				break;
			}
		}	 
		if (!bResponseReceived)
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::WaitForPingResponse(bool &bResponseCome)
{
	HRESULT hr = S_OK;
	bool bWaitTooLong = false;
	int iCycle = 0;
	if (m_pStatus)
	{
		while ((!bResponseCome) && (!bWaitTooLong))
		{
			++iCycle;
			if (iCycle > 10) // 1 seconds waiting limit
			{
				bWaitTooLong = true;
			}
			else
			{
				m_pStatus->GetPingResponse(bResponseCome);
				if (!bResponseCome)
				{
					Sleep(100);
				}
			}
		}	 
		if (bWaitTooLong)
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::WaitForChangePasswordResponse(bool& bResponseCome, bool& bOk)
{
	HRESULT hr = S_OK;
	bool bHold = false;
	bOk = false;
	bool bWaitTooLong = false;
	int iCycle = 0;
	if (m_pStatus)
	{
		while ((!bResponseCome) && (!bWaitTooLong))
		{
			++iCycle;
			if (iCycle > 50) // 5 seconds waiting limit
			{
				bWaitTooLong = true;
			}
			else
			{
				m_pStatus->getChangePasswordStatus(bResponseCome, bOk);
				if (!bResponseCome)
				{
					Sleep(100);
				}
			}
		}	 
		if (bWaitTooLong)
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc commands

HRESULT CCTIDoc::sendLoginCommand(char* provider, char* userid, char* password)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createLoginCommand(provider, userid, password, message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendGetPhonebookCommand()
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetPhoneBookCommand(message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendGetHistoryCommand()
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetHistoryCommand(message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
			if (SUCCEEDED(hr))
			{
				m_pStatus->m_bHistoryNeedsUpdating = false;
				m_pStatus->m_bHistoryCompleted = false;
				m_pCallList->clear();
			}
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendGetUnansweredCommand()
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetUnansweredCommand(message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
			if (SUCCEEDED(hr))
			{
				m_pStatus->m_bHistoryNeedsUpdating = false;
				m_pStatus->m_bHistoryCompleted = false;
				m_pCallList->clear();
			}
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendGetTransfersCommand()
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetTransfersCommand(message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendHoldCommand(int iLine)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			CString callRef = pLine->getCallRef();
			if (pLine->getCurrent() || pLine->getHeld())
			{
				m_pCommand->createHoldCommand(callRef.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
				else
				{
					hr = E_FAIL;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendHoldOffCommand(int iLine)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			CString callRef = pLine->getCallRef();
			if (pLine->getHold())
			{
				m_pCommand->createHoldOffCommand(callRef.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendAnswerCommand(int iLine)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			CString callRef = pLine->getCallRef();
			if (pLine->getComing())
			{
				m_pCommand->createAnswerOwnCommand(callRef.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	return hr;
}


HRESULT CCTIDoc::sendAnswerRepresentativeCommand(int iRep)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
			CString callRef = pRep->getAlertingCallRef();
			if (callRef != "")
			{
				m_pCommand->createCallAnswerCommand(callRef.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
					m_bRepresentativeAnswered = TRUE;
					m_callRefOfAnsweredRepresentative = callRef;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendRedirect(int iLine, CString target)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pPhoneNumberList && m_pCommand)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			CString callRef = pLine->getCallRef();
			if (pLine->getComing())
			{
				m_pCommand->createAlertingRedirectCommand(callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else if (pLine->getCurrent())
			{
				m_pCommand->createCallRedirectCommand(callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendRedirectRepresentativeAlerting(int iRep, CString target)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand && m_pPhoneNumberList)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
			CString callRef = pRep->getAlertingCallRef();
			if (callRef != "")
			{
				m_pCommand->createAlertingRedirectCommand(
					callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendRedirectRepresentativeCurrent(int iRep, CString target)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand && m_pPhoneNumberList)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
			CString callRef = pRep->getTalkingCallRef();
			if (callRef != "")
			{
				m_pCommand->createCallRedirectCommand(
					callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}



HRESULT CCTIDoc::sendCallCommand(char* number, int iLine)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pPhoneNumberList && m_pCommand)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			if (pLine->getFree())
			{
				pLine->setNumber(number);
				pLine->setOwnCall(true);
				if (m_pOlderCalls)
				{
					m_pOlderCalls->add(number);
				}
				CString terminal = pLine->getNumber();
				m_pCommand->createCallCommand(terminal.GetBuffer(0), message);
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
					updateView();
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendEndCommand(int iLine)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines)
	{
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine && m_pCommand)
		{
			if (!pLine->getFree())
			{
				CString callRef = pLine->getCallRef();
				if (callRef != "")
				{
					m_pCommand->createEndCallCommand(callRef.GetBuffer(0), message);
				}
				else
				{
					CString terminal = pLine->getNumber();
					m_pCommand->createEndCallCommandWithTerminal(
						terminal.GetBuffer(0), message);
				}
				if (m_pICTIConnection)
				{
					hr = SendCTIMessage(message);
				}
				else
				{
					hr = E_FAIL;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return  hr;
}


HRESULT CCTIDoc::sendChangePasswordCommand(char* oldPassword, char* newPassword)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createSetPasswordCommand(oldPassword, newPassword, message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendGetDetailsCommand(char* terminal)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetDetailsCommand(terminal, message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendAddRepresentativeCommand(int iRep)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
			m_pCommand->createListenCommand(repTerminal.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendAddRingingRepresentativeCommand(int iRep)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
			m_pCommand->createListenWithRingingCommand(repTerminal.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendRemoveRepresentativeCommand(int iRep)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
			m_pCommand->createListenOffCommand(repTerminal.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendRemoveRingingRepresentativeCommand(int iRep)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		CString repName = pRep->getName();
		CString repTerminal = pRep->getTerminal();
		if (m_pCommand)
		{
			m_pCommand->createListenWithRingingOffCommand(repTerminal.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendSetTransfer(int type, char* number)
{
	HRESULT hr = E_FAIL;
	char message[500];
	CString cNumber = number;
	if (m_pCommand && m_pHelper)
	{
		CString terminal = m_pHelper->getTerminal(cNumber);
		m_pCommand->createSetTransferCommand(type, number, message);
		if (strlen(message) > 0)
		{
			if (m_pICTIConnection)
			{
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendJoinCalls(char* callRef1, char* callRef2)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createJoinCallsCommand(callRef1, callRef2, message);
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendPing()
{
	HRESULT hr = E_FAIL;
	char message[80];
	strcpy(message, PING);
	if (m_pICTIConnection)
	{
		hr = SendCTIMessage(message);
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::sendDNDCommand(bool bDND)
{
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		if (bDND)
		{
			m_pCommand->createDNDOnCommand(message);
		}
		else
		{
			m_pCommand->createDNDOffCommand(message);
		}
		if (m_pICTIConnection)
		{
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


HRESULT CCTIDoc::acquireTransfers()
{
	HRESULT hr = E_FAIL;
	bool bGot = false;
	if (m_pStatus)
	{
		m_pStatus->setTransfersGot(false);
		if (m_pTransferRules)
		{
			m_pTransferRules->clear();
		}
		hr = sendGetTransfersCommand();
		if (SUCCEEDED(hr))
		{
			for(int i = 0; i < 10; ++i)
			{
				Sleep(300);
				m_pStatus->getTransfersGot(bGot);
				if (bGot)
				{
					hr = S_OK;
					m_pTransferRules->adjust();
					break;
				}
			}
			if (!bGot)
			{
				hr = E_FAIL;
			}
		}
		else
		{
		}
	}
	else
	{
		hr = E_FAIL;
	}
	return hr;
}


void CCTIDoc::checkOK(bool bPasswordOK)
{
	informOperationForPing();
	if (bPasswordOK && m_pStatus)
	{
		m_pStatus->setChangePasswordStatus(true);
	}
}


void CCTIDoc::checkHook(char* terminal, bool bHook)
{
	if (m_pLines && m_pRepresentatives && m_pStatus)
	{
		CString sTerminal = terminal;
		if (m_pStatus->m_terminal == sTerminal)
		{
			m_pStatus->m_bOwnHook = bHook;
		}
		m_pLines->setHookOfTerminal(sTerminal, bHook);
		m_pRepresentatives->checkRepresentativeHook(terminal, bHook);
		FinalizeServerOperation();
	}
}


void CCTIDoc::checkTalking(char* terminal, char* callRef, 
	char* transferedNumber)
{
	CString sCallRef = callRef;
	CString sTerminal = terminal;
	CString sTransferedNumber = transferedNumber;
	if (m_pLines && m_pRepresentatives && m_pStatus)
	{
		m_pLines->checkTalking(sCallRef, sTerminal);
		m_pRepresentatives->checkTalkingRepresentative(sTerminal, sCallRef);
	}
	FinalizeServerOperation();
}


void CCTIDoc::checkAlerting(char* terminal1, char* terminal2, char* callRef,
	char* transferedNumber)
{
	bool bOwnWith;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
	CString sCallRef = callRef;
	CString sTransferedNumber = transferedNumber;
	CString origTransfered = "";
	if (sTransferedNumber)
	{
		origTransfered = sTransferedNumber;
	}
	if (m_pStatus && m_pLines && m_pRepresentatives)
	{
		CString foreignTerminal = 
			m_pLines->getForeignTerminal(sTerminal1, sTerminal2, bOwnWith);
		if (sTransferedNumber == m_pStatus->m_terminal)
		{
			// moving from line of this terminal
			// call is moved to sTerminal2, and moved from sMovedNumber
			CString empty = ""; // Number of the line is not changed.
			m_pLines->checkTransferingFromThisLine(sCallRef, sTerminal2, empty);
		}
		else if (bOwnWith && (foreignTerminal != ""))
		{
			if (sTerminal1 == m_pStatus->m_terminal)
			{
				if (m_pLines->checkAlertingThisTerminal(sCallRef, sTerminal2, 
					sTransferedNumber))
				{
					setViewAsTopMostWindow();
				}
			}
			else if (sTerminal2 == m_pStatus->m_terminal)
			{
				m_pLines->SetCallRefOfOwnCall(foreignTerminal, sCallRef, sTransferedNumber);
			}
		}
		if (m_pRepresentatives->checkAlertingRepresentative(sTerminal1, sTerminal2, 
			sCallRef, m_pStatus->m_iTime))
		{
			setViewAsTopMostWindow();
		}
		if (m_bRepresentativeAnswered && 
			(sCallRef == m_callRefOfAnsweredRepresentative) && m_pCommand)
		{
			char message[500];
			m_pCommand->createAnswerOwnCommand(sCallRef.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
				HRESULT hr = SendCTIMessage(message);
			}
			m_bRepresentativeAnswered = FALSE;
			m_callRefOfAnsweredRepresentative = "";
		}
		FinalizeServerOperation();
	}
}


void CCTIDoc::checkConnecting(char* terminal1, char* terminal2, char* callRef, 
	char* transferedNumber)
{
	bool bOwnWith;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
	CString sCallRef = callRef;
	CString sTransferedNumber = transferedNumber;
	if (m_pStatus && m_pLines && m_pRepresentatives)
	{
		if (sTransferedNumber == m_pStatus->m_terminal)
		{
			// moving from line of this terminal
			m_pLines->checkTransferingFromThisLine(sCallRef, sTerminal2, 
				sTerminal1);
		}
		else if (sTerminal1 == m_pStatus->m_terminal)
		{
			CString foreignTerminal = 
				m_pLines->getForeignTerminal(sTerminal1, sTerminal2, bOwnWith);
			m_pLines->SetCallRefOfOwnCall(foreignTerminal, sCallRef, sTransferedNumber);
		}
		else
		{
			m_pLines->checkTransferingToThisLine(sCallRef, sTerminal2, 
				sTransferedNumber);
			if (sTerminal2 == m_pStatus->m_terminal)
			{
				m_pLines->checkComingCall(sCallRef, sTerminal1, 
					sTransferedNumber);
			}
		}
		m_pRepresentatives->checkAlertingRepresentative(sTerminal2, sTerminal1, 
			sCallRef, m_pStatus->m_iTime);
		m_pRepresentatives->checkConnectingRepresentative(sTerminal1, sCallRef);
		FinalizeServerOperation();
	}
}


void CCTIDoc::checkTerminated(char* terminal, char* callRef)
{
	bool bOwnWith = false;
	CString sTerminal = terminal;
	CString sCallRef = callRef;
	if (m_pStatus)
	{
		if (m_pLines)
		{
			bool bComingTerminated = false;
			m_pLines->checkTerminated(sCallRef, bComingTerminated);
		}
		if (m_pRepresentatives)
		{
			m_pRepresentatives->checkDisconnectedRepresentative(sTerminal, sCallRef);
		}
		FinalizeServerOperation();
	}
}


void CCTIDoc::checkConnectionFailed(char* terminal1, char* terminal2, char* callRef,
    char* reason)
{
	int iLine;
	CString sCallRef = callRef;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
	if (m_pLines && m_pStatus)
	{
		iLine = m_pLines->findFirstNotCurrentLine(sCallRef, sTerminal2);
		if (iLine != -1)
		{
			CLine* pLine = m_pLines->getLine(iLine);
			if (pLine)
			{
				pLine->setCallRef(sCallRef);
				if (sTerminal1 == m_pStatus->m_terminal)
				{
					pLine->setOwnCall(true);
					pLine->setNumber(sTerminal2);
				}
				else if (sTerminal2 == m_pStatus->m_terminal)
				{
					pLine->setComing(true);
					pLine->setNumber(sTerminal1);
					if (m_pRepresentatives)
					{
						m_pRepresentatives->checkConnectingRepresentative(sTerminal1, 
							sCallRef);
					}
				}
				if (strcmp(reason, FAIL_REASON_BUSY) == 0)
				{
					pLine->setReserved(true);
				}
				if (strcmp(reason, FAIL_REASON_DND) == 0)
				{
					pLine->setDND(true);
				}
				if (strcmp(reason, FAIL_REASON_UNKNOWN) == 0)
				{
					pLine->setUnknownError(true);
				}
			}
		}

		FinalizeServerOperation();
	}
}


void CCTIDoc::checkHold(char* terminal, char* callRef, bool bHold)
{
	CString sTerminal = terminal;
	CString sCallRef = callRef;
	if (m_pLines && m_pStatus)
	{
		m_pLines->setHold(sTerminal, sCallRef, bHold);
	}
	FinalizeServerOperation();
}



void CCTIDoc::checkHeld(char* terminal, char* callRef, bool bHeld)
{
	CString sTerminal = terminal;
	CString sCallRef = callRef;
	if (m_pLines && m_pStatus)
	{
		m_pLines->setHeld(sTerminal, sCallRef, bHeld);
	}
	FinalizeServerOperation();
}


void CCTIDoc::checkDND(char* terminal, bool bDNDOn)
{
	CString sTerminal = terminal;
    CRepresentative* pRep;
    int iRep;
	if (m_pStatus)
	{
		if (sTerminal == m_pStatus->m_terminal)
		{
			m_pStatus->m_bOwnDND = bDNDOn;
		}
		else
		{
			m_pLines->setDND(terminal, bDNDOn);
			iRep = m_pRepresentatives->findRepresentativeTerminal(sTerminal);
			if (iRep != -1)
			{
				pRep = m_pRepresentatives->getRepresentative(iRep);
				if (pRep)
				{
					pRep->setDND(bDNDOn);
				}
			}
		}
		FinalizeServerOperation();
	}
}


void CCTIDoc::checkInService(char* terminal, bool bInService)
{
	CString sTerminal = terminal;
	if (m_pStatus)
	{
		if (sTerminal == m_pStatus->m_terminal)
		{
			m_pStatus->m_bOwnInService = bInService;
		}
	}
	if (m_pLines)
	{
		m_pLines->SetInService(terminal, bInService);
	}
	if (m_pRepresentatives)
	{
		m_pRepresentatives->SetRepInService(sTerminal, bInService);
	}
	FinalizeServerOperation();
}


void CCTIDoc::checkError(int errorType)
{
	POSITION pos = this->GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) this->GetNextView(pos);
	if (pView)
	{
		pView->SetErrorMessage(errorType);
	}
}


void CCTIDoc::addPhoneNumber(char* terminal, char* firstname, char* lastname, 
	char* gsm, bool bGroupNumber)
{
	if (m_pHelper)
	{
		CPhoneNumber* number = new CPhoneNumber(terminal, firstname,
			lastname, gsm, bGroupNumber, m_pOutput);
		if (number && m_pPhoneNumberList)
		{
			m_pPhoneNumberList->add(number);
			informOperationForPing();
		}
	}
}


void CCTIDoc::addPhoneCall(char* syear, char* smonth, char* sday, 
	char* stime, char* scallingaddress,
	char* scalledaddress, int iStatus)
{
	if (m_pHelper)
	{
		CString caller = scallingaddress;
		if ((iStatus == 2) && (caller != "") && 
			(caller != m_pStatus->m_terminal))
		{
			CString callingNumber = scallingaddress;
			strcpy(scallingaddress, callingNumber.GetBuffer(0));
			CPhoneCall* pCall = new CPhoneCall(
				syear, smonth, sday, stime, scallingaddress,
				scalledaddress, iStatus);
			if (pCall && m_pCallList)
			{
				m_pCallList->add(pCall);
			}
			else
			{
				delete pCall;
			}
		}
	}
	if (m_pStatus)
	{
		++m_pStatus->m_iNumberOfNewUnansweredCalls;
		m_pStatus->SetHistoryCompleted();
		POSITION pos = GetFirstViewPosition();
		CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
		if (pView)
		{
			pView->SendMessage(WM_USER+6, 0, 0);
			pView = NULL;
		}
	}
	informOperationForPing();
}


void CCTIDoc::checkInComingTransfer(int iType, char* number)
{
	if (m_pTransferRules)
	{
		switch(iType)
		{
			case 0 : m_pTransferRules->m_nameTransferAllCalls = number;
					 m_pTransferRules->m_bTransferAllCalls = true;
					 break;
			case 1 : m_pTransferRules->m_nameTransferReservedCalls = number;
					 m_pTransferRules->m_bTransferReservedCalls = true;
					 break;
			case 2 : m_pTransferRules->m_nameTransferNoAnswerCalls = number;
					 m_pTransferRules->m_bTransferNoAnswerCalls = true;
					 break;
			default : break;
		}
	}
}


void CCTIDoc::checkInComingUserDetail(int fieldNumber, char* fieldData)
{
	CString data = fieldData;
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
		pView->updateUserDetail(fieldNumber, data);
		pView = NULL;
	}
}


void CCTIDoc::phoneNumbersEnd()
{
	if (m_pStatus)
	{
		m_pStatus->SetPhoneBookCompleted();
		updateView(true);
		informOperationForPing();
		// set history ready if it is not
		POSITION pos = GetFirstViewPosition();
		CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
		if (pView)
		{
			pView->refreshCalls(false);
			pView->refreshPhoneBookListControl();
			pView = NULL;
		}
	}
}


void CCTIDoc::checkInComingTransferEnd()
{
	if (m_pStatus)
	{
		m_pStatus->setTransfersGot(true);
	}
	FinalizeServerOperation();
}


void CCTIDoc::historyEnd()
{
	bool bCompleted = false;
	if (m_pStatus)
	{
		m_pStatus->SetHistoryCompleted();
		bCompleted = true;
	}
	FinalizeServerOperation();
}


void CCTIDoc::ping()
{
	HRESULT hr = E_FAIL;
	char message[80];
	strcpy(message, PING_RESPONSE);
	if (m_pICTIConnection)
	{
		hr = SendCTIMessage(message);
	}
	informOperationForPing();
}


void CCTIDoc::pingResponse()
{
	if (m_pStatus)
	{
		m_pStatus->SetPingResponse();
		informOperationForPing();
	}
}


void CCTIDoc::informPasswordChanged()
{
}


void CCTIDoc::socketError()
{
	if (m_pStatus)
	{
		m_pStatus->SetTerminateAll();
	}
}


void CCTIDoc::eventMessage(char* message)
{
}


void CCTIDoc::setPrefix(char* prefix)
{
	if (m_pStatus)
	{
		m_pStatus->m_prefix = prefix;
		if (m_pCallList)
		{
			m_pCallList->setStatus(m_pStatus);
		}
	}
}


void CCTIDoc::SetApplicationUpdate(CStringArray &urls)
{
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
		m_pStatus->m_bApplicationToBeUpdated = true;
		pView->SetURL(urls);
	}
}


BOOL CCTIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCTIDoc serialization

void CCTIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}


HRESULT CCTIDoc::GetConnectedState(BOOL& bConnectedState)
{
#ifdef TESTFILES
	addTestMessage("GetConnectedState");
#endif
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	HRESULT hr = S_OK;
	return hr;
}


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc diagnostics

#ifdef _DEBUG
void CCTIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCTIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG
