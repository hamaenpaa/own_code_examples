// CTIDoc.cpp : implementation of the CCTIDoc class
//

#include "stdafx.h"
#include "CTI.h"

#include "CTIDoc.h"
#include "CTIFormView.h"
#include "MainFrm.h"

// #define TESTFILES 1

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// #define OUTPUTDEBUGPHONECALLEVENTS 1
// #define OUTPUTDEBUGSERVERCOMMANDS 1
// #define OUTPUTDEBUGCHECKCONNECTING 1
// #define OUTPUTDEBUGCHECKALERTING 1
// #define OUTPUTDEBUGCHECKTALKING 1
// #define OUTPUTDEBUGCHECKCONNECTIONFAILED 1
// #define OUTPUTDEBUGCHECKTERMINATED 1
// #define OUTPUTDEBUGPING 1
// #define OUTPUTDEBUGREDIRECTCOMMANDS 1
// #define OUTPUTDEBUGCREATINGCONNECTION 1
// #define OUTPUTDEBUGUNINITIALIZE 1
// #define OUTPUTDEBUGINITIALIZEDNS	1
// #define OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE 1
// #define OUTPUTDEBUGSENDLOGINCOMMAND 1
// #define OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND 1
// #define OUTPUTDEBUGSENDGETHISTORYCOMMAND	1
// #define OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND 1
// #define OUTPUTDEBUGSENDGETTRANSFERSCOMMAND 1
// #define OUTPUTDEBUGSENDHOLDCOMMAND 1
// #define OUTPUTDEBUGSENDHOLDOFFCOMMAND 1
// #define OUTPUTDEBUGSENDANSWERCOMMAND	1
// #define OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREDIRECT 1
// #define OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING 1
// #define OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT 1
// #define OUTPUTDEBUGSENDCALLCOMMAND 1
// #define OUTPUTDEBUGSENDENDCOMMAND 1
// #define OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND 1
// #define OUTPUTDEBUGSENDGETDETAILSCOMMAND 1
// #define OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND 1
// #define OUTPUTDEBUGSENDSETTRANSFER 1
// #define OUTPUTDEBUGSENDJOINCALLS 1
// #define OUTPUTDEBUGSENDPING 1
// #define OUTPUTDEBUGSENDDNDCOMMAND 1
// #define OUTPUTDEBUGACQUIRETRANSFERS 1
// #define OUTPUTDEBUGCHECKOK 1
// #define OUTPUTDEBUGCHECKHOOK 1
// #define OUTPUTDEBUGCHECKTALKING 1
// #define OUTPUTDEBUGCHECKALERTING	1
// #define OUTPUTDEBUGCHECKCONNECTING 1
// #define OUTPUTDEBUGCHECKTERMINATED 1
// #define OUTPUTDEBUGCHECKCONNECTIONFAILED 1
// #define OUTPUTDEBUGCHECKHOLD 1
// #define OUTPUTDEBUGCHECKDND 1
// #define OUTPUTDEBUGCHECKINSERVICE 1
// #define OUTPUTDEBUGCHECKERROR 1
// #define OUTPUTDEBUGADDPHONENUMBER 1
// #define OUTPUTDEBUGADDPHONECALL 1
// #define OUTPUTDEBUGCHECKINCOMINGTRANSFER 1
// #define OUTPUTDEBUGPHONENUMBERSEND 1
// #define OUTPUTDEBUGINCOMINGTRANSFEREND 1
// #define OUTPUTDEBUGHISTORYEND 1
// #define OUTPUTDEBUGPING 1
// #define OUTPUTDEBUGPINGRESPONSE 1
// #define OUTPUTDEBUGINFORMPASSWORDCHANGED 1
// #define OUTPUTDEBUGSOCKETERROR 1
// #define OUTPUTDEBUGEVENTMESSAGE 1
// #define OUTPUTDEBUGSETPREFIX 1
// #define OUTPUTDEBUGSETAPPLICATIONUPDATE 1
// #define OUTPUTDEBUGCALLTRANSFERCOMMANDSANDEVENTS 1
// #define OUTPUTDEBUGDESTRUCTOR 1
/////////////////////////////////////////////////////////////////////////////
// CCTIDoc

IMPLEMENT_DYNCREATE(CCTIDoc, CDocument)

BEGIN_MESSAGE_MAP(CCTIDoc, CDocument)
	//{{AFX_MSG_MAP(CCTIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CCTIDoc::informOperationForPing()
{
	if (m_pStatus)
	{
		m_pStatus->m_iLastOperationTime = m_pStatus->m_iTime;
	}
}


void CCTIDoc::FinalizeServerOperation()
{
	if (m_pStatus)
	{
		if (m_pStatus->IsLoginCompleted())
		{
			updateView();
		}
	}
	informOperationForPing();
}


void CCTIDoc::setViewAsTopMostWindow()
{
	if (m_pStatus)
	{
		m_pStatus->m_bSetAsForeGroundWindow = true;
	}
}


void CCTIDoc::updateView(bool bInitialCommandsCompleted)
{
/*
#ifdef TESTFILES
	addTestMessage("updateView");
#endif
*/
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
		pView->Update(bInitialCommandsCompleted);
		pView = NULL;
	}
}


HRESULT CCTIDoc::SendCTIMessage(char* message)
{
#ifdef TESTFILES
	CString testMessage = "SendCTIMessage";
	addTestMessage(testMessage);
	testMessage = message;
	addTestMessage(testMessage);
#endif
	CString sMessage = message;
#ifdef OUTPUTDEBUGSERVERCOMMANDS
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "SendCTIMessage", 
		Server command: " + sMessage + "\n");
#endif
	HRESULT hr = E_FAIL;
	_bstr_t bstrMessage = message;
	if (m_pICTIConnection)
	{
		hr = m_pICTIConnection->SendCTIMessage(bstrMessage);
	}
#ifdef OUTPUTDEBUGSERVERCOMMANDS
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "SendCTIMessage", 
			"Server command sending succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "SendCTIMessage", 
			"Server command sending failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


#ifdef TESTFILES
void CCTIDoc::addTestMessage(CString message, bool bFinal)
{
	CString fmessage;
	char counter[80];
	ltoa(m_lReadCounter, counter, 10);
	CString strCounter = counter;
	fmessage = "[" + strCounter;
	fmessage += "]:";
	fmessage += message;
	fmessage += "\n";
	m_fileBuffer += fmessage;
	if (bFinal || m_fileBuffer.GetLength() > 255)
	{
		FILE *fp;
		fp = fopen("c:\\Test\\CTIDoc.txt","a");
		fprintf(fp, "%s", m_fileBuffer.GetBuffer(0));
		fclose(fp);
		m_fileBuffer = "";
	}
	++m_lReadCounter;
}
#endif


#ifdef TESTFILES
void CCTIDoc::sendCommandTestMessage(CString commandName, int iLine)
{
	char lineNumber[6];
	itoa(iLine, lineNumber, 10);
	CString testMessage = commandName;
	testMessage += lineNumber;
	addTestMessage(testMessage);
}
#endif

#ifdef TESTFILES
void CCTIDoc::addTestEventMessage(CString message, char* terminal,
	char* callRef)
{
	CString testMessage = message;
	addTestMessage(testMessage);
	testMessage = "Terminal: ";
	testMessage += terminal;
	testMessage += " callRef: ";
	testMessage += callRef;
	addTestMessage(testMessage);
}
#endif


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc construction/destruction

CCTIDoc::CCTIDoc()
{
#ifdef TESTFILES
	m_lReadCounter = 0;
	m_fileBuffer = "";
	addTestMessage("Doc constructed");
#endif
	m_pOutput = new COutput();
    m_pStatus = new CGeneralStatus(m_pOutput);
    m_pHelper = new CHelper(m_pOutput);
    m_pTransferRules = new CTransferRules(m_pOutput);
    m_pFastChooses = new CFastChooses(m_pOutput);
    m_pCallList = new CPhoneCallsList(m_pOutput);
	m_pCallList->setStatus(m_pStatus);
    m_pPhoneNumberList = new CPhoneNumberList(m_pOutput);
    m_pLines = new CLines(m_pHelper, m_pStatus, m_pPhoneNumberList, 
		m_pFastChooses, m_pOutput);
    m_pRepresentatives = new CRepresentatives(
		m_pHelper, m_pStatus, m_pOutput);
    m_pOlderCalls = new COlderCallList(m_pOutput);
	m_pCommand = new CCTICommand(m_pOutput);
    m_pInitFile = new CInitFile(m_pStatus, m_pHelper, m_pRepresentatives, 
		m_pTransferRules, m_pFastChooses, m_pOlderCalls, m_pCallList,
		m_pPhoneNumberList, "CTI.ini", m_pOutput);
//	m_pStatus->m_mainWndMode = eNoConnection;
    m_pICTICom = NULL;
	m_pICTIConnection = NULL;
	m_bRepresentativeAnswered = FALSE;
	m_callRefOfAnsweredRepresentative = "";
}


CCTIDoc::~CCTIDoc()
{
#ifdef OUTPUTDEBUGDESTRUCTOR
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "destructor", "begin\n");
#endif
	this->UnInitialize();
	DeletePointers();
#ifdef OUTPUTDEBUGDESTRUCTOR
	m_pOutput->Out("CCTIDoc", "destructor", "end\n");
	m_pOutput->endSeparator();
#endif
	delete m_pOutput;
}


void CCTIDoc::DeletePointers()
{
#ifdef OUTPUTDEBUGDESTRUCTOR
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "DeletePointers", "begin\n");
#endif
	if (m_pInitFile)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pInitFile\n");
#endif
		delete m_pInitFile;
		m_pInitFile = NULL;
	}
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pCommand\n");
#endif
		delete m_pCommand;
		m_pCommand = NULL;
	}
	if (m_pOlderCalls)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pOlderCalls\n");
#endif
		delete m_pOlderCalls;
		m_pOlderCalls = NULL;
	}
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pRepresentatives\n");
#endif
		delete m_pRepresentatives;
		m_pRepresentatives = NULL;
	}
	if (m_pLines)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pLines\n");
#endif
		delete m_pLines;
		m_pLines = NULL;
	}
	if (m_pPhoneNumberList)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pPhoneNumberList\n");
#endif
		delete m_pPhoneNumberList;
		m_pPhoneNumberList = NULL;
	}
	if (m_pCallList)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pCallList\n");
#endif
		delete m_pCallList;
		m_pCallList = NULL;
	}
	if (m_pFastChooses)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pFastChooses\n");
#endif
		delete m_pFastChooses;
		m_pFastChooses = NULL;
	}
	if (m_pTransferRules)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pTransferRules\n");
#endif
		delete m_pTransferRules;
		m_pTransferRules = NULL;
	}
	if (m_pHelper)
	{
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pHelper\n");
#endif
		delete m_pHelper;
		m_pHelper = NULL;
	}
	if (m_pStatus)
	{
		m_bConnection = m_pStatus->m_bConnection;
#ifdef OUTPUTDEBUGDESTRUCTOR
		m_pOutput->Out("CCTIDoc", "DeletePointers", "m_pStatus\n");
		if (m_bConnection)
		{
			m_pOutput->Out("CCTIDoc", "DeletePointers", "m_bConnection\n");
		}
		else
		{
			m_pOutput->Out("CCTIDoc", "DeletePointers", "!m_bConnection\n");
		}
#endif
		delete m_pStatus;
		m_pStatus = NULL;
	}
#ifdef OUTPUTDEBUGDESTRUCTOR
	m_pOutput->Out("CCTIDoc", "DeletePointers", "end\n");
	m_pOutput->endSeparator();
#endif
}


HRESULT CCTIDoc::UnInitialize()
{
#ifdef OUTPUTDEBUGUNINITIALIZE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "UnInitialize", "begin\n");
#endif
	HRESULT hr = S_OK;
	bool bConnection = false;
	if (m_pStatus)
	{
		bConnection = m_pStatus->m_bConnection;
	}
	else
	{
		bConnection = m_bConnection;
	}
	if (bConnection)
	{
#ifdef OUTPUTDEBUGUNINITIALIZE
		m_pOutput->Out("CCTIDoc", "UnInitialize", 
			"m_pStatus->m_bConnection\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGUNINITIALIZE
			m_pOutput->Out("CCTIDoc", "UnInitialize", 
				"Uninitialize CTIConnection\n");
#endif
			hr = m_pICTIConnection->UnInitialize();	
			m_pICTIConnection->Release();
			m_pICTIConnection = NULL;
		}
			
		if (m_pICTICom)
		{
#ifdef OUTPUTDEBUGUNINITIALIZE
			m_pOutput->Out("CCTIDoc", "UnInitialize", "Stop CTICom\n");
#endif
			hr = m_pICTICom->Stop();
			m_pICTICom->Release();
			m_pICTICom = NULL;
			if (m_pStatus)
			{
#ifdef OUTPUTDEBUGUNINITIALIZE
				m_pOutput->Out("CCTIDoc", "UnInitialize", 
					"m_pStatus->m_bConnection = false; ",
					"m_pStatus->m_bLoginCompleted = false;\n");
#endif
				m_pStatus->m_bConnection = false;
				m_pStatus->m_bLoginCompleted = false;
				m_pStatus->m_bLoginOrSetPasswordRequestSendAfterGettingConnection = false;
			}
		}
	}
#ifdef OUTPUTDEBUGUNINITIALIZE
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "UnInitialize", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "UnInitialize", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::InitializeDNS(int& iError)
{
#ifdef OUTPUTDEBUGINITIALIZEDNS
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "InitializeDNS", "begin\n");
#endif
	HRESULT hr = S_OK;
	if (m_pStatus)
	{
		if (!(m_pStatus->m_bConnection))
		{
			WSADATA wsaData;
			if(WSAStartup(MAKEWORD(1,1), &wsaData) != NULL)
			{
#ifdef OUTPUTDEBUGINITIALIZEDNS
				m_pOutput->Out("CCTIDoc", "InitializeDNS", 
					"WSAStartup failed -> iError = 1\n");
#endif
#ifdef TESTFILES
				addTestMessage("WSAStartup failed");
#endif
				hr = E_FAIL;
				iError = 1;
			}
			else
			{
#ifdef OUTPUTDEBUGINITIALIZEDNS
				m_pOutput->Out("CCTIDoc", "InitializeDNS", 
					"WSAStartup succeeded\n");
#endif
				HOSTENT *pHostEnt;
				struct sockaddr_in sin;
#ifdef OUTPUTDEBUGINITIALIZEDNS
				m_pOutput->Out("CCTIDoc", "InitializeDNS", 
					"finding www.elisa.fi\n");
#endif
				if (pHostEnt = gethostbyname("www.elisa.fi"))
				{
#ifdef OUTPUTDEBUGINITIALIZEDNS
					m_pOutput->Out("CCTIDoc", "InitializeDNS", 
						"www.elisa.fi found\n");
#endif
					pHostEnt = NULL;
					m_pStatus->m_bCableOn = true;
#ifdef OUTPUTDEBUGINITIALIZEDNS
					m_pOutput->Out("CCTIDoc", "InitializeDNS", 
						"FullProviderName",
						m_pStatus->m_fullProviderName, "\n");
#endif
					if (pHostEnt = gethostbyname(m_pStatus->m_fullProviderName.GetBuffer(0)))
					{
#ifdef OUTPUTDEBUGINITIALIZEDNS
						m_pOutput->Out("CCTIDoc", "InitializeDNS", 
							"DNS IP found, ",
							"m_pStatus->m_bServerFound = true\n");
#endif
						memcpy(&sin.sin_addr, pHostEnt->h_addr_list[0], 
							pHostEnt->h_length);
						m_bstrIP = inet_ntoa(sin.sin_addr);
						m_pStatus->m_bServerFound = true; 
					}
					else
					{
#ifdef OUTPUTDEBUGINITIALIZEDNS
						m_pOutput->Out("CCTIDoc", "InitializeDNS", 
							"DNS IP not found -> iError = 2, ",
							"m_pStatus->m_bServerFound = false, ",
							"hr = E_FAIL\n");
#endif
						hr = E_FAIL;
						m_pStatus->m_bServerFound = false;
						iError = 2;
					}
				}
				else
				{
#ifdef OUTPUTDEBUGINITIALIZEDNS
					m_pOutput->Out("CCTIDoc", "InitializeDNS", 
						"www.elisa.fi not found -> iError = 1",
						", m_pStatus->m_bCableOn = false, hr = E_FAIL\n");
#endif
					hr = E_FAIL;
					m_pStatus->m_bCableOn = false;
					iError = 1;
				}
			}
		}
	}
#ifdef OUTPUTDEBUGINITIALIZEDNS
	char sError[10];
	itoa(iError, sError, 10);
	CString strError = sError;
	m_pOutput->Out("CCTIDoc", "InitializeDNS", "iError = " + strError + "\n");
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "InitializeDNS", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "InitializeDNS", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::InitializeConnection()
{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "InitializeConnection", "begin\n");
#endif
	HRESULT hr = S_OK;
	if (m_pStatus)
	{
		if (!(m_pStatus->m_bConnection))
		{
			if (!m_pICTIConnection)
			{
				try
				{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
					m_pOutput->Out("CCTIDoc", "InitializeConnection",
						"InitializeConnectionComponent\n");
#endif
					hr = CoCreateInstance(CLSID_CTIConnectionCom, 
						NULL, CLSCTX_INPROC_SERVER,
						IID_ICTIConnectionCom, (void**)&m_pICTIConnection );
				}
				catch( .../*CException &e*/ )
				{
				}
			}
			if (m_pICTIConnection)
			{
				char serverPort[10];
				itoa(m_pStatus->m_serverPort, serverPort, 10);
				CString port = serverPort;
#ifdef OUTPUTDEBUGCREATINGCONNECTION
				m_pOutput->Out("CCTIDoc", "InitializeConnection",
					"Port: " + port + "\n");
#endif
#ifdef TESTFILES
				addTestMessage("Port: " + port);
#endif
				if ((port == "InitializeConnection") || (port == "0"))
				{
					port = "6666";
				}
				hr = m_pICTIConnection->Initialize(m_bstrIP,
					_bstr_t(port), false);	
			}
		}

		if (FAILED (hr) && m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
			m_pOutput->Out("CCTIDoc", "InitializeConnection",
				"failed connection: Uninitialize connection\n");
#endif
			m_pICTIConnection->UnInitialize();
			m_pICTIConnection->Release();
			m_pICTIConnection = NULL;
		}

		if (SUCCEEDED(hr))
		{
			if (!m_pICTICom)
			{
				try
				{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
					m_pOutput->Out("CCTIDoc", "InitializeConnection",
						"Create CTICom\n");
#endif
#ifdef TESTFILES
					addTestMessage("Create CTICom");
#endif
					hr = CoCreateInstance(CLSID_CTICom, 
						NULL, CLSCTX_INPROC_SERVER,
						IID_ICTICom, (void**)&m_pICTICom );
				}
				catch( ...) // CException &e
				{
				}
			}
		}
		
		if (SUCCEEDED(hr))
		{
			if (m_pICTICom)
			{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
				m_pOutput->Out("CCTIDoc", "InitializeConnection","Start CTICom\n");
#endif
#ifdef TESTFILES
				addTestMessage("Start CTICom");
#endif
				hr = m_pICTICom->Start((IUnknown*) m_pICTIConnection, (IUnknown*) this, 
					(IUnknown*)m_pOutput);
				if (SUCCEEDED(hr))
				{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
					m_pOutput->Out("CCTIDoc", "InitializeConnection",
						"m_pStatus->m_bConnection = true\n");
					m_pOutput->Out("CCTIDoc", "InitializeConnection",
						"m_pPhoneNumberList->clear()\n");
#endif
					m_pStatus->m_bConnection = true;
					m_pPhoneNumberList->clear();
				}
			}
		}
		if (FAILED(hr) && m_pICTICom)
		{
#ifdef OUTPUTDEBUGCREATINGCONNECTION
			m_pOutput->Out("CCTIDoc", "InitializeConnection","Stop CTICom\n");
#endif
#ifdef TESTFILES
			addTestMessage("Stop CTICom");
#endif
			m_pICTICom->Stop();
			m_pICTICom->Release();
			m_pICTICom = NULL;
		}
	}
#ifdef OUTPUTDEBUGCREATINGCONNECTION
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "InitializeConnection","return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "InitializeConnection","return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


int CCTIDoc::readInitFile(CString filename)
{
#ifdef OUTPUTDEBUGREADINITFILE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "readInitFile", 
		"filename = " + filename + ", begin\n");
#endif
	int retval = -1;
	if (m_pInitFile)
	{
#ifdef OUTPUTDEBUGREADINITFILE
		m_pOutput->Out("CCTIDoc", "readInitFile", "m_pInitFile\n");
#endif
		retval = m_pInitFile->readInitFile(filename);
	}
	if (retval == -1)
	{
#ifdef OUTPUTDEBUGREADINITFILE
		m_pOutput->Out("CCTIDoc", "readInitFile", "retval == -1, readInitFile failed\n");
#endif
	}
	else
	{
#ifdef OUTPUTDEBUGREADINITFILE
		char sRetval[10];
		itoa(retval, sRetval, 10);
		CString strRetval = sRetval;
		m_pOutput->Out("CCTIDoc", "readInitFile", 
			"retval = " + strRetval + " != -1,", "readInitFile succeeded\n");
#endif
	}
#ifdef OUTPUTDEBUGREADINITFILE
	m_pOutput->Out("CCTIDoc", "readInitFile", 
		"filename = " + filename + ", end\n");
	m_pOutput->endSeparator();
#endif
	return retval;
}


int CCTIDoc::writeInitFile(CString filename)
{
#ifdef OUTPUTDEBUGWRITEINITFILE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "writeInitFile", 
		"filename = " + filename + ", begin\n");
#endif
	if (m_pInitFile)
	{
#ifdef OUTPUTDEBUGWRITEINITFILE
		m_pOutput->Out("CCTIDoc", "writeInitFile", "m_pInitFile\n");
#endif
		int iRetVal = m_pInitFile->writeInitFile(filename);
#ifdef OUTPUTDEBUGWRITEINITFILE
		char sRetval[10];
		itoa(retval, sRetval, 10);
		CString strRetval = sRetval;
		m_pOutput->Out("CCTIDoc", "writeInitFile", 
			"retval = " + strRetval + "\n");
		m_pOutput->endSeparator();
#endif
		return iRetVal;
	}
	else 
	{
#ifdef OUTPUTDEBUGWRITEINITFILE
		m_pOutput->Out("CCTIDoc", "writeInitFile", "!m_pInitFile -> return -1\n");
		m_pOutput->endSeparator();
#endif
		return -1;
	}
}


HRESULT CCTIDoc::WaitForResponse(bool &bLoginOk, bool &bSetPassword)
{
#ifdef OUTPUTDEBUGWAITFORESPONSE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "WaitForResponse", "begin\n");
#endif
	HRESULT hr = S_OK;
	bool bResponseReceived = false;
	bool bTempLogin = false;
	bool bTempSetPassword = false;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGWAITFORESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForResponse", "m_pStatus\n");
#endif
		for(int i = 0; i < 10; ++i)
		{
#ifdef OUTPUTDEBUGWAITFORESPONSE
			char si[10];
			itoa(i, si, 10);
			CString strI = si;
			m_pOutput->Out("CCTIDoc", "WaitForResponse", "i=" + strI + "\n");
#endif
			bool bConnectionTryingWithSamePassword = false;
			POSITION pos = this->GetFirstViewPosition();
			CCTIFormView *pView = (CCTIFormView*) this->GetNextView(pos);
			if (pView)
			{
#ifdef OUTPUTDEBUGWAITFORESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForResponse", "pView\n");
#endif
				bConnectionTryingWithSamePassword = 
					pView->m_bConnectionTryingWithSamePassword;
			}
			if (bConnectionTryingWithSamePassword)
			{
#ifdef OUTPUTDEBUGWAITFORESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForResponse", 
					"bConnectionTryingWithSamePassword\n");
#endif
				Sleep(500);
			}
			else
			{
#ifdef OUTPUTDEBUGWAITFORESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForResponse", 
					"!bConnectionTryingWithSamePassword\n");
#endif
				Sleep(2000);
			}
			m_pStatus->GetLoginInfo(bResponseReceived, bTempLogin, bTempSetPassword);
			if (bResponseReceived)
			{
#ifdef OUTPUTDEBUGWAITFORESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForResponse", "bResponseReceived\n");
#endif
				bLoginOk = bTempLogin;
				bSetPassword = bTempSetPassword;
				break;
			}
		}	 
		if (!bResponseReceived)
		{
#ifdef OUTPUTDEBUGWAITFORESPONSE
			m_pOutput->Out("CCTIDoc", "WaitForResponse", "!bResponseReceived\n");
#endif
			hr = E_FAIL;
		}
	}
	else
	{
#ifdef OUTPUTDEBUGWAITFORESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForResponse", "!m_pStatus\n");
#endif
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGWAITFORESPONSE
	if (bLoginOk)
	{
		if (bSetPassword)
		{
			m_pOutput->Out("CCTIDoc", "WaitForResponse", 
				"bLoginOk = true, bSetPassword = true\n");
		}
		else
		{
			m_pOutput->Out("CCTIDoc", "WaitForResponse", 
				"bLoginOk = true, bSetPassword = false\n");
		}
	}
	else
	{
		if (bSetPassword)
		{
			m_pOutput->Out("CCTIDoc", "WaitForResponse", 
				"bLoginOk = false, bSetPassword = true\n");
		}
		else
		{
			m_pOutput->Out("CCTIDoc", "WaitForResponse", 
				"bLoginOk = false, bSetPassword = false\n");
		}
	}
	m_pOutput->Out("CCTIDoc", "WaitForResponse", "end\n");
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::WaitForPingResponse(bool &bResponseCome)
{
#ifdef OUTPUTDEBUGWAITFORESPONSE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "WaitForPingResponse", "begin\n");
#endif
	HRESULT hr = S_OK;
	bool bWaitTooLong = false;
	int iCycle = 0;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGWAITFORESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForPingResponse", "m_pStatus\n");
#endif
		while ((!bResponseCome) && (!bWaitTooLong))
		{
#ifdef OUTPUTDEBUGWAITFORESPONSE
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"(!bResponseCome) && (!bWaitTooLong)\n");
#endif
			++iCycle;
			if (iCycle > 10) // 1 seconds waiting limit
			{
				bWaitTooLong = true;
#ifdef OUTPUTDEBUGWAITFORESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForPingResponse", "Wait too long\n");
#endif
			}
			else
			{
				m_pStatus->GetPingResponse(bResponseCome);
				if (!bResponseCome)
				{
#ifdef OUTPUTDEBUGWAITFORESPONSE
					m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
						"!bResponseCome -> Sleep(100)\n");
#endif
					Sleep(100);
				}
			}
		}	 
		if (bWaitTooLong)
		{
#ifdef OUTPUTDEBUGWAITFORESPONSE
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"bWaitTooLong -> hr = E_FAIL\n");
#endif
			hr = E_FAIL;
		}
	}
	else
	{
#ifdef OUTPUTDEBUGWAITFORESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
			"!m_pStatus -> hr = E_FAIL\n");
#endif
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGWAITFORESPONSE
	if (SUCCEEDED(hr))
	{
		if (bResponseCome)
		{
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"return succeeded, bResponseCome = true\n");
		}
		else
		{
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"return succeeded, bResponseCome = false\n");
		}
	}
	else
	{
		if (bResponseCome)
		{
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"return failed, bResponseCome = true\n");
		}
		else
		{
			m_pOutput->Out("CCTIDoc", "WaitForPingResponse", 
				"return failed, bResponseCome = false\n");
		}
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::WaitForChangePasswordResponse(bool& bResponseCome, bool& bOk)
{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", "begin\n");
#endif
	HRESULT hr = S_OK;
	bool bHold = false;
	bOk = false;
	bool bWaitTooLong = false;
	int iCycle = 0;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", "m_pStatus\n");
#endif
		while ((!bResponseCome) && (!bWaitTooLong))
		{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
			m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
				"(!bResponseCome) && (!bWaitTooLong)\n");
#endif
			++iCycle;
			if (iCycle > 50) // 5 seconds waiting limit
			{
				bWaitTooLong = true;
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"iCycle > 50 -> Wait too long\n");
#endif
			}
			else
			{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"iCycle <= 50\n");
#endif
				m_pStatus->getChangePasswordStatus(bResponseCome, bOk);
				if (!bResponseCome)
				{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
					m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
						"!bResponseCome\n");
#endif
					Sleep(100);
				}
			}
		}	 
		if (bWaitTooLong)
		{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
			m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
				"bWaitTooLong -> hr = E_FAIL\n");
#endif
			hr = E_FAIL;
		}
	}
	else
	{
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
		m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
			"!m_pStatus -> hr = E_FAIL\n");
#endif
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGWAITFORCHANGEPASSWORDRESPONSE
	if (SUCCEEDED(hr))
	{
		if (bResponseCome)
		{
			if (bOk)
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return succeeded, bResponseCome = true, bOk = true\n");
			}
			else
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return succeeded, bResponseCome = true, bOk = false\n");
			}
		}
		else
		{
			if (bOk)
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return succeeded, bResponseCome = false, bOk = true\n");
			}
			else
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return succeeded, bResponseCome = false, bOk = false\n");
			}
		}
	}
	else
	{
		if (bResponseCome)
		{
			if (bOk)
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return failed, bResponseCome = true, bOk = true\n");
			}
			else
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return failed, bResponseCome = true, bOk = false\n");
			}
		}
		else
		{
			if (bOk)
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return failed, bResponseCome = false, bOk = true\n");
			}
			else
			{
				m_pOutput->Out("CCTIDoc", "WaitForChangePasswordResponse", 
					"return failed, bResponseCome = false, bOk = false\n");
			}
		}
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc commands

HRESULT CCTIDoc::sendLoginCommand(char* provider, char* userid, char* password)
{
#ifdef OUTPUTDEBUGSENDLOGINCOMMAND
	m_pOutput->beginSeparator();
	CString strProvider = provider;
	CString strUserId = userid;
	CString strPassword = password;
	m_pOutput->Out("CCTIDoc", "sendLoginCommand", 
		"begin, provider = " + strProvider + ", userid = " + strUserId +
		", password = " + strPassword + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDLOGINCOMMAND
		m_pOutput->Out("CCTIDoc", "sendLoginCommand", "m_pCommand\n");
#endif
		m_pCommand->createLoginCommand(provider, userid, password, message);
#ifdef OUTPUTDEBUGSENDLOGINCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendLoginCommand", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDLOGINCOMMAND
			m_pOutput->Out("CCTIDoc", "sendLoginCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
	}
#ifdef OUTPUTDEBUGSENDLOGINCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendLoginCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendLoginCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendGetPhonebookCommand()
{
#ifdef OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", "begin\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND
		m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", "m_pCommand\n");
#endif
		m_pCommand->createGetPhoneBookCommand(message);
#ifdef OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND
			m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
	}
#ifdef OUTPUTDEBUGSENDGETPHONEBOOKCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendGetPhonebookCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendGetHistoryCommand()
{
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", "begin\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
		m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", "m_pCommand\n");
#endif
		m_pCommand->createGetHistoryCommand(message);
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
			m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
			if (SUCCEEDED(hr))
			{
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
				m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", 
					"SUCCEEDED(hr) -> m_pStatus->m_bHistoryNeedsUpdating = false",
					"m_pStatus->m_bHistoryCompleted = false",
					"m_pCallList->clear()\n");
#endif
				m_pStatus->m_bHistoryNeedsUpdating = false;
				m_pStatus->m_bHistoryCompleted = false;
				m_pCallList->clear();
			}
		}
	}
#ifdef OUTPUTDEBUGSENDGETHISTORYCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendGetUnansweredCommand()
{
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", "begin\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
		m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", "m_pCommand\n");
#endif
		m_pCommand->createGetUnansweredCommand(message);
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendGetHistoryCommand", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
			m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
			if (SUCCEEDED(hr))
			{
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
				m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", 
					"SUCCEEDED(hr) -> m_pStatus->m_bHistoryNeedsUpdating = false",
					"m_pStatus->m_bHistoryCompleted = false",
					"m_pCallList->clear()\n");
#endif
				m_pStatus->m_bHistoryNeedsUpdating = false;
				m_pStatus->m_bHistoryCompleted = false;
				m_pCallList->clear();
			}
		}
	}
#ifdef OUTPUTDEBUGSENDGETUNANSWEREDCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendGetUnansweredCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendGetTransfersCommand()
{
#ifdef OUTPUTDEBUGSENDGETTRANSFERSCOMMAND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", "begin\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDGETTRANSFERSCOMMAND
		m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", "m_pCommand\n");
#endif
		m_pCommand->createGetTransfersCommand(message);
#ifdef OUTPUTDEBUGSENDGETTRANSFERSCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDGETTRANSFERSCOMMAND
			m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
	}
#ifdef OUTPUTDEBUGSENDGETTRANSFERSCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendGetTransfersCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendHoldCommand(int iLine)
{
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	m_pOutput->Out("CCTIDoc", "sendHoldCommand", 
		"begin, iLine = " + strLine + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
		m_pOutput->Out("CCTIDoc", "sendHoldCommand", "m_pLines && m_pCommand\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
			m_pOutput->Out("CCTIDoc", "sendHoldCommand", "pLine\n");
#endif
			CString callRef = pLine->getCallRef();
			if (pLine->getCurrent() || pLine->getHeld())
			{
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
				m_pOutput->Out("CCTIDoc", "sendHoldCommand", 
					"pLine->getCurrent() || pLine->getHeld(), callRef = " 
					+ callRef + "\n");
#endif
				m_pCommand->createHoldCommand(callRef.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendHoldCommand", 
					"message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
					m_pOutput->Out("CCTIDoc", "sendHoldCommand", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
				else
				{
					hr = E_FAIL;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
#ifdef OUTPUTDEBUGSENDHOLDCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendHoldCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendHoldCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendHoldOffCommand(int iLine)
{
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", 
		"begin, iLine = " + strLine + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
		m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", "m_pLines && m_pCommand\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
			m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", "pLine\n");
#endif
			CString callRef = pLine->getCallRef();
			if (pLine->getHold())
			{
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
				m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", 
					"pLine->getHold(), callRef = " 	+ callRef + "\n");
#endif
				m_pCommand->createHoldOffCommand(callRef.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", 
					"message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
					m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
#ifdef OUTPUTDEBUGSENDHOLDOFFCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendHoldOffCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendAnswerCommand(int iLine)
{
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	m_pOutput->Out("CCTIDoc", "sendAnswerCommand", 
		"begin, iLine = " + strLine + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
		m_pOutput->Out("CCTIDoc", "sendAnswerCommand", "m_pLines && m_pCommand\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
			m_pOutput->Out("CCTIDoc", "sendAnswerCommand", "pLine\n");
#endif
			CString callRef = pLine->getCallRef();
			if (pLine->getComing())
			{
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
				m_pOutput->Out("CCTIDoc", "sendAnswerCommand", 
					"pLine->getComing(), callRef = " + callRef + "\n");
#endif
				m_pCommand->createAnswerOwnCommand(callRef.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendAnswerCommand", 
					"message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
					m_pOutput->Out("CCTIDoc", "sendAnswerCommand", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
#ifdef OUTPUTDEBUGSENDANSWERCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendAnswerCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendAnswerCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendAnswerRepresentativeCommand(int iRep)
{
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
		"begin, iRep = " + strRep + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
			"m_pRepresentatives && m_pCommand\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", "pRep\n");
#endif
			CString callRef = pRep->getAlertingCallRef();
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
				"alerting callRef = " + callRef + "\n");
#endif
			if (callRef != "")
			{
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
				m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
					"alerting callRef != \"\"\n");
#endif
				m_pCommand->createCallAnswerCommand(callRef.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
					"message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
					m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", 
						"m_pICTIConnection -> SendCTIMessage, ",
						"m_bRepresentativeAnswered = TRUE, ",
						"m_callRefOfAnsweredRepresentative = " + callRef + "\n");
#endif
					hr = SendCTIMessage(message);
					m_bRepresentativeAnswered = TRUE;
					m_callRefOfAnsweredRepresentative = callRef;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDANSWERREPRESENTATIVECOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendAnswerRepresentativeCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendRedirect(int iLine, CString target)
{
#ifdef OUTPUTDEBUGSENDREDIRECT
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	m_pOutput->Out("CCTIDoc", "sendRedirect", 
		"begin, iLine = " + strLine + ", target = " + target + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pPhoneNumberList && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDREDIRECT
		m_pOutput->Out("CCTIDoc", "sendRedirect", 
			"m_pLines && m_pPhoneNumberList && m_pCommand\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
			CString callRef = pLine->getCallRef();
#ifdef OUTPUTDEBUGSENDREDIRECT
			m_pOutput->Out("CCTIDoc", "sendRedirect", "pLine, callRef = " + callRef + "\n");
#endif
			if (pLine->getComing())
			{
#ifdef OUTPUTDEBUGSENDREDIRECT
				m_pOutput->Out("CCTIDoc", "sendRedirect", "pLine->getComing()\n");
#endif
				m_pCommand->createAlertingRedirectCommand(callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREDIRECT
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendRedirect", 
					"alertingRedirectCommand, message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDREDIRECT
					m_pOutput->Out("CCTIDoc", "sendRedirect", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else if (pLine->getCurrent())
			{
#ifdef OUTPUTDEBUGSENDREDIRECT
				m_pOutput->Out("CCTIDoc", "sendRedirect", "pLine->getCurrent()\n");
#endif
				m_pCommand->createCallRedirectCommand(callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREDIRECT
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendRedirect", 
					"CallRedirectCommand, message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDREDIRECT
					m_pOutput->Out("CCTIDoc", "sendRedirect", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDREDIRECT
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendRedirect", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendRedirect", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendRedirectRepresentativeAlerting(int iRep, CString target)
{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
		"begin, iRep = " + strRep + ", target = " + target + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand && m_pPhoneNumberList)
	{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
			"m_pRepresentatives && m_pCommand && m_pPhoneNumberList\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
			CString callRef = pRep->getAlertingCallRef();
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
			m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
				"pRep, alertingCallRef = " + callRef + "\n");
#endif
			if (callRef != "")
			{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
				m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
					"callRef != \"\"\n");
#endif
				m_pCommand->createAlertingRedirectCommand(
					callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
					"AlertingRedirectCommand, message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
					m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVEALERTING
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeAlerting", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendRedirectRepresentativeCurrent(int iRep, CString target)
{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
		"begin, iRep = " + strRep + ", target = " + target + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives && m_pCommand && m_pPhoneNumberList)
	{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
			"m_pRepresentatives && m_pCommand && m_pPhoneNumberList\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (pRep)
		{
			CString callRef = pRep->getTalkingCallRef();
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
			m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
				"pRep, alertingCallRef = " + callRef + "\n");
#endif
			if (callRef != "")
			{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
				m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
					"callRef != \"\"\n");
#endif
				m_pCommand->createCallRedirectCommand(
					callRef.GetBuffer(0), 
					target.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
					"CallRedirectCommand, message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
					m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDREDIRECTREPRESENTATIVECURRENT
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendRedirectRepresentativeCurrent", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}



HRESULT CCTIDoc::sendCallCommand(char* number, int iLine)
{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	CString strNumber = number;
	m_pOutput->Out("CCTIDoc", "sendCallCommand", 
		"begin, iLine = " + strLine + ", number = " + strNumber + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines && m_pPhoneNumberList && m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
		m_pOutput->Out("CCTIDoc", "sendCallCommand", 
			"m_pLines && m_pPhoneNumberList && m_pCommand\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine)
		{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
			m_pOutput->Out("CCTIDoc", "sendCallCommand", "pLine\n");
#endif
			if (pLine->getFree())
			{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
				m_pOutput->Out("CCTIDoc", "sendCallCommand", "pLine->getFree()",
					"-> setNumber(" + strNumber + "), setOwnCall(true)\n");
#endif
				pLine->setNumber(number);
				pLine->setOwnCall(true);
				if (m_pOlderCalls)
				{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
					m_pOutput->Out("CCTIDoc", "sendCallCommand", "m_pOlderCalls",
						"-> m_pOlderCalls->add(" + strNumber + ")\n");
#endif
					m_pOlderCalls->add(number);
				}
				CString terminal = pLine->getNumber();
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
				m_pOutput->Out("CCTIDoc", "sendCallCommand", 
					"terminal = " + terminal + "\n");
#endif
				m_pCommand->createCallCommand(terminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "sendCallCommand", 
					"CallCommand, message = " + strMessage + "\n");
#endif
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
					m_pOutput->Out("CCTIDoc", "sendCallCommand", 
						"m_pICTIConnection -> SendCTIMessage, updateView()\n");
#endif
					hr = SendCTIMessage(message);
					updateView();
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDCALLCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendCallCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendCallCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendEndCommand(int iLine)
{
#ifdef OUTPUTDEBUGSENDENDCOMMAND
	m_pOutput->beginSeparator();
	char sLine[10];
	itoa(iLine, sLine, 10);
	CString strLine = sLine;
	m_pOutput->Out("CCTIDoc", "sendEndCommand", 
		"begin, iLine = " + strLine + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pLines)
	{
#ifdef OUTPUTDEBUGSENDENDCOMMAND
		m_pOutput->Out("CCTIDoc", "sendEndCommand", "m_pLines\n");
#endif
		CLine* pLine = m_pLines->getLine(iLine);
		if (pLine && m_pCommand)
		{
#ifdef OUTPUTDEBUGSENDENDCOMMAND
			m_pOutput->Out("CCTIDoc", "sendEndCommand", "pLine && m_pCommand\n");
#endif
			if (!pLine->getFree())
			{
				CString callRef = pLine->getCallRef();
#ifdef OUTPUTDEBUGSENDENDCOMMAND
				m_pOutput->Out("CCTIDoc", "sendEndCommand", 
					"!pLine->getFree(), callRef = " + callRef + "\n");
#endif
				if (callRef != "")
				{
					m_pCommand->createEndCallCommand(callRef.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDENDCOMMAND
					CString strMessage = message;
					m_pOutput->Out("CCTIDoc", "sendEndCommand", 
						"!pLine->getFree(), callRef != \"\" -> message = " 
						+ strMessage + "\n");
#endif
				}
				else
				{
					CString terminal = pLine->getNumber();
					m_pCommand->createEndCallCommandWithTerminal(
						terminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDENDCOMMAND
					CString strMessage = message;
					m_pOutput->Out("CCTIDoc", "sendEndCommand", 
						"!pLine->getFree(), callRef == \"\", terminal = " + terminal + 
						" -> message = " + strMessage + "\n");
#endif
				}
				if (m_pICTIConnection)
				{
#ifdef OUTPUTDEBUGSENDENDCOMMAND
					m_pOutput->Out("CCTIDoc", "sendEndCommand", 
						"m_pICTIConnection -> SendCTIMessage\n");
#endif
					hr = SendCTIMessage(message);
				}
				else
				{
					hr = E_FAIL;
				}
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDENDCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendEndCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendEndCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return  hr;
}


HRESULT CCTIDoc::sendChangePasswordCommand(char* oldPassword, char* newPassword)
{
#ifdef OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND
	m_pOutput->beginSeparator();
	CString strOldPassword = oldPassword;
	CString strNewPassword = newPassword;
	m_pOutput->Out("CCTIDoc", "sendChangePasswordCommand", 
		"begin, oldPassword = " + strOldPassword + ", newPassword = " 
		+ strNewPassword + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createSetPasswordCommand(oldPassword, newPassword, message);
#ifdef OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendChangePasswordCommand", 
			"m_pCommand, message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND
			m_pOutput->Out("CCTIDoc", "sendChangePasswordCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDCHANGEPASSWORDCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendChangePasswordCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendChangePasswordCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendGetDetailsCommand(char* terminal)
{
#ifdef OUTPUTDEBUGSENDGETDETAILSCOMMAND
	m_pOutput->beginSeparator();
	CString strTerminal = terminal;
	m_pOutput->Out("CCTIDoc", "sendGetDetailsCommand", 
		"begin, terminal = " + strTerminal + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
		m_pCommand->createGetDetailsCommand(terminal, message);
#ifdef OUTPUTDEBUGSENDGETDETAILSCOMMAND
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendGetDetailsCommand", 
			"m_pCommand, message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDGETDETAILSCOMMAND
			m_pOutput->Out("CCTIDoc", "sendGetDetailsCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDGETDETAILSCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendGetDetailsCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendGetDetailsCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendAddRepresentativeCommand(int iRep)
{
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", 
		"begin, iRep = " + strRep + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", 
			"m_pRepresentatives\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", 
				"RepName: " + repName + " RepTerminal: " + repTerminal + "\n");
#endif
			m_pCommand->createListenCommand(repTerminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", 
				"m_pCommand, message = " + strMessage + "\n");
#endif
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
				m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDADDREPRESENTATIVECOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendAddRepresentativeCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendAddRingingRepresentativeCommand(int iRep)
{
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", 
		"begin, iRep = " + strRep + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", 
			"m_pRepresentatives\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", 
				"RepName: " + repName + " RepTerminal: " + repTerminal + "\n");
#endif
			m_pCommand->createListenWithRingingCommand(repTerminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", 
				"m_pCommand, message = " + strMessage + "\n");
#endif
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
				m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDADDRINGINGREPRESENTATIVECOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendAddRingingRepresentativeCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendRemoveRepresentativeCommand(int iRep)
{
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", 
		"begin, iRep = " + strRep + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", 
			"m_pRepresentatives\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		if (m_pCommand && pRep)
		{
			CString repName = pRep->getName();
			CString repTerminal = pRep->getTerminal();
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", 
				"m_pCommand && pRep, RepName: " + repName + " RepTerminal: " 
				+ repTerminal + "\n");
#endif
			m_pCommand->createListenOffCommand(repTerminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", 
				"message = " + strMessage + "\n");
#endif
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
				m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDREMOVEREPRESENTATIVECOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendRemoveRepresentativeCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendRemoveRingingRepresentativeCommand(int iRep)
{
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
	m_pOutput->beginSeparator();
	char sRep[10];
	itoa(iRep, sRep, 10);
	CString strRep = sRep;
	m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
		"begin, iRep = " + strRep + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
		"m_pRepresentatives\n");
#endif
		CRepresentative* pRep = m_pRepresentatives->getRepresentative(iRep);
		CString repName = pRep->getName();
		CString repTerminal = pRep->getTerminal();
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
		m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
			"RepName: " + repName + " RepTerminal: " + repTerminal + "\n");
#endif
		if (m_pCommand)
		{
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
			m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
				"m_pCommand\n");
#endif
			m_pCommand->createListenWithRingingOffCommand(repTerminal.GetBuffer(0), message);
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
				"message = " + strMessage + "\n");
#endif
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
				m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDREMOVERINGINGREPRESENTATIVECOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendRemoveRingingRepresentativeCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendSetTransfer(int type, char* number)
{
#ifdef OUTPUTDEBUGSENDSETTRANSFER
	m_pOutput->beginSeparator();
	CString strType = stype;
	CString strNumber = number;
	m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
		"begin, type = " + strType + ", number = " + strNumber + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	CString cNumber = number;
	if (m_pCommand && m_pHelper)
	{
#ifdef OUTPUTDEBUGSENDSETTRANSFER
		m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
			"m_pCommand && m_pHelper\n");
#endif
		CString terminal = m_pHelper->getTerminal(cNumber);
#ifdef OUTPUTDEBUGSENDSETTRANSFER
		m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
			"terminal = " + terminal + "\n");
#endif
		m_pCommand->createSetTransferCommand(type, number, message);
#ifdef OUTPUTDEBUGSENDSETTRANSFER
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
			"message = " + strMessage + "\n");
#endif
		if (strlen(message) > 0)
		{
#ifdef OUTPUTDEBUGSENDSETTRANSFER
			m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
				"strlen(message) > 0\n");
#endif
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGSENDSETTRANSFER
				m_pOutput->Out("CCTIDoc", "sendSetTransfer", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				hr = SendCTIMessage(message);
			}
			else
			{
				hr = E_FAIL;
			}
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDSETTRANSFER
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendSetTransfer", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendSetTransfer", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendJoinCalls(char* callRef1, char* callRef2)
{
#ifdef OUTPUTDEBUGSENDJOINCALLS
	m_pOutput->beginSeparator();
	CString strCallRef1 = callRef1;
	CString strCallRef2 = callRef2;
	m_pOutput->Out("CCTIDoc", "sendJoinCalls", 
		"begin, callRef1 = " + strCallRef1 
		+ ", callref2 = " + strCallRef2 + "\n");
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDJOINCALLS
		m_pOutput->Out("CCTIDoc", "sendJoinCalls", 
			"m_pCommand\n");
#endif
		m_pCommand->createJoinCallsCommand(callRef1, callRef2, message);
#ifdef OUTPUTDEBUGSENDJOINCALLS
		CString strMessage = message;
		m_pOutput->Out("CCTIDoc", "sendJoinCalls", 
			"message = " + strMessage + "\n");
#endif
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDJOINCALLS
			m_pOutput->Out("CCTIDoc", "sendJoinCalls", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDJOINCALLS
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendJoinCalls", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendJoinCalls", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendPing()
{
#ifdef OUTPUTDEBUGSENDPING
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "sendPing\n");
#endif
	HRESULT hr = E_FAIL;
	char message[80];
	strcpy(message, PING);
#ifdef OUTPUTDEBUGSENDPING
	CString strMessage = message;
	m_pOutput->Out("CCTIDoc", "sendPing", 
		"message = " + strMessage + "\n");
#endif
	if (m_pICTIConnection)
	{
#ifdef OUTPUTDEBUGSENDPING
		m_pOutput->Out("CCTIDoc", "sendPing", 
			"m_pICTIConnection -> SendCTIMessage\n");
#endif
		hr = SendCTIMessage(message);
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDPING
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendPing", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendPing", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::sendDNDCommand(bool bDND)
{
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
	m_pOutput->beginSeparator();
	if (bDND)
	{
		m_pOutput->Out("CCTIDoc", "sendDNDCommand", "bDND = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendDNDCommand", "bDND = false\n");
	}
#endif
	HRESULT hr = E_FAIL;
	char message[500];
	if (m_pCommand)
	{
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
		m_pOutput->Out("CCTIDoc", "sendDNDCommand", "m_pCommand\n");
#endif
		if (bDND)
		{
			m_pCommand->createDNDOnCommand(message);
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendDNDCommand", 
				"bDND -> message = " + strMessage + "\n");
#endif
		}
		else
		{
			m_pCommand->createDNDOffCommand(message);
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
			CString strMessage = message;
			m_pOutput->Out("CCTIDoc", "sendDNDCommand", 
				"!bDND -> message = " + strMessage + "\n");
#endif
		}
		if (m_pICTIConnection)
		{
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
			m_pOutput->Out("CCTIDoc", "sendDNDCommand", 
				"m_pICTIConnection -> SendCTIMessage\n");
#endif
			hr = SendCTIMessage(message);
		}
		else
		{
			hr = E_FAIL;
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGSENDDNDCOMMAND
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "sendDNDCommand", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "sendDNDCommand", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


HRESULT CCTIDoc::acquireTransfers()
{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "acquireTransfers, "begin\n");
#endif
	HRESULT hr = E_FAIL;
	bool bGot = false;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
		m_pOutput->Out("CCTIDoc", "acquireTransfers", "m_pStatus\n");
#endif
		m_pStatus->setTransfersGot(false);
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
		m_pOutput->Out("CCTIDoc", "acquireTransfers", "m_pStatus->setTransfersGot(false)\n");
#endif
		if (m_pTransferRules)
		{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
			m_pOutput->Out("CCTIDoc", "acquireTransfers", 
				"m_pTransferRules -> m_pTransferRules->clear()\n");
#endif
			m_pTransferRules->clear();
		}
		hr = sendGetTransfersCommand();
		if (SUCCEEDED(hr))
		{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
			m_pOutput->Out("CCTIDoc", "acquireTransfers", 
				"sendGetTransfersCommand succeeded\n");
#endif
			for(int i = 0; i < 10; ++i)
			{
				Sleep(300);
				m_pStatus->getTransfersGot(bGot);
				if (bGot)
				{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
					m_pOutput->Out("CCTIDoc", "acquireTransfers", 
						"bGot = true\n");
#endif
					hr = S_OK;
					m_pTransferRules->adjust();
					break;
				}
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
				else
				{
					m_pOutput->Out("CCTIDoc", "acquireTransfers", 
						"bGot = false\n");
				}
#endif
			}
			if (!bGot)
			{
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
				m_pOutput->Out("CCTIDoc", "acquireTransfers", 
					"bGot = false -> hr = E_FAIL\n");
#endif
				hr = E_FAIL;
			}
		}
		else
		{
		}
	}
	else
	{
		hr = E_FAIL;
	}
#ifdef OUTPUTDEBUGACQUIRETRANSFERS
	if (SUCCEEDED(hr))
	{
		m_pOutput->Out("CCTIDoc", "acquireTransfers", "return succeeded\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "acquireTransfers", "return failed\n");
	}
	m_pOutput->endSeparator();
#endif
	return hr;
}


void CCTIDoc::checkOK(bool bPasswordOK)
{
#ifdef OUTPUTDEBUGCHECKOK
	m_pOutput->beginSeparator();
	if (bPasswordOK)
	{
		m_pOutput->Out("CCTIDoc", "checkOK, "begin, bPasswordOK = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkOK, "begin, bPasswordOK = false\n");
	}
#endif
	informOperationForPing();
	if (bPasswordOK && m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKOK
		m_pOutput->Out("CCTIDoc", "checkOK", 
			"bPasswordOK && m_pStatus -> m_pStatus->setChangePasswordStatus(true)\n");
#endif
		m_pStatus->setChangePasswordStatus(true);
	}
#ifdef OUTPUTDEBUGCHECKOK
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkHook(char* terminal, bool bHook)
{
#ifdef OUTPUTDEBUGCHECKHOOK
	m_pOutput->beginSeparator();
	CString strTerminal = terminal;
	if (bHook)
	{
		m_pOutput->Out("CCTIDoc", "checkHook", 
			"begin, bHook = true, terminal = " + strTerminal + "\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkHook", 
			"begin, bHook = false, terminal = " + strTerminal + "\n"));
	}
#endif
	if (m_pLines && m_pRepresentatives && m_pStatus)
	{
		CString sTerminal = terminal;
#ifdef OUTPUTDEBUGCHECKHOOK
		m_pOutput->Out("CCTIDoc", "checkHook", 
			"m_pLines && m_pRepresentatives && m_pStatus, ",
			"sTerminal = " + sTerminal + "\n");
#endif
		if (m_pStatus->m_terminal == sTerminal)
		{
#ifdef OUTPUTDEBUGCHECKHOOK
			m_pOutput->Out("CCTIDoc", "checkHook", 
				"m_pStatus->m_terminal == sTerminal-> ",
				"m_pStatus->m_bOwnHook = bHook\n");
#endif
			m_pStatus->m_bOwnHook = bHook;
		}
		m_pLines->setHookOfTerminal(sTerminal, bHook);
#ifdef OUTPUTDEBUGCHECKHOOK
		m_pOutput->Out("CCTIDoc", "checkHook", 
			"m_pLines->setHookOfTerminal(sTerminal, bHook)\n");
#endif
		m_pRepresentatives->checkRepresentativeHook(terminal, bHook);
#ifdef OUTPUTDEBUGCHECKHOOK
		m_pOutput->Out("CCTIDoc", "checkHook", 
			"m_pRepresentatives->checkRepresentativeHook(terminal, bHook)\n");
#endif
		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKHOOK
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkTalking(char* terminal, char* callRef, 
	char* transferedNumber)
{
	CString sCallRef = callRef;
	CString sTerminal = terminal;
	CString sTransferedNumber = transferedNumber;
#ifdef OUTPUTDEBUGCHECKTALKING
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "checkTalking", 
		"callRef: " + sCallRef + " ,terminal: " + sTerminal + ",transferedNumber: " + 
		sTransferedNumber + "\n");
#endif
	if (m_pLines && m_pRepresentatives && m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKTALKING
		m_pOutput->Out("CCTIDoc", "checkTalking", 
			"m_pLines && m_pRepresentatives && m_pStatus\n");
#endif
		m_pLines->checkTalking(sCallRef, sTerminal);
#ifdef OUTPUTDEBUGCHECKTALKING
		m_pOutput->Out("CCTIDoc", "checkTalking", 
			"m_pLines->checkTalking(sCallRef, sTerminal)\n");
#endif
		m_pRepresentatives->checkTalkingRepresentative(sTerminal, sCallRef);
#ifdef OUTPUTDEBUGCHECKTALKING
		m_pOutput->Out("CCTIDoc", "checkTalking", 
			"m_pRepresentatives->checkTalkingRepresentative(sTerminal, sCallRef)\n");
#endif
	}
#ifdef OUTPUTDEBUGCHECKTALKING
	m_pOutput->Out("CCTIDoc", "checkTalking" "FinalizeServerOperation\n");
#endif
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGCHECKTALKING
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkAlerting(char* terminal1, char* terminal2, char* callRef,
	char* transferedNumber)
{
	bool bOwnWith;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
	CString sCallRef = callRef;
	CString sTransferedNumber = transferedNumber;
	CString origTransfered = "";
	if (sTransferedNumber)
	{
		origTransfered = sTransferedNumber;
	}
#ifdef OUTPUTDEBUGCHECKALERTING
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "checkAlerting", 
		"callRef: " + sCallRef + " ,terminal1 (alerting): " + sTerminal1 
		+ ",terminal2 (connecting) = " + terminal2 
		+ ",transferedNumber: " + sTransferedNumber + "\n");
#endif
	if (m_pStatus && m_pLines && m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGCHECKALERTING
		m_pOutput->Out("CCTIDoc", "checkAlerting", 
			"m_pStatus && m_pLines && m_pRepresentatives\n");
#endif
		CString foreignTerminal = 
			m_pLines->getForeignTerminal(sTerminal1, sTerminal2, bOwnWith);
#ifdef OUTPUTDEBUGCHECKALERTING
		m_pOutput->Out("CCTIDoc", "checkAlerting", 
			"foreignTerminal = " + foreignTerminal + "\n");
#endif
		if (sTransferedNumber == m_pStatus->m_terminal)
		{
#ifdef OUTPUTDEBUGCHECKALERTING
			m_pOutput->Out("CCTIDoc", "checkAlerting", 
				"sTransferedNumber == m_pStatus->m_terminal ",
				"-> checkTransferingFromThisLine\n");
#endif
			// moving from line of this terminal
			// call is moved to sTerminal2, and moved from sMovedNumber
			CString empty = ""; // Number of the line is not changed.
			m_pLines->checkTransferingFromThisLine(sCallRef, sTerminal2, empty);
		}
		else if (bOwnWith && (foreignTerminal != ""))
		{
#ifdef OUTPUTDEBUGCHECKALERTING
			m_pOutput->Out("CCTIDoc", "checkAlerting", 
				"sTransferedNumber != m_pStatus->m_terminal, bOwnWith, ",
				"foreignTerminal != \"\"\n");
#endif
			if (sTerminal1 == m_pStatus->m_terminal)
			{
#ifdef OUTPUTDEBUGCHECKALERTING
				m_pOutput->Out("CCTIDoc", "checkAlerting", 
					"sTerminal1 == m_pStatus->m_terminal ",
					"-> checkAlertingThisTerminal\n");
#endif
				if (m_pLines->checkAlertingThisTerminal(sCallRef, sTerminal2, 
					sTransferedNumber))
				{
#ifdef OUTPUTDEBUGCHECKALERTING
					m_pOutput->Out("CCTIDoc", "checkAlerting", "setViewAsTopMostWindow\n");
#endif
					setViewAsTopMostWindow();
				}
			}
			else if (sTerminal2 == m_pStatus->m_terminal)
			{
#ifdef OUTPUTDEBUGCHECKALERTING
				m_pOutput->Out("CCTIDoc", "checkAlerting", 
					"sTerminal1 != m_pStatus->m_terminal && ",
					"sTerminal2 == m_pStatus->m_terminal",
					"-> SetCallRefOfOwnCall\n");
#endif
				m_pLines->SetCallRefOfOwnCall(foreignTerminal, sCallRef, sTransferedNumber);
			}
		}
#ifdef OUTPUTDEBUGCHECKALERTING
		m_pOutput->Out("CCTIDoc", "checkAlerting", 
			"->m_pRepresentatives->checkAlertingRepresentative\n");
#endif
		if (m_pRepresentatives->checkAlertingRepresentative(sTerminal1, sTerminal2, 
			sCallRef, m_pStatus->m_iTime))
		{
#ifdef OUTPUTDEBUGCHECKALERTING
			m_pOutput->Out("CCTIDoc", "checkAlerting", "setViewAsTopMostWindow\n");
#endif
			setViewAsTopMostWindow();
		}
		if (m_bRepresentativeAnswered && 
			(sCallRef == m_callRefOfAnsweredRepresentative) && m_pCommand)
		{
#ifdef OUTPUTDEBUGCHECKALERTING
			m_pOutput->Out("CCTIDoc", "checkAlerting", 
				"m_bRepresentativeAnswered && sCallRef == ",
				"m_callRefOfAnsweredRepresentative && m_pCommand",
				"-> createAnswerOwnCommand\n");
#endif
			char message[500];
			m_pCommand->createAnswerOwnCommand(sCallRef.GetBuffer(0), message);
			if (m_pICTIConnection)
			{
#ifdef OUTPUTDEBUGCHECKALERTING
				m_pOutput->Out("CCTIDoc", "checkAlerting", 
					"m_pICTIConnection -> SendCTIMessage\n");
#endif
				HRESULT hr = SendCTIMessage(message);
#ifdef OUTPUTDEBUGCHECKALERTING
				CString strMessage = message;
				m_pOutput->Out("CCTIDoc", "checkAlerting", 
					"message = " + strMessage + "\n");
#endif
			}
			m_bRepresentativeAnswered = FALSE;
			m_callRefOfAnsweredRepresentative = "";
#ifdef OUTPUTDEBUGCHECKALERTING
			m_pOutput->Out("CCTIDoc", "checkAlerting", 
				"m_bRepresentativeAnswered = FALSE, ",
				"m_callRefOfAnsweredRepresentative = \"\"\n");
#endif
		}
#ifdef OUTPUTDEBUGCHECKALERTING
		m_pOutput->Out("CCTIDoc", "checkAlerting", 
			"->FinalizeServerOperation\n");
#endif
		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKALERTING
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkConnecting(char* terminal1, char* terminal2, char* callRef, 
	char* transferedNumber)
{
	bool bOwnWith;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
	CString sCallRef = callRef;
	CString sTransferedNumber = transferedNumber;
#ifdef OUTPUTDEBUGCHECKCONNECTING
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "checkConnecting", 
		"callRef: " + sCallRef + " ,terminal1 (connecting): " + sTerminal1 
		+ ",terminal2 (alerting) = " + terminal2 
		+ ",transferedNumber: " + sTransferedNumber + "\n");
#endif
	if (m_pStatus && m_pLines && m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGCHECKCONNECTING
		m_pOutput->Out("CCTIDoc", "checkConnecting", 
			"m_pStatus && m_pLines && m_pRepresentatives\n");
#endif
		if (sTransferedNumber == m_pStatus->m_terminal)
		{
#ifdef OUTPUTDEBUGCHECKCONNECTING
			m_pOutput->Out("CCTIDoc", "checkConnecting", 
				"sTransferedNumber == m_pStatus->m_terminal",
				"-> m_pLines->checkTransferingFromThisLine\n");
#endif
			// moving from line of this terminal
			m_pLines->checkTransferingFromThisLine(sCallRef, sTerminal2, 
				sTerminal1);
		}
		else if (sTerminal1 == m_pStatus->m_terminal)
		{
#ifdef OUTPUTDEBUGCHECKCONNECTING
			m_pOutput->Out("CCTIDoc", "checkConnecting", 
				"sTransferedNumber != m_pStatus->m_terminal && ",
				"sTerminal1 == m_pStatus->m_terminal\n");
#endif
			CString foreignTerminal = 
				m_pLines->getForeignTerminal(sTerminal1, sTerminal2, bOwnWith);
#ifdef OUTPUTDEBUGCHECKCONNECTING
			m_pOutput->Out("CCTIDoc", "checkConnecting", 
				"foreignTerminal = " + foreignTerminal + 
				" -> SetCallRefOfOwnCall\n");
#endif
			m_pLines->SetCallRefOfOwnCall(foreignTerminal, sCallRef, sTransferedNumber);
		}
		else
		{
#ifdef OUTPUTDEBUGCHECKCONNECTING
			m_pOutput->Out("CCTIDoc", "checkConnecting", 
				"sTransferedNumber != m_pStatus->m_terminal && sTerminal1",
				"!= m_pStatus->m_terminal -> checkTransferingToThisLine\n");
#endif
			m_pLines->checkTransferingToThisLine(sCallRef, sTerminal2, 
				sTransferedNumber);
			if (sTerminal2 == m_pStatus->m_terminal)
			{
#ifdef OUTPUTDEBUGCHECKCONNECTING
				m_pOutput->Out("CCTIDoc", "checkConnecting", 
					"sTerminal2 == m_pStatus->m_terminal"
					"-> checkComingCall\n");
#endif
				m_pLines->checkComingCall(sCallRef, sTerminal1, 
					sTransferedNumber);
			}
		}
#ifdef OUTPUTDEBUGCHECKCONNECTING
		m_pOutput->Out("CCTIDoc", "checkConnecting", 
			"->m_pRepresentatives->checkAlertingRepresentative\n");
#endif
		m_pRepresentatives->checkAlertingRepresentative(sTerminal2, sTerminal1, 
			sCallRef, m_pStatus->m_iTime);
#ifdef OUTPUTDEBUGCHECKCONNECTING
		m_pOutput->Out("CCTIDoc", "checkConnecting", 
			"->m_pRepresentatives->checkConnectingRepresentative\n");
#endif
		m_pRepresentatives->checkConnectingRepresentative(sTerminal1, sCallRef);
#ifdef OUTPUTDEBUGCHECKCONNECTING
		m_pOutput->Out("CCTIDoc", "checkConnecting", 
			"->FinalizeServerOperation\n");
#endif
		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKCONNECTING
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkTerminated(char* terminal, char* callRef)
{
	bool bOwnWith = false;
	CString sTerminal = terminal;
	CString sCallRef = callRef;
#ifdef OUTPUTDEBUGCHECKTERMINATED
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "checkTerminated", 
		"terminal: " + sTerminal + ", callRef: " + sCallRef + "\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKTERMINATED
		m_pOutput->Out("CCTIDoc", "checkTerminated", "m_pStatus\n");
#endif
		if (m_pLines)
		{
#ifdef OUTPUTDEBUGCHECKTERMINATED
			m_pOutput->Out("CCTIDoc", "checkTerminated", 
				"m_pLines -> m_pLines->checkTerminated\n");
#endif
			bool bComingTerminated = false;
			m_pLines->checkTerminated(sCallRef, bComingTerminated);
		}
		if (m_pRepresentatives)
		{
#ifdef OUTPUTDEBUGCHECKTERMINATED
			m_pOutput->Out("CCTIDoc", "checkTerminated", 
				"m_pRepresentatives->checkDisconnectedRepresentative\n");
#endif
			m_pRepresentatives->checkDisconnectedRepresentative(sTerminal, sCallRef);
		}
#ifdef OUTPUTDEBUGCHECKTERMINATED
		m_pOutput->Out("CCTIDoc", "checkTerminated", 
			"->FinalizeServerOperation\n");
#endif
		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKTERMINATED
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkConnectionFailed(char* terminal1, char* terminal2, char* callRef,
    char* reason)
{
	int iLine;
	CString sCallRef = callRef;
	CString sTerminal1 = terminal1;
	CString sTerminal2 = terminal2;
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
	m_pOutput->beginSeparator();
	CString sReason = reason;
	m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
		"callRef: " + sCallRef + " ,terminal1: " + sTerminal1 
		+ " ,terminal2: " + sTerminal2 + " ,reason: " + sReason + "\n");
#endif
	if (m_pLines && m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
		m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
			"m_pLines && m_pStatus\n");
#endif
		iLine = m_pLines->findFirstNotCurrentLine(sCallRef, sTerminal2);
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
		char sLine[10];
		itoa(iLine, sLine, 10);
		CString strLine = sLine;
		m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
			"m_pLines->findFirstNotCurrentLine -> iLine = " + strLine + "\n");
#endif
		if (iLine != -1)
		{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
			m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
				"iLine != -1\n");
#endif
			CLine* pLine = m_pLines->getLine(iLine);
			if (pLine)
			{
				pLine->setCallRef(sCallRef);
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
				m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
					"pLine-> setCallRef: " + sCallRef + "\n");
#endif
				if (sTerminal1 == m_pStatus->m_terminal)
				{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
					m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
						"sTerminal1 == m_pStatus->m_terminal "
						"-> setOwnCall(true), setNumber: " + sTerminal2 + "\n");
#endif
					pLine->setOwnCall(true);
					pLine->setNumber(sTerminal2);
				}
				else if (sTerminal2 == m_pStatus->m_terminal)
				{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
					m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
						"sTerminal1 != m_pStatus->m_terminal && ",
						"sTerminal2 == m_pStatus->m_terminal",
						"-> setComing(true), setNumber: " + sTerminal1 + "\n");
#endif
					pLine->setComing(true);
					pLine->setNumber(sTerminal1);
					if (m_pRepresentatives)
					{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
						m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
							"->m_pRepresentatives->"
							"checkConnectingRepresentative\n");
#endif
						m_pRepresentatives->checkConnectingRepresentative(sTerminal1, 
							sCallRef);
					}
				}
				if (strcmp(reason, FAIL_REASON_BUSY) == 0)
				{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
					m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
						"reason == FAIL_REASON_BUSY -> setReserved(true)\n");
#endif
					pLine->setReserved(true);
				}
				if (strcmp(reason, FAIL_REASON_DND) == 0)
				{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
					m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
						"reason == FAIL_REASON_DND -> setDND(true)\n");
#endif
					pLine->setDND(true);
				}
				if (strcmp(reason, FAIL_REASON_UNKNOWN) == 0)
				{
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
					m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
						"reason == FAIL_REASON_UNKNOWN",
						"-> setUnknownError(true)\n");
#endif
					pLine->setUnknownError(true);
				}
			}
		}
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
		m_pOutput->Out("CCTIDoc", "checkConnectionFailed", 
			"->FinalizeServerOperation\n");
#endif

		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKCONNECTIONFAILED
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkHold(char* terminal, char* callRef, bool bHold)
{
	CString sTerminal = terminal;
	CString sCallRef = callRef;
#ifdef OUTPUTDEBUGCHECKHOLD
	m_pOutput->beginSeparator();
	if (bHold)
	{
		m_pOutput->Out("CCTIDoc", "checkHold", 
			"callRef: " + sCallRef + " ,terminal: " + sTerminal 
			+ " ,bHold = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkHold", 
			"callRef: " + sCallRef + " ,terminal: " + sTerminal 
			+ " ,bHold = false\n");
	}
#endif
	if (m_pLines && m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKHOLD
		m_pOutput->Out("CCTIDoc", "checkHold", 
			"m_pLines && m_pStatus -> m_pLines->setHold(sTerminal, sCallRef, bHold)\n");
#endif
		m_pLines->setHold(sTerminal, sCallRef, bHold);
	}
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGCHECKHOLD
	m_pOutput->endSeparator();
#endif
}



void CCTIDoc::checkHeld(char* terminal, char* callRef, bool bHeld)
{
	CString sTerminal = terminal;
	CString sCallRef = callRef;
#ifdef OUTPUTDEBUGCHECKHELD
	m_pOutput->beginSeparator();
	if (bHold)
	{
		m_pOutput->Out("CCTIDoc", "checkHeld", 
			"callRef: " + sCallRef + " ,terminal: " + sTerminal 
			+ " ,bHeld = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkHeld", 
			"callRef: " + sCallRef + " ,terminal: " + sTerminal 
			+ " ,bHeld = false\n");
	}
#endif
	if (m_pLines && m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKHELD
		m_pOutput->Out("CCTIDoc", "checkHeld", 
			"m_pLines && m_pStatus\n");
#endif
		m_pLines->setHeld(sTerminal, sCallRef, bHeld);
	}
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGCHECKHELD
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkDND(char* terminal, bool bDNDOn)
{
	CString sTerminal = terminal;
#ifdef OUTPUTDEBUGCHECKDND
	m_pOutput->beginSeparator();
	if (bDNDOn)
	{
		m_pOutput->Out("CCTIDoc", "checkDND", 
			"terminal: " + sTerminal + " ,bDNDOn = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkDND", 
			"terminal: " + sTerminal + " ,bDNDOn = false\n");
	}
#endif
    CRepresentative* pRep;
    int iRep;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKDND
		m_pOutput->Out("CCTIDoc", "checkDND", "m_pStatus\n");
#endif
		if (sTerminal == m_pStatus->m_terminal)
		{
			m_pStatus->m_bOwnDND = bDNDOn;
#ifdef OUTPUTDEBUGCHECKDND
			m_pOutput->Out("CCTIDoc", "checkDND", 
				"sTerminal == m_pStatus->m_terminal",
				"-> m_pStatus->m_bOwnDND = bDNDOn\n");
#endif
		}
		else
		{
#ifdef OUTPUTDEBUGCHECKDND
			m_pOutput->Out("CCTIDoc", "checkDND", 
				"sTerminal != m_pStatus->m_terminal",
				"-> m_pLines->setDND(terminal, bDNDOn)\n");
#endif
			m_pLines->setDND(terminal, bDNDOn);
			iRep = m_pRepresentatives->findRepresentativeTerminal(sTerminal);
#ifdef OUTPUTDEBUGCHECKDND
			char sRep[10];
			itoa(iRep, sRep, 10);
			CString strRep = sRep;
			m_pOutput->Out("CCTIDoc", "checkDND", 
				"iRep = ",
				"m_pRepresentatives->findRepresentativeTerminal(sTerminal) = ",
				sRep + "\n");
#endif
			if (iRep != -1)
			{
#ifdef OUTPUTDEBUGCHECKDND
				m_pOutput->Out("CCTIDoc", "checkDND", "iRep != -1\n");
#endif
				pRep = m_pRepresentatives->getRepresentative(iRep);
				if (pRep)
				{
#ifdef OUTPUTDEBUGCHECKDND
					m_pOutput->Out("CCTIDoc", "checkDND", 
						"pRep -> pRep->setDND(bDNDOn)\n");
#endif
					pRep->setDND(bDNDOn);
				}
			}
		}
#ifdef OUTPUTDEBUGCHECKDND
		m_pOutput->Out("CCTIDoc", "checkDND", "->FinalizeServerOperation()\n");
#endif
		FinalizeServerOperation();
	}
#ifdef OUTPUTDEBUGCHECKDND
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkInService(char* terminal, bool bInService)
{
	CString sTerminal = terminal;
#ifdef OUTPUTDEBUGCHECKINSERVICE
	m_pOutput->beginSeparator();
	if (bInService)
	{
		m_pOutput->Out("CCTIDoc", "checkInService", 
			"terminal: " + sTerminal + " ,bInService = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "checkInService", 
			"terminal: " + sTerminal + " ,bInService = false\n");
	}
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGCHECKINSERVICE
		m_pOutput->Out("CCTIDoc", "checkInService", "m_pStatus\n");
#endif
		if (sTerminal == m_pStatus->m_terminal)
		{
#ifdef OUTPUTDEBUGCHECKINSERVICE
			m_pOutput->Out("CCTIDoc", "checkInService", 
				"sTerminal == m_pStatus->m_terminal",
				"-> m_pStatus->m_bOwnInService = bInService\n");
#endif
			m_pStatus->m_bOwnInService = bInService;
		}
	}
	if (m_pLines)
	{
#ifdef OUTPUTDEBUGCHECKINSERVICE
		m_pOutput->Out("CCTIDoc", "checkInService", 
			"m_pLines -> m_pLines->SetInService(terminal, bInService)\n");
#endif
		m_pLines->SetInService(terminal, bInService);
	}
	if (m_pRepresentatives)
	{
#ifdef OUTPUTDEBUGCHECKINSERVICE
		m_pOutput->Out("CCTIDoc", "checkInService", 
			"m_pRepresentatives",
			"-> m_pRepresentatives->SetRepInService(sTerminal, bInService)\n");
#endif
		m_pRepresentatives->SetRepInService(sTerminal, bInService);
	}
#ifdef OUTPUTDEBUGCHECKINSERVICE
	m_pOutput->Out("CCTIDoc", "checkInService", 
		"-> FinalizeServerOperation()\n");
#endif
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGCHECKINSERVICE
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkError(int errorType)
{
#ifdef OUTPUTDEBUGCHECKERROR
	m_pOutput->beginSeparator();
	char sErrorType[10];
	itoa(errorType, sErrorType, 10);
	CString strErrorType = sErrorType;
	m_pOutput->Out("CCTIDoc", "checkError", 
		"errorType = " + strErrorType + "\n");
#endif
	POSITION pos = this->GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) this->GetNextView(pos);
	if (pView)
	{
#ifdef OUTPUTDEBUGCHECKERROR
		m_pOutput->Out("CCTIDoc", "checkError", "pView\n");
#endif
		pView->SetErrorMessage(errorType);
	}
#ifdef OUTPUTDEBUGCHECKERROR
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::addPhoneNumber(char* terminal, char* firstname, char* lastname, 
	char* gsm, bool bGroupNumber)
{
#ifdef OUTPUTDEBUGADDPHONENUMBER
	m_pOutput->beginSeparator();
	CString strTerminal = terminal;
	CString strFirstName = firstname;
	CString strLastName = lastname;
	CString strGSM = gsm;
	if (bGroupNumber)
	{
		m_pOutput->Out("CCTIDoc", "addPhoneNumber", 
			"terminal: " + strTerminal + ",firstName: " + strFirstName 
			+ ",lastName: " + strLastName + ", gsm = " + strGSM + 
			", bGroupNumber = true\n");
	}
	else
	{
		m_pOutput->Out("CCTIDoc", "addPhoneNumber", 
			"terminal: " + strTerminal + ",firstName: " + strFirstName 
			+ ",lastName: " + strLastName + ", gsm = " + strGSM + 
			", bGroupNumber = false\n");
	}
#endif
	if (m_pHelper)
	{
#ifdef OUTPUTDEBUGADDPHONENUMBER
		m_pOutput->Out("CCTIDoc", "addPhoneNumber", "m_pHelper\n");
#endif
		CPhoneNumber* number = new CPhoneNumber(terminal, firstname,
			lastname, gsm, bGroupNumber, m_pOutput);
		if (number && m_pPhoneNumberList)
		{
#ifdef OUTPUTDEBUGADDPHONENUMBER
			m_pOutput->Out("CCTIDoc", "addPhoneNumber", "number && m_pPhoneNumberList\n");
#endif
			m_pPhoneNumberList->add(number);
			informOperationForPing();
		}
	}
#ifdef OUTPUTDEBUGADDPHONENUMBER
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::addPhoneCall(char* syear, char* smonth, char* sday, 
	char* stime, char* scallingaddress,
	char* scalledaddress, int iStatus)
{
#ifdef OUTPUTDEBUGADDPHONECALL
	m_pOutput->beginSeparator();
	CString strYear = syear;
	CString strMonth = smonth;
	CString strDay = sday;
	CString strTime = stime;
	CString strCallingAddress = scallingaddress;
	CString strCalledAddress = scalledaddress;
	char sstatus[10];
	itoa(iStatus, sstatus, 10);
	CString strStatus = sstatus;
	m_pOutput->Out("CCTIDoc", "addPhoneCall", 
		"syear: " + strYear + ",smonth: " + strMonth 
		+ ",stime: " + strTime + ", scallingaddress = " + strCallingAddress + 
		", scalledAddress = " + strCalledAddress + 
		", iStatus = " + strStatus + "\n");
#endif
	if (m_pHelper)
	{
#ifdef OUTPUTDEBUGADDPHONECALL
		m_pOutput->Out("CCTIDoc", "addPhoneCall", "m_pHelper\n");
#endif
		CString caller = scallingaddress;
		if ((iStatus == 2) && (caller != "") && 
			(caller != m_pStatus->m_terminal))
		{
#ifdef OUTPUTDEBUGADDPHONECALL
			m_pOutput->Out("CCTIDoc", "addPhoneCall", 
				"(iStatus == 2) && (caller != "") && ",
				"(caller != m_pStatus->m_terminal)\n");
#endif
			CString callingNumber = scallingaddress;
			strcpy(scallingaddress, callingNumber.GetBuffer(0));
			CPhoneCall* pCall = new CPhoneCall(
				syear, smonth, sday, stime, scallingaddress,
				scalledaddress, iStatus);
#ifdef OUTPUTDEBUGADDPHONECALL
			m_pOutput->Out("CCTIDoc", "addPhoneCall", 
				"pCall constructed\n");
#endif
			if (pCall && m_pCallList)
			{
#ifdef OUTPUTDEBUGADDPHONECALL
				m_pOutput->Out("CCTIDoc", "addPhoneCall", 
					"pCall && m_pCallList -> m_pCallList->add(pCall)\n");
#endif
				m_pCallList->add(pCall);
			}
			else
			{
#ifdef OUTPUTDEBUGADDPHONECALL
				m_pOutput->Out("CCTIDoc", "addPhoneCall", 
					"!(pCall && m_pCallList) -> delete pCall\n");
#endif
				delete pCall;
			}
		}
	}
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGADDPHONECALL
		m_pOutput->Out("CCTIDoc", "addPhoneCall", 
			"m_pStatus\n");
#endif
		++m_pStatus->m_iNumberOfNewUnansweredCalls;
#ifdef OUTPUTDEBUGADDPHONECALL
		char sNumberOfNewUnansweredCalls[10];
		itoa(m_pStatus->m_iNumberOfNewUnansweredCalls, 
			sNumberOfNewUnansweredCalls, 10);
		CString strNumberOfNewUnansweredCalls = 
			sNumberOfNewUnansweredCalls;
		m_pOutput->Out("CCTIDoc", "addPhoneCall", 
			"m_pStatus->m_iNumberOfNewUnansweredCalls = " 
			+ sNumberOfNewUnansweredCalls + "\n");
#endif
		m_pStatus->SetHistoryCompleted();
		POSITION pos = GetFirstViewPosition();
		CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
		if (pView)
		{
#ifdef OUTPUTDEBUGADDPHONECALL
			m_pOutput->Out("CCTIDoc", "addPhoneCall", 
				"pView-> pView->SendMessage(WM_USER+6, 0, 0)\n");
#endif
			pView->SendMessage(WM_USER+6, 0, 0);
			pView = NULL;
		}
	}
#ifdef OUTPUTDEBUGADDPHONECALL
	m_pOutput->Out("CCTIDoc", "addPhoneCall", "-> informOperationForPing()\n");
#endif
	informOperationForPing();
#ifdef OUTPUTDEBUGADDPHONECALL
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkInComingTransfer(int iType, char* number)
{
#ifdef OUTPUTDEBUGCHECKINCOMINGTRANSFER
	m_pOutput->beginSeparator();
	char sTransferType[10];
	itoa(iType, sTransferType, 10);
	CString strTransferType = sTransferType;
	CString strNumber = number;
	m_pOutput->Out("CCTIDoc", "checkInComingTransfer", 
		"iType = " + strTransferType + ", number = " + strNumber + "\n");
#endif
	if (m_pTransferRules)
	{
		switch(iType)
		{
			case 0 : m_pTransferRules->m_nameTransferAllCalls = number;
					 m_pTransferRules->m_bTransferAllCalls = true;
					 break;
			case 1 : m_pTransferRules->m_nameTransferReservedCalls = number;
					 m_pTransferRules->m_bTransferReservedCalls = true;
					 break;
			case 2 : m_pTransferRules->m_nameTransferNoAnswerCalls = number;
					 m_pTransferRules->m_bTransferNoAnswerCalls = true;
					 break;
			default : break;
		}
	}
#ifdef OUTPUTDEBUGCHECKINCOMINGTRANSFER
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkInComingUserDetail(int fieldNumber, char* fieldData)
{
#ifdef OUTPUTDEBUGCHECKINCOMINGUSERDETAIL
	m_pOutput->beginSeparator();
	char sFieldNumber[10];
	itoa(fieldNumber, sFieldNumber, 10);
	CString strFieldNumber = sFieldNumber;
	CString strFieldData = fieldData;
	m_pOutput->Out("CCTIDoc", "checkInComingUserDetail", 
		"fieldNumber = " + strFieldNumber + ", fieldData = " + strFieldData + "\n");
#endif
	CString data = fieldData;
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
#ifdef OUTPUTDEBUGCHECKINCOMINGUSERDETAIL
		m_pOutput->Out("CCTIDoc", "checkInComingUserDetail", 
			"pView -> pView->updateUserDetail(fieldNumber, data)\n");
#endif
		pView->updateUserDetail(fieldNumber, data);
		pView = NULL;
	}
#ifdef OUTPUTDEBUGCHECKINCOMINGUSERDETAIL
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::phoneNumbersEnd()
{
#ifdef OUTPUTDEBUGPHONENUMBERSEND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", "begin\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGPHONENUMBERSEND
		m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", "m_pStatus\n");
#endif
		m_pStatus->SetPhoneBookCompleted();
#ifdef OUTPUTDEBUGPHONENUMBERSEND
		m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", 
			"m_pStatus->SetPhoneBookCompleted()\n");
#endif
		updateView(true);
#ifdef OUTPUTDEBUGPHONENUMBERSEND
		m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", "updateView(true)\n");
#endif
		informOperationForPing();
#ifdef OUTPUTDEBUGPHONENUMBERSEND
		m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", 
			"informOperationForPing()\n");
#endif
		// set history ready if it is not
		POSITION pos = GetFirstViewPosition();
		CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
		if (pView)
		{
#ifdef OUTPUTDEBUGPHONENUMBERSEND
			m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", "pView\n");
#endif
			pView->refreshCalls(false);
#ifdef OUTPUTDEBUGPHONENUMBERSEND
			m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", 
				"pView->refreshCalls(false)\n");
#endif
			pView->refreshPhoneBookListControl();
#ifdef OUTPUTDEBUGPHONENUMBERSEND
			m_pOutput->Out("CCTIDoc", "phoneNumbersEnd", 
				"pView->refreshPhoneBookListControl()\n");
#endif
			pView = NULL;
		}
	}
#ifdef OUTPUTDEBUGPHONENUMBERSEND
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::checkInComingTransferEnd()
{
#ifdef OUTPUTDEBUGINCOMINGTRANSFEREND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "checkInComingTransferEnd", "begin\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGINCOMINGTRANSFEREND
		OutputDebugString("CCTIDoc::checkInComingTransferEnd, m_pStatus\n");
#endif
		m_pStatus->setTransfersGot(true);
	}
#ifdef OUTPUTDEBUGINCOMINGTRANSFEREND
	m_pOutput->Out("CCTIDoc", "historyEnd", 
		"-> FinalizeServerOperation\n");
#endif
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGINCOMINGTRANSFEREND
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::historyEnd()
{
#ifdef OUTPUTDEBUGHISTORYEND
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "historyEnd", "begin\n");
#endif
	bool bCompleted = false;
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGHISTORYEND
		m_pOutput->Out("CCTIDoc", "historyEnd", 
			"m_pStatus -> m_pStatus->SetHistoryCompleted\n");
#endif
		m_pStatus->SetHistoryCompleted();
		bCompleted = true;
	}
#ifdef OUTPUTDEBUGHISTORYEND
	m_pOutput->Out("CCTIDoc", "historyEnd", 
		"-> FinalizeServerOperation\n");
#endif
	FinalizeServerOperation();
#ifdef OUTPUTDEBUGHISTORYEND
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::ping()
{
#ifdef OUTPUTDEBUGPING
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "ping", "begin\n");
#endif
	HRESULT hr = E_FAIL;
	char message[80];
	strcpy(message, PING_RESPONSE);
#ifdef OUTPUTDEBUGPING
	CString strMessage = message;
	m_pOutput->Out("CCTIDoc", "ping", "PingResponse, message = " + strMessage + "\n");
#endif
	if (m_pICTIConnection)
	{
#ifdef OUTPUTDEBUGPING
		m_pOutput->Out("CCTIDoc", "ping", 
			"m_pICTIConnection -> SendCTIMessage\n");
#endif
		hr = SendCTIMessage(message);
	}
#ifdef OUTPUTDEBUGPING
	m_pOutput->Out("CCTIDoc", "ping", 
		"->informOperationForPing\n");
#endif
	informOperationForPing();
#ifdef OUTPUTDEBUGPING
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::pingResponse()
{
#ifdef OUTPUTDEBUGPINGRESPONSE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "pingResponse", "begin\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGPINGRESPONSE
		m_pOutput->Out("CCTIDoc", "pingResponse", "m_pStatus\n");
#endif
		m_pStatus->SetPingResponse();
#ifdef OUTPUTDEBUGPINGRESPONSE
		m_pOutput->Out("CCTIDoc", "pingResponse", 
			"m_pStatus->SetPingResponse()\n");
#endif
		informOperationForPing();
	}
#ifdef OUTPUTDEBUGPINGRESPONSE
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::informPasswordChanged()
{
#ifdef OUTPUTDEBUGINFORMPASSWORDCHANGED
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "pingResponse", "visited\n");
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::socketError()
{
#ifdef OUTPUTDEBUGSOCKETERROR
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "socketError", "begin\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGSOCKETERROR
		m_pOutput->Out("CCTIDoc", "socketError", 
			"m_pStatus -> m_pStatus->SetTerminateAll()\n");
#endif
		m_pStatus->SetTerminateAll();
	}
#ifdef OUTPUTDEBUGSOCKETERROR
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::eventMessage(char* message)
{
#ifdef OUTPUTDEBUGEVENTMESSAGE
	m_pOutput->beginSeparator();
	CString strMessage = message;
	m_pOutput->Out("CCTIDoc", "eventMessage", 
		"message = " + strMessage + "\n");
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::setPrefix(char* prefix)
{
#ifdef OUTPUTDEBUGSETPREFIX
	m_pOutput->beginSeparator();
	CString strPrefix = prefix;
	m_pOutput->Out("CCTIDoc", "setPrefix", 
		"prefix = " + strPrefix + "\n");
#endif
	if (m_pStatus)
	{
#ifdef OUTPUTDEBUGSETPREFIX
		m_pOutput->Out("CCTIDoc", "setPrefix", 
			"m_pStatus -> m_pStatus->m_prefix = prefix\n");
#endif
		m_pStatus->m_prefix = prefix;
		if (m_pCallList)
		{
#ifdef OUTPUTDEBUGSETPREFIX
			m_pOutput->Out("CCTIDoc", "setPrefix", 
				"m_pCallList -> m_pCallList->setStatus(m_pStatus)\n");
#endif
			m_pCallList->setStatus(m_pStatus);
		}
	}
#ifdef OUTPUTDEBUGSETPREFIX
	m_pOutput->endSeparator();
#endif
}


void CCTIDoc::SetApplicationUpdate(CStringArray &urls)
{
#ifdef OUTPUTDEBUGSETAPPLICATIONUPDATE
	m_pOutput->beginSeparator();
	m_pOutput->Out("CCTIDoc", "SetApplicationUpdate", "begin\n");
#endif
	POSITION pos = GetFirstViewPosition();
	CCTIFormView *pView = (CCTIFormView*) GetNextView(pos);
	if (pView)
	{
#ifdef OUTPUTDEBUGSETAPPLICATIONUPDATE
		m_pOutput->Out("CCTIDoc", "SetApplicationUpdate", 
			"pView->SetURL(urls)\n");
#endif
		m_pStatus->m_bApplicationToBeUpdated = true;
#ifdef OUTPUTDEBUGSETAPPLICATIONUPDATE
		m_pOutput->Out("CCTIDoc", "SetApplicationUpdate", 
			"m_pStatus->m_bApplicationToBeUpdated = true");
#endif
		pView->SetURL(urls);
#ifdef OUTPUTDEBUGSETAPPLICATIONUPDATE
		m_pOutput->Out("CCTIDoc", "SetApplicationUpdate", 
						", pView->SetURL(urls)\n");
#endif
	}
#ifdef OUTPUTDEBUGSETAPPLICATIONUPDATE
	m_pOutput->endSeparator();
#endif
}


BOOL CCTIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCTIDoc serialization

void CCTIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}


HRESULT CCTIDoc::GetConnectedState(BOOL& bConnectedState)
{
#ifdef TESTFILES
	addTestMessage("GetConnectedState");
#endif
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	HRESULT hr = S_OK;
	return hr;
}


/////////////////////////////////////////////////////////////////////////////
// CCTIDoc diagnostics

#ifdef _DEBUG
void CCTIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCTIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG
