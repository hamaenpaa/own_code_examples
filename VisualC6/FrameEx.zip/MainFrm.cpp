// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "FrameEx.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_ACTIVATE()
	ON_WM_INITMENU()
	ON_WM_INITMENUPOPUP()
	ON_WM_MOUSEACTIVATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_CHAR()
	ON_WM_MOUSEMOVE()
	ON_WM_MOVE()
	ON_WM_MENUCHAR()
	ON_WM_MEASUREITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_iActivated = 1;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CFrameWnd::OnActivate(nState, pWndOther, bMinimized);
		
	// TODO: Add your message handler code here
	// ShowOwnedPopups( FALSE );	
}

void CMainFrame::OnInitMenu(CMenu* pMenu) 
{
	// CFrameWnd::OnInitMenu(pMenu);
	// TODO: Add your message handler code here
	// pMenu->ModifyMenu( 0, MF_GRAYED, 0, NULL );	
}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	// CFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	// TODO: Add your message handler code here
	
}

int CMainFrame::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message) 
{
	// TODO: Add your message handler code here and/or call default
	if (message==5)
	{
		TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
		TRACE("Message on 5.\n");
		TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
	}
	TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
	TRACE("OnMouseActivate\n");
	TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
	// AfxMessageBox("OnMouseActivate");
	switch (m_iActivated)
	{
		case 1 : return MA_ACTIVATE;
		case 2 : return MA_NOACTIVATE;
		case 3 : return MA_ACTIVATEANDEAT;
		case 4 : return MA_NOACTIVATEANDEAT   ;
		default : break;

	}
	return CFrameWnd::OnMouseActivate(pDesktopWnd, nHitTest, message);
}

void CMainFrame::OnLButtonDown(UINT nFlags, CPoint point) 
{
	AfxMessageBox("OnLButtonDown");
	TRACE("LButtonDown\n");
	SendWantedMessage();
	CFrameWnd::OnLButtonDown(nFlags, point);
}

void CMainFrame::SendWantedMessage()
{
	TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
	TRACE("m_iActivated: %d\n",m_iActivated);
	TRACE("\n\n\n\n\n\n\n\n\n\n\n\n");
	m_iActivated++;
	if (m_iActivated == 5) m_iActivated = 1;
	int ValueLParam;
	ValueLParam = WM_NCHITTEST + 256*5; 
	CWnd::SendMessage(WM_MOUSEACTIVATE,(UINT)m_hWnd,ValueLParam);
}


void CMainFrame::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	AfxMessageBox("OnChar");
	TRACE("OnChar\n");
	CFrameWnd::OnChar(nChar, nRepCnt, nFlags);
}

void CMainFrame::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	AfxMessageBox("MouseMove");	
	SendWantedMessage();
	CFrameWnd::OnMouseMove(nFlags, point);
}

void CMainFrame::OnMove(int x, int y) 
{
	AfxMessageBox("Move");	
	TRACE("Move\n");
	SendWantedMessage();
	CFrameWnd::OnMove(x, y);
	
	// TODO: Add your message handler code here
	
}

LRESULT CMainFrame::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
	// TODO: Add your message handler code here and/or call default
	AfxMessageBox("MenuChar");		
	TRACE("MenuChar\n");
	SendWantedMessage();
	return CFrameWnd::OnMenuChar(nChar, nFlags, pMenu);
}

void CMainFrame::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	AfxMessageBox("MeasureItem");	
	CFrameWnd::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}
