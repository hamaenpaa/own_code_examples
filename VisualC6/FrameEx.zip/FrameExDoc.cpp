// FrameExDoc.cpp : implementation of the CFrameExDoc class
//

#include "stdafx.h"
#include "FrameEx.h"

#include "FrameExDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFrameExDoc

IMPLEMENT_DYNCREATE(CFrameExDoc, CDocument)

BEGIN_MESSAGE_MAP(CFrameExDoc, CDocument)
	//{{AFX_MSG_MAP(CFrameExDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFrameExDoc construction/destruction

CFrameExDoc::CFrameExDoc()
{
	// TODO: add one-time construction code here

}

CFrameExDoc::~CFrameExDoc()
{
}

BOOL CFrameExDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFrameExDoc serialization

void CFrameExDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CFrameExDoc diagnostics

#ifdef _DEBUG
void CFrameExDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFrameExDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFrameExDoc commands
