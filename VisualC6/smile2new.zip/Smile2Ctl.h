// Smile2Ctl.h : Declaration of the CSmile2Ctl

#ifndef __SMILE2CTL_H_
#define __SMILE2CTL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>
#include "Smile2CP.h"

#define X(x) (int)(xLeft + (x)*xScale/100) // Scaling macros
#define Y(y) (int)(yTop + (y)*yScale/100)
#define CX(x) (int)((x)*xScale/100)
#define CY(y) (int)((y)*yScale/100)
/////////////////////////////////////////////////////////////////////////////
// CSmile2Ctl
class ATL_NO_VTABLE CSmile2Ctl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CSmile2Ctl, ISmile2Ctl, &IID_ISmile2Ctl, &LIBID_SMILE2Lib>,
	public CComControl<CSmile2Ctl>,
	public IPersistStreamInitImpl<CSmile2Ctl>,
	public IOleControlImpl<CSmile2Ctl>,
	public IOleObjectImpl<CSmile2Ctl>,
	public IOleInPlaceActiveObjectImpl<CSmile2Ctl>,
	public IViewObjectExImpl<CSmile2Ctl>,
	public IOleInPlaceObjectWindowlessImpl<CSmile2Ctl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CSmile2Ctl>,
	public IPersistStorageImpl<CSmile2Ctl>,
	public ISpecifyPropertyPagesImpl<CSmile2Ctl>,
	public IQuickActivateImpl<CSmile2Ctl>,
	public IDataObjectImpl<CSmile2Ctl>,
	public IProvideClassInfo2Impl<&CLSID_Smile2Ctl, &DIID__ISmile2CtlEvents, &LIBID_SMILE2Lib>,
	public IPropertyNotifySinkCP<CSmile2Ctl>,
	public CComCoClass<CSmile2Ctl, &CLSID_Smile2Ctl>,
	public CProxy_ISmile2CtlEvents< CSmile2Ctl >,
	public IObjectSafetyImpl<CSmile2Ctl, INTERFACESAFE_FOR_UNTRUSTED_CALLER>,
	public IPersistPropertyBagImpl<CSmile2Ctl>
{
public:
	CSmile2Ctl()
	{
		m_clrFillColor = RGB(0xFF, 0xFF, 0);	// Yellow
		m_clrForeColor = RGB(0, 0, 0);			// Black
		m_clrBackColor = RGB(0, 0xFF, 0xFF);	// Cyan
		m_rectRc.left   = 0;
		m_rectRc.top    = 0;
		m_rectRc.right  = 0;
		m_rectRc.bottom = 0;
		m_nFontNumber = 0;

		// The function OleCreateFontIndirect creates and initializes
		// a standard font object using an initial description of
		// the font's properties in a FONTDESC structure. 
		// A QueryInterface is built into this call, and
		// the function returns an interface pointer to the new 
		// font object specified by caller in the m_pFont parameter.
		static FONTDESC _fontdesc =
		{sizeof(FONTDESC), OLESTR("Arial"), FONTSIZE(10),
		FW_BOLD, ANSI_CHARSET, TRUE, FALSE, FALSE };
		FONTDESC fd = _fontdesc;
		OleCreateFontIndirect(&fd,IID_IFontDisp,(void**)&m_pFont);
		m_nSad = 0;
		m_bWink = FALSE;
	}

	~CSmile2Ctl()
	{
		DeleteObject(m_pFont);
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMILE2CTL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSmile2Ctl)
	COM_INTERFACE_ENTRY(ISmile2Ctl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(IObjectSafety)
	COM_INTERFACE_ENTRY(IPersistPropertyBag)
	COM_INTERFACE_ENTRY_IID(IID_IPersist, IPersistPropertyBag)
END_COM_MAP()

BEGIN_PROP_MAP(CSmile2Ctl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("BackColor", DISPID_BACKCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("BorderStyle", DISPID_BORDERSTYLE, CLSID_NULL)
	PROP_ENTRY("FillColor", DISPID_FILLCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Font", DISPID_FONT, CLSID_StockFontPage)
	PROP_ENTRY("ForeColor", DISPID_FORECOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Sad", 1, CLSID_Smile2Prop)
	PROP_ENTRY("FontNumber", 2, CLSID_Smile2Prop)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CSmile2Ctl)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
	CONNECTION_POINT_ENTRY(DIID__ISmile2CtlEvents)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CSmile2Ctl)
	CHAIN_MSG_MAP(CComControl<CSmile2Ctl>)
	DEFAULT_REFLECTION_HANDLER()
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_ISmile2Ctl,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// ISmile2Ctl
public:
	STDMETHOD(get_FontNumber)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_FontNumber)(/*[in]*/ short newVal);
	STDMETHOD(get_Sad)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Sad)(/*[in]*/ short newVal);

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		RECT& rc = *(RECT*)di.prcBounds;
		HDC hdc = di.hdcDraw;
		COLORREF colBack;	// Background color (Stock property)
		COLORREF colFore;	// Foreground color (Custom property)
		COLORREF colFill;	// Fill color (Custom property)
		HBRUSH hOldBrush, hBrushBack, hBrushFill, hBrushStock;
		HPEN hOldPen, hPenThick, hPenStock;
		HFONT hStockFont=NULL,hOldFont=NULL;
		BSTR StockFontName;
		long xLeft = rc.left; // Use with scaling macros
		long yTop = rc.top;
		long xScale = rc.right - rc.left;
		long yScale = rc.bottom - rc.top;


		// Translate OLE_COLORs into a COLORREF type
		OleTranslateColor(m_clrBackColor, NULL, &colBack);
		OleTranslateColor(m_clrForeColor, NULL, &colFore);
		OleTranslateColor(m_clrFillColor, NULL, &colFill);

		// Draw the component as a rectangle in background color
		hBrushBack = CreateSolidBrush(colBack);
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrushBack);
		Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

		// Using control's Font Stock Property
//		wchar_t wsz0[] = L"Arial";
		wchar_t wsz1[] = L"AvantGarde Bk BT";
		wchar_t wsz2[] = L"Book Antiqua";
		wchar_t wsz3[] = L"Centaur";
		wchar_t wsz4[] = L"Courier New";
		wchar_t wsz5[] = L"Dauphin";
		wchar_t wsz6[] = L"Fixedsys";
		wchar_t wsz7[] = L"Futura Lt BT";
		wchar_t wsz8[] = L"Gigi";
		wchar_t wsz9[] = L"Lithograph";
		wchar_t wsz10[] = L"Lucida Sans";
		wchar_t wsz11[] = L"Modern";
		wchar_t wsz12[] = L"MS Sans Serif";
		wchar_t wsz13[] = L"Papyrus";
		wchar_t wsz14[] = L"Rockwell";
		wchar_t wsz15[] = L"Script";
		wchar_t wsz16[] = L"System";
		wchar_t wsz17[] = L"Tahoma";
		wchar_t wsz18[] = L"Terminal";
		wchar_t wsz19[] = L"Arial";
		wchar_t wsz20[] = L"Times New Roman";

		BSTR bstr;
		switch(m_nFontNumber) {
		
		case 0:	 bstr = SysAllocString(wsz19);
				 break;
		case 1:  bstr = SysAllocString(wsz1);
				 break;
		case 2:  bstr = SysAllocString(wsz2);
				 break;
		case 3:  bstr = SysAllocString(wsz3);
				 break;
		case 4:  bstr = SysAllocString(wsz4);
				 break;
		case 5:  bstr = SysAllocString(wsz5);
				 break;
		case 6:  bstr = SysAllocString(wsz6);
				 break;
		case 7:  bstr = SysAllocString(wsz7);
				 break;
		case 8:  bstr = SysAllocString(wsz8);
				 break;
		case 9:  bstr = SysAllocString(wsz9);
				 break;
		case 10: bstr = SysAllocString(wsz10);
				 break;
		case 11: bstr = SysAllocString(wsz11);
				 break;
		case 12: bstr = SysAllocString(wsz12);
				 break;
		case 13: bstr = SysAllocString(wsz13);
				 break;
		case 14: bstr = SysAllocString(wsz14);
				 break;
		case 15: bstr = SysAllocString(wsz15);
				 break;
		case 16: bstr = SysAllocString(wsz16);
				 break;
		case 17: bstr = SysAllocString(wsz17);
				 break;
		case 18: bstr = SysAllocString(wsz18);
				 break;
		case 19: bstr = SysAllocString(wsz19);
				 break;
		case 20: bstr = SysAllocString(wsz20);
				 break;
		default: bstr = SysAllocString(wsz20);
				 break;
		}

		TCHAR msg[50];

		CComQIPtr<IFont,&IID_IFont> pFont(m_pFont);
		if (m_nFontNumber > 0 && m_nFontNumber < 21)
		{
			if(pFont)
			{
				pFont->put_Name(bstr);
				SysFreeString(bstr);
				pFont->get_hFont(&hStockFont);
				pFont->get_Name(&StockFontName);
				wsprintf(msg,_T("%S"), (LPWSTR)StockFontName);
				SysFreeString(StockFontName);
			}
		}
		else
		{
			if (pFont)
			{
				pFont->get_hFont(&hStockFont);
				pFont->get_Name(&StockFontName);
				wsprintf(msg,_T("%S"), (LPWSTR)StockFontName);
				SysFreeString(StockFontName);
			}
		}
		if(hStockFont)
			hOldFont = (HFONT)SelectObject(hdc,hStockFont);

		hPenStock = (HPEN)GetStockObject(BLACK_PEN);
		hOldPen = (HPEN)SelectObject(hdc, hPenStock);
		SetTextColor(hdc, colFore);
		DrawText(hdc, msg, -1, &rc, DT_CENTER | DT_TOP | DT_SINGLELINE);

		if(hOldFont)
			SelectObject(hdc,hOldFont);

		// Drawing the head with PenThick and BrushFill
		int iPenWidth = max(CX(5), CY(5));  // Pen width proportional to 
											// control size
		hPenThick = CreatePen(PS_SOLID, iPenWidth, RGB(0x00, 0x00, 0x00));
		hBrushFill = CreateSolidBrush(colFill);
		SelectObject(hdc, hPenThick);
		SelectObject(hdc, hBrushFill);
		m_rectRc.left   = rc.left+CX(10);
		m_rectRc.top    = rc.top+CY(13);
		m_rectRc.right  = rc.right-CX(10);
		m_rectRc.bottom = rc.bottom-CY(7);
		Ellipse(hdc, m_rectRc.left, m_rectRc.top,
			m_rectRc.right, m_rectRc.bottom);

		// Drawing the mouth with PenThick
		if (m_nSad)									// Custom property Sad
		{
			Arc(hdc, X(25), Y(70), X(75), Y(140),	// Sad mouth
				X(65), Y(75), X(35), Y(75));
		}
		else
		{
			Arc(hdc, X(25), Y(10), X(75), Y(80),	// Smiling mouth
				X(35), Y(70), X(65), Y(70));
		}

		// Drawing eyes
		hBrushStock = (HBRUSH)GetStockObject(BLACK_BRUSH);
		SelectObject(hdc, hBrushStock);
		if (m_bWink)								// Left eye
		{
			SelectObject(hdc, hPenStock);
			MoveToEx(hdc, X(57), Y(35), NULL);
			LineTo(hdc, X(65), Y(50));
			MoveToEx(hdc, X(57), Y(50), NULL);
			LineTo(hdc, X(65), Y(35));
			SelectObject(hdc, hPenThick);
		}

		else
		{
			Ellipse(hdc, X(60), Y(38), X(62), Y(47));
		}

		Ellipse(hdc, X(38), Y(38), X(40), Y(47));	// Right eye
		Ellipse(hdc, X(49), Y(46), X(51), Y(55));	// Nose

		SelectObject(hdc, hOldPen);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrushBack);
		DeleteObject(hBrushFill);
		DeleteObject(hPenThick);

		return S_OK;
	}

	OLE_COLOR m_clrBackColor;
	LONG m_nBorderStyle;
	OLE_COLOR m_clrFillColor;
	CComPtr<IFontDisp> m_pFont;
	OLE_COLOR m_clrForeColor;
	short m_nSad;
	BOOL m_bWink;
	RECT m_rectRc;
	short m_nFontNumber;

	LRESULT OnLButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		HRGN hRgn;
		WORD xPos = LOWORD(lParam); // Horizontal position of cursor
		WORD yPos = HIWORD(lParam); // Vertical position of cursor

		// Create a region of the head ellipse
		hRgn = CreateEllipticRgnIndirect(&m_rectRc);

		// If the clicked point is in the elliptic region
		if (PtInRegion(hRgn, xPos, yPos))
			Fire_ClickIn(xPos, yPos);
		else
			Fire_ClickOut(xPos, yPos);

		// Delete the region that we created
		DeleteObject(hRgn);

		return 0;
	}
};

#endif //__SMILE2CTL_H_
