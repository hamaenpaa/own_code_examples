// Smile2Prop.cpp : Implementation of CSmile2Prop
#include "stdafx.h"
#include "Smile2.h"
#include "Smile2Prop.h"

/////////////////////////////////////////////////////////////////////////////
// CSmile2Prop

