// Smile2Prop.h : Declaration of the CSmile2Prop

#ifndef __SMILE2PROP_H_
#define __SMILE2PROP_H_

#include "Smile2.h"
#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_Smile2Prop;

/////////////////////////////////////////////////////////////////////////////
// CSmile2Prop
class ATL_NO_VTABLE CSmile2Prop :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSmile2Prop, &CLSID_Smile2Prop>,
	public IPropertyPageImpl<CSmile2Prop>,
	public CDialogImpl<CSmile2Prop>
{
public:
	CSmile2Prop() 
	{
		m_dwTitleID = IDS_TITLESmile2Prop;
		m_dwHelpFileID = IDS_HELPFILESmile2Prop;
		m_dwDocStringID = IDS_DOCSTRINGSmile2Prop;
	}

	enum {IDD = IDD_SMILE2PROP};

DECLARE_REGISTRY_RESOURCEID(IDR_SMILE2PROP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSmile2Prop) 
	COM_INTERFACE_ENTRY(IPropertyPage)
END_COM_MAP()

BEGIN_MSG_MAP(CSmile2Prop)
	CHAIN_MSG_MAP(IPropertyPageImpl<CSmile2Prop>)
	COMMAND_HANDLER(IDC_SAD, EN_CHANGE, OnChangeSad)
	COMMAND_HANDLER(IDC_FONTNUMBER, EN_CHANGE, OnChangeFontnumber)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	STDMETHOD(Apply)(void)
	{
		USES_CONVERSION;
		ATLTRACE(_T("CSmile2Prop::Apply\n"));
		for (UINT i = 0; i < m_nObjects; i++)
		{
			CComQIPtr<ISmile2Ctl, &IID_ISmile2Ctl> pSmile2(m_ppUnk[i]);
			short nSad = (short)GetDlgItemInt(IDC_SAD);
			if FAILED(pSmile2->put_Sad(nSad))
			{
				CComPtr<IErrorInfo> pError;
				CComBSTR strError;
				GetErrorInfo(0, &pError);
				pError->GetDescription(&strError);
				MessageBox(OLE2T(strError), _T("Error"), MB_ICONEXCLAMATION);
				return E_FAIL;
			}
			short nFontNumber = (short)GetDlgItemInt(IDC_FONTNUMBER);
			if FAILED(pSmile2->put_FontNumber(nFontNumber))
			{
				CComPtr<IErrorInfo> pError;
				CComBSTR strError;
				GetErrorInfo(0, &pError);
				pError->GetDescription(&strError);
				MessageBox(OLE2T(strError), _T("Error"), MB_ICONEXCLAMATION);
				return E_FAIL;
			}
		}
		m_bDirty = FALSE;
		return S_OK;
	}
	LRESULT OnChangeSad(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		SetDirty(TRUE);
		return 0;
	}
	LRESULT OnChangeFontnumber(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		SetDirty(TRUE);
		return 0;
	}
};

#endif //__SMILE2PROP_H_
