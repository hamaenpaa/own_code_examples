// Smile2Ctl.cpp : Implementation of CSmile2Ctl

#include "stdafx.h"
#include "Smile2.h"
#include "Smile2Ctl.h"

/////////////////////////////////////////////////////////////////////////////
// CSmile2Ctl


STDMETHODIMP CSmile2Ctl::get_Sad(short *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pVal = m_nSad;
	return S_OK;
}

STDMETHODIMP CSmile2Ctl::put_Sad(short newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if (newVal != 0)
		m_nSad = 1;
	else
		m_nSad = 0;
	FireViewChange();
	return S_OK;
}

STDMETHODIMP CSmile2Ctl::get_FontNumber(short *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pVal = m_nFontNumber;
	return S_OK;
}

STDMETHODIMP CSmile2Ctl::put_FontNumber(short newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_nFontNumber = newVal;
	FireViewChange();
	return S_OK;
}
