//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Smile2.rc
//
#define IDS_PROJNAME                    100
#define IDB_SMILE2CTL                   102
#define IDR_SMILE2CTL                   103
#define IDS_TITLESmile2Prop             104
#define IDS_HELPFILESmile2Prop          105
#define IDS_DOCSTRINGSmile2Prop         106
#define IDR_SMILE2PROP                  107
#define IDD_SMILE2PROP                  108
#define IDC_SAD                         202
#define IDC_FONTNUMBER                  203

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
