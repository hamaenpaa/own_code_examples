/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Mar 08 08:46:04 2000
 */
/* Compiler settings for D:\iio222\Esimerkit\Smile2\Smile2.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ISmile2Ctl = {0x4AA6C9AD,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


const IID LIBID_SMILE2Lib = {0x4AA6C9A0,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


const IID DIID__ISmile2CtlEvents = {0x4AA6C9AF,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


const CLSID CLSID_Smile2Ctl = {0x4AA6C9AE,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


const IID DIID__ISmile2PropEvents = {0x4AA6C9B2,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


const CLSID CLSID_Smile2Prop = {0x4AA6C9B1,0xE80B,0x11D3,{0xA8,0xA3,0xFA,0x15,0xFF,0x2E,0x66,0x19}};


#ifdef __cplusplus
}
#endif

