//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RotaryMFC.rc
//
#define IDS_ROTARYMFC                   1
#define IDD_ABOUTBOX_ROTARYMFC          1
#define IDB_ROTARYMFC                   1
#define IDI_ABOUTDLL                    1
#define IDS_ROTARYMFC_PPG               2
#define IDS_ROTARYMFC_PPG_CAPTION       200
#define IDD_PROPPAGE_ROTARYMFC          200
#define IDC_TICKS_ENABLED               201
#define IDC_NUM_TICKS                   202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
