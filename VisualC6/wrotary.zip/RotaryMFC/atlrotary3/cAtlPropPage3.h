// cAtlPropPage3.h : Declaration of the CcAtlPropPage3

#ifndef __CATLPROPPAGE3_H_
#define __CATLPROPPAGE3_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_cAtlPropPage3;

/////////////////////////////////////////////////////////////////////////////
// CcAtlPropPage3
class ATL_NO_VTABLE CcAtlPropPage3 :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CcAtlPropPage3, &CLSID_cAtlPropPage3>,
	public IPropertyPageImpl<CcAtlPropPage3>,
	public CDialogImpl<CcAtlPropPage3>
{
public:
	CcAtlPropPage3() 
	{
		m_dwTitleID = IDS_TITLEcAtlPropPage3;
		m_dwHelpFileID = IDS_HELPFILEcAtlPropPage3;
		m_dwDocStringID = IDS_DOCSTRINGcAtlPropPage3;
	}

	enum {IDD = IDD_CATLPROPPAGE3};

DECLARE_REGISTRY_RESOURCEID(IDR_CATLPROPPAGE3)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CcAtlPropPage3) 
	COM_INTERFACE_ENTRY(IPropertyPage)
END_COM_MAP()

BEGIN_MSG_MAP(CcAtlPropPage3)
	CHAIN_MSG_MAP(IPropertyPageImpl<CcAtlPropPage3>)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	STDMETHOD(Apply)(void)
	{
		ATLTRACE(_T("CcAtlPropPage3::Apply\n"));
		for (UINT i = 0; i < m_nObjects; i++)
		{
/*	    CString msg;
		char no[20];
        ltoa(m_nObjects,no,10); */
	    USES_CONVERSION;
		ATLTRACE(_T("CAtlRotaryProp::Apply\n"));
/*		msg = no; msg = "m_nObjects: " + msg;
		long pno;
		AfxMessageBox(msg);*/
		for (UINT i = 0; i < m_nObjects; i++)
		{
			CComQIPtr<IAtlRotaryCtl3, &IID_IAtlRotaryCtl3> pAtlRotary(m_ppUnk[i]);
			if (m_b
/*

            int kok1 = GetDlgItemInt(IDC_SHOWTICKMARKS);
			ltoa(kok1,no,10);
			msg = no;
            msg = "TicksEnable,int: "+ msg;
			AfxMessageBox(msg);
			BOOL EnableTicks = TRUE;
			if (EnableTicks) {
			  msg= "EnableTicks:TRUE";
              AfxMessageBox(msg);
            }
			else
            {
			  msg= "EnableTicks:FALSE";
              AfxMessageBox(msg);
            }
*/
            if (FAILED(pAtlRotary->put_Ticks(EnableTicks)))
            {
              CComPtr<IErrorInfo> pError;
              CComBSTR strError;
			  GetErrorInfo(0,&pError);
			  pError->GetDescription(&strError);
              MessageBox(OLE2T(strError), _T("Error"), MB_ICONEXCLAMATION);
			  AfxMessageBox("PutTicks FAILED");
              return E_FAIL;
			} else AfxMessageBox("PutTicks MANAGED");
			short TickNo = (short)GetDlgItemInt(IDC_NOTICKMARKS);
/*			pno = TickNo;
			ltoa(pno,no,10);
            msg = no;
			msg = "NumTicks: " + msg;
			AfxMessageBox(msg); */
            if (FAILED(pAtlRotary->put_NumTicks(TickNo)))
            {
              CComPtr<IErrorInfo> pError;
              CComBSTR strError;
			  GetErrorInfo(0,&pError);
			  pError->GetDescription(&strError);
              MessageBox(OLE2T(strError), _T("Error"), MB_ICONEXCLAMATION);
			  // AfxMessageBox("PutNumTicks FAILED");
              return E_FAIL;
			} // else AfxMessageBox("PutNumTicks MANAGED");
			// Do something interesting here
			// ICircCtl* pCirc;
			// m_ppUnk[i]->QueryInterface(IID_ICircCtl, (void**)&pCirc);
			// pCirc->put_Caption(CComBSTR("something special"));
			// pCirc->Release();
		}
		m_bDirty = FALSE;
			// Do something interesting here
			// ICircCtl* pCirc;
			// m_ppUnk[i]->QueryInterface(IID_ICircCtl, (void**)&pCirc);
			// pCirc->put_Caption(CComBSTR("something special"));
			// pCirc->Release();
		return S_OK;
	}
};

#endif //__CATLPROPPAGE3_H_
