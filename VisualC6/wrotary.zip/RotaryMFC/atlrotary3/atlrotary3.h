/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Mar 13 21:47:35 2000
 */
/* Compiler settings for C:\visualc\rotary\RotaryMFC\atlrotary3\atlrotary3.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __atlrotary3_h__
#define __atlrotary3_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IAtlRotaryCtl3_FWD_DEFINED__
#define __IAtlRotaryCtl3_FWD_DEFINED__
typedef interface IAtlRotaryCtl3 IAtlRotaryCtl3;
#endif 	/* __IAtlRotaryCtl3_FWD_DEFINED__ */


#ifndef ___IAtlRotaryCtl3Events_FWD_DEFINED__
#define ___IAtlRotaryCtl3Events_FWD_DEFINED__
typedef interface _IAtlRotaryCtl3Events _IAtlRotaryCtl3Events;
#endif 	/* ___IAtlRotaryCtl3Events_FWD_DEFINED__ */


#ifndef __AtlRotaryCtl3_FWD_DEFINED__
#define __AtlRotaryCtl3_FWD_DEFINED__

#ifdef __cplusplus
typedef class AtlRotaryCtl3 AtlRotaryCtl3;
#else
typedef struct AtlRotaryCtl3 AtlRotaryCtl3;
#endif /* __cplusplus */

#endif 	/* __AtlRotaryCtl3_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IAtlRotaryCtl3_INTERFACE_DEFINED__
#define __IAtlRotaryCtl3_INTERFACE_DEFINED__

/* interface IAtlRotaryCtl3 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IAtlRotaryCtl3;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5117E82F-F91F-11D3-B4E3-AB4A67B50436")
    IAtlRotaryCtl3 : public IDispatch
    {
    public:
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_BackColor( 
            /* [in] */ OLE_COLOR clr) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_BackColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_ForeColor( 
            /* [in] */ OLE_COLOR clr) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_ForeColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TickNo( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TickNo( 
            /* [in] */ short newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EnableTicks( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EnableTicks( 
            /* [in] */ BOOL newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAtlRotaryCtl3Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IAtlRotaryCtl3 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IAtlRotaryCtl3 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BackColor )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ OLE_COLOR clr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BackColor )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ForeColor )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ OLE_COLOR clr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ForeColor )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TickNo )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TickNo )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ short newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EnableTicks )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EnableTicks )( 
            IAtlRotaryCtl3 __RPC_FAR * This,
            /* [in] */ BOOL newVal);
        
        END_INTERFACE
    } IAtlRotaryCtl3Vtbl;

    interface IAtlRotaryCtl3
    {
        CONST_VTBL struct IAtlRotaryCtl3Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAtlRotaryCtl3_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IAtlRotaryCtl3_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IAtlRotaryCtl3_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IAtlRotaryCtl3_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IAtlRotaryCtl3_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IAtlRotaryCtl3_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IAtlRotaryCtl3_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IAtlRotaryCtl3_put_BackColor(This,clr)	\
    (This)->lpVtbl -> put_BackColor(This,clr)

#define IAtlRotaryCtl3_get_BackColor(This,pclr)	\
    (This)->lpVtbl -> get_BackColor(This,pclr)

#define IAtlRotaryCtl3_put_ForeColor(This,clr)	\
    (This)->lpVtbl -> put_ForeColor(This,clr)

#define IAtlRotaryCtl3_get_ForeColor(This,pclr)	\
    (This)->lpVtbl -> get_ForeColor(This,pclr)

#define IAtlRotaryCtl3_get_TickNo(This,pVal)	\
    (This)->lpVtbl -> get_TickNo(This,pVal)

#define IAtlRotaryCtl3_put_TickNo(This,newVal)	\
    (This)->lpVtbl -> put_TickNo(This,newVal)

#define IAtlRotaryCtl3_get_EnableTicks(This,pVal)	\
    (This)->lpVtbl -> get_EnableTicks(This,pVal)

#define IAtlRotaryCtl3_put_EnableTicks(This,newVal)	\
    (This)->lpVtbl -> put_EnableTicks(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id][propput] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_put_BackColor_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [in] */ OLE_COLOR clr);


void __RPC_STUB IAtlRotaryCtl3_put_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_get_BackColor_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);


void __RPC_STUB IAtlRotaryCtl3_get_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_put_ForeColor_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [in] */ OLE_COLOR clr);


void __RPC_STUB IAtlRotaryCtl3_put_ForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_get_ForeColor_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);


void __RPC_STUB IAtlRotaryCtl3_get_ForeColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_get_TickNo_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IAtlRotaryCtl3_get_TickNo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_put_TickNo_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [in] */ short newVal);


void __RPC_STUB IAtlRotaryCtl3_put_TickNo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_get_EnableTicks_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB IAtlRotaryCtl3_get_EnableTicks_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IAtlRotaryCtl3_put_EnableTicks_Proxy( 
    IAtlRotaryCtl3 __RPC_FAR * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IAtlRotaryCtl3_put_EnableTicks_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IAtlRotaryCtl3_INTERFACE_DEFINED__ */



#ifndef __ATLROTARY3Lib_LIBRARY_DEFINED__
#define __ATLROTARY3Lib_LIBRARY_DEFINED__

/* library ATLROTARY3Lib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ATLROTARY3Lib;

#ifndef ___IAtlRotaryCtl3Events_DISPINTERFACE_DEFINED__
#define ___IAtlRotaryCtl3Events_DISPINTERFACE_DEFINED__

/* dispinterface _IAtlRotaryCtl3Events */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IAtlRotaryCtl3Events;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("5117E831-F91F-11D3-B4E3-AB4A67B50436")
    _IAtlRotaryCtl3Events : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IAtlRotaryCtl3EventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IAtlRotaryCtl3Events __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IAtlRotaryCtl3EventsVtbl;

    interface _IAtlRotaryCtl3Events
    {
        CONST_VTBL struct _IAtlRotaryCtl3EventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IAtlRotaryCtl3Events_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IAtlRotaryCtl3Events_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IAtlRotaryCtl3Events_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IAtlRotaryCtl3Events_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IAtlRotaryCtl3Events_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IAtlRotaryCtl3Events_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IAtlRotaryCtl3Events_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IAtlRotaryCtl3Events_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_AtlRotaryCtl3;

#ifdef __cplusplus

class DECLSPEC_UUID("5117E830-F91F-11D3-B4E3-AB4A67B50436")
AtlRotaryCtl3;
#endif
#endif /* __ATLROTARY3Lib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
