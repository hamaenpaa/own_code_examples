// cAtlRotaryProp.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "cAtlRotaryProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cAtlRotaryProp dialog


cAtlRotaryProp::cAtlRotaryProp(CWnd* pParent /*=NULL*/)
	: CDialog(cAtlRotaryProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(cAtlRotaryProp)
	m_bTickMarks = FALSE;
	m_sNoTicksMarks = 0;
	//}}AFX_DATA_INIT
}


void cAtlRotaryProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cAtlRotaryProp)
	DDX_Check(pDX, IDC_SHOWTICKMARKS, m_bTickMarks);
	DDX_Text(pDX, IDC_NOTICKMARKS, m_sNoTicksMarks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cAtlRotaryProp, CDialog)
	//{{AFX_MSG_MAP(cAtlRotaryProp)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cAtlRotaryProp message handlers
