// SmileCtl.cpp : Implementation of CSmileCtl

#include "stdafx.h"
#include "Smile.h"
#include "SmileCtl.h"

/////////////////////////////////////////////////////////////////////////////
// CSmileCtl


STDMETHODIMP CSmileCtl::get_Sad(BOOL *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here

	*pVal = m_bsad;
	return S_OK;
}

STDMETHODIMP CSmileCtl::put_Sad(BOOL newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here

	m_bsad = newVal;
	FireViewChange();
	return S_OK;
}
