// SmileCtl.h : Declaration of the CSmileCtl

#ifndef __SMILECTL_H_
#define __SMILECTL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>


/////////////////////////////////////////////////////////////////////////////
// CSmileCtl
class ATL_NO_VTABLE CSmileCtl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CSmileCtl, ISmileCtl, &IID_ISmileCtl, &LIBID_SMILELib>,
	public CComControl<CSmileCtl>,
	public IPersistStreamInitImpl<CSmileCtl>,
	public IOleControlImpl<CSmileCtl>,
	public IOleObjectImpl<CSmileCtl>,
	public IOleInPlaceActiveObjectImpl<CSmileCtl>,
	public IViewObjectExImpl<CSmileCtl>,
	public IOleInPlaceObjectWindowlessImpl<CSmileCtl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CSmileCtl>,
	public IPersistStorageImpl<CSmileCtl>,
	public ISpecifyPropertyPagesImpl<CSmileCtl>,
	public IQuickActivateImpl<CSmileCtl>,
	public IDataObjectImpl<CSmileCtl>,
	public IProvideClassInfo2Impl<&CLSID_SmileCtl, &DIID__ISmileCtlEvents, &LIBID_SMILELib>,
	public IPropertyNotifySinkCP<CSmileCtl>,
	public CComCoClass<CSmileCtl, &CLSID_SmileCtl>
{
public:
	CSmileCtl()
	{
		m_bsad = FALSE;
		m_clrFillColor = RGB(0xFF, 0xFF, 0); // DeFault Color: Yellow
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMILECTL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSmileCtl)
	COM_INTERFACE_ENTRY(ISmileCtl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CSmileCtl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("BackColor", DISPID_BACKCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("BorderColor", DISPID_BORDERCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Caption", DISPID_CAPTION, CLSID_NULL)
	PROP_ENTRY("FillColor", DISPID_FILLCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Font", DISPID_FONT, CLSID_StockFontPage)
	PROP_ENTRY("ForeColor", DISPID_FORECOLOR, CLSID_StockColorPage)
	PROP_ENTRY("Text", DISPID_TEXT, CLSID_NULL)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CSmileCtl)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CSmileCtl)
	CHAIN_MSG_MAP(CComControl<CSmileCtl>)
	DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_ISmileCtl,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
//			if (InlineIsEqualGUID(*arr[i], riid))
//				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// ISmileCtl
public:
	STDMETHOD(get_Sad)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_Sad)(/*[in]*/ BOOL newVal);

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{

		RECT& rc = *(RECT*)di.prcBounds;
        HDC hdc  = di.hdcDraw;

		int leftmove,topmove;
        int divisionwidth, divisionheight;

        COLORREF    colFore;
        HBRUSH      hOldBrush, hBrush;
        HPEN        hOldPen, hPen;
        HFONT       hFont;

		RECT rectMouth;
		POINT ptMouthStart,ptMouthStop,ptSwap,ptCenter;

        leftmove = (rc.right-rc.left) /10;
        topmove = (rc.bottom-rc.top) /10;

        hPen = (HPEN)GetStockObject(BLACK_PEN);
        hOldPen = (HPEN)SelectObject(hdc, hPen);
        hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH);
        hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
    //    hFont = (HFONT)GetStockObject();

		OleTranslateColor(m_clrFillColor, NULL, &colFore);
        hBrush    = CreateSolidBrush(colFore);
        SelectObject(hdc, hBrush);

		Ellipse(hdc, rc.left+leftmove, rc.top+topmove, 
			        rc.right-leftmove, rc.bottom-topmove);

		// Eyes and Mouth filled and drawn by black
        hBrush    = CreateSolidBrush(0);
        SelectObject(hdc, hBrush);

        divisionheight = (rc.bottom-rc.top-2*topmove) / 6;
        divisionwidth = (rc.right-rc.left-2*leftmove) / 6;

		
		// Left eye
        Ellipse(hdc, rc.left+leftmove+2*divisionwidth,   rc.top+topmove+1.5*divisionheight, 
			         rc.left+leftmove+2.5*divisionwidth, rc.top+topmove+2.5*divisionheight);
        // Right eye
        Ellipse(hdc, rc.left+leftmove+3.5*divisionwidth,  rc.top+topmove+1.5*divisionheight, 
			         rc.left+leftmove+4*divisionwidth,    rc.top+topmove+2.5*divisionheight);
        // Nose
        Ellipse(hdc, rc.left+leftmove+2.75*divisionwidth, rc.top+topmove+2*divisionheight, 
			         rc.left+leftmove+3.25*divisionwidth, rc.top+topmove+3*divisionheight );
        // Mouth

		// Calculate points for mouth. 
		// Rectangle for the arc
		if (m_bsad) {
          rectMouth.top = rc.bottom-2*topmove-divisionheight;
		  rectMouth.bottom = rc.bottom-2*topmove+5*divisionheight;
		  rectMouth.left = rc.left+2*leftmove;
		  rectMouth.right = rc.right-2*leftmove;
        } else {
          rectMouth.top = rc.top+2*topmove;
		  rectMouth.bottom = rc.bottom-2*topmove;
		  rectMouth.left = rc.left+2*leftmove;
		  rectMouth.right = rc.right-2*leftmove;
        }
		// Center of the ellipse of the whole face
		ptCenter.x = rc.left+(rc.right-rc.left)/2;
        ptCenter.y = rc.top+(rc.bottom-rc.top)/2;
		// Starting and ending points for the mouth
		// Smiling mouth: ptStart->ptStop, sad: ptStop->ptStart 
		ptMouthStart.x = ptCenter.x-1.5*divisionwidth;
        ptMouthStart.y = ptCenter.y+divisionheight;
		ptMouthStop.x = ptCenter.x+1.5*divisionwidth;
        ptMouthStop.y = ptMouthStart.y;
		// Change the start and end point with each other: sad mouth
		if (m_bsad) { 
			ptSwap = ptMouthStart;
			ptMouthStart = ptMouthStop;
			ptMouthStop = ptSwap;
		}
		// Draw the mouth
        Arc(hdc,rectMouth.left,rectMouth.top,rectMouth.right,rectMouth.bottom,
			    ptMouthStart.x,ptMouthStart.y,ptMouthStop.x,ptMouthStop.y);



/*
		Rectangle(di.hdcDraw, rc.left, rc.top, rc.right, rc.bottom);

		SetTextAlign(di.hdcDraw, TA_CENTER|TA_BASELINE);
		LPCTSTR pszText = _T("ATL 3.0 : SmileCtl");
		
		
		TextOut(di.hdcDraw, 
			(rc.left + rc.right) / 2, 
			(rc.top + rc.bottom) / 2, 
			pszText, 
			lstrlen(pszText));
*/
        SelectObject(hdc, hOldPen);
        SelectObject(hdc, hOldBrush);
        DeleteObject(hBrush);

		return S_OK;
	}
	OLE_COLOR m_clrBackColor;
	OLE_COLOR m_clrBorderColor;
	CComBSTR m_bstrCaption;
	OLE_COLOR m_clrFillColor;
	CComPtr<IFontDisp> m_pFont;
	OLE_COLOR m_clrForeColor;
	CComBSTR m_bstrText;
	BOOL m_bsad;
};

#endif //__SMILECTL_H_
