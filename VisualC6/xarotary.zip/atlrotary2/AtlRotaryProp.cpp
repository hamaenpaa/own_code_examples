// AtlRotaryProp.cpp : Implementation of CAtlRotaryProp
#include "stdafx.h"
#include "Atlrotary2.h"
#include "AtlRotaryProp.h"

/////////////////////////////////////////////////////////////////////////////
// CAtlRotaryProp

