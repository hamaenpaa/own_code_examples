#if !defined(AFX_CATLROTARYPROP_H__5117E821_F91F_11D3_B4E3_AB4A67B50436__INCLUDED_)
#define AFX_CATLROTARYPROP_H__5117E821_F91F_11D3_B4E3_AB4A67B50436__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// cAtlRotaryProp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// cAtlRotaryProp dialog

class cAtlRotaryProp : public CDialog
{
// Construction
public:
	cAtlRotaryProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(cAtlRotaryProp)
	enum { IDD = IDD_ATLROTARYPROP };
	BOOL	m_bTickMarks;
	short	m_sNoTicksMarks;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(cAtlRotaryProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(cAtlRotaryProp)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CATLROTARYPROP_H__5117E821_F91F_11D3_B4E3_AB4A67B50436__INCLUDED_)
