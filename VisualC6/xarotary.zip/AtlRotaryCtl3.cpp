// AtlRotaryCtl3.cpp : Implementation of CAtlRotaryCtl3

#include "stdafx.h"
#include "Atlrotary3.h"
#include "AtlRotaryCtl3.h"

/////////////////////////////////////////////////////////////////////////////
// CAtlRotaryCtl3


STDMETHODIMP CAtlRotaryCtl3::get_TickNo(short *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    *pVal = m_sNumTicks;
	return S_OK;
}

STDMETHODIMP CAtlRotaryCtl3::put_TickNo(short newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
    m_sNumTicks = newVal;
	return S_OK;
}

STDMETHODIMP CAtlRotaryCtl3::get_EnableTicks(BOOL *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here
	*pVal = m_bTicks;
	return S_OK;
}

STDMETHODIMP CAtlRotaryCtl3::put_EnableTicks(BOOL newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	// TODO: Add your implementation code here

	m_bTicks = newVal;
	return S_OK;
}
