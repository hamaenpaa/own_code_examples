#ifndef _ATLROTARY3CP_H_
#define _ATLROTARY3CP_H_

template <class T>
class CProxy_IAtlRotaryCtl3Events : public IConnectionPointImpl<T, &DIID__IAtlRotaryCtl3Events, CComDynamicUnkArray>
{
	//Warning this class may be recreated by the wizard.
public:
};
#endif