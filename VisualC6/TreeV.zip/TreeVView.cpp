// TreeVView.cpp : implementation of the CTreeVView class
//

#include "stdafx.h"
#include "TreeV.h"

#include "TreeVDoc.h"
#include "TreeVView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeVView

IMPLEMENT_DYNCREATE(CTreeVView, CTreeView)

BEGIN_MESSAGE_MAP(CTreeVView, CTreeView)
	//{{AFX_MSG_MAP(CTreeVView)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	ON_NOTIFY_REFLECT(TVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(TVN_ENDLABELEDIT, OnEndlabeledit)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeVView construction/destruction

CTreeVView::CTreeVView()
{
	// TODO: add construction code here

}

CTreeVView::~CTreeVView()
{
}

BOOL CTreeVView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CTreeView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTreeVView drawing

void CTreeVView::OnDraw(CDC* pDC)
{
	CTreeVDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTreeVView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();
	CTreeCtrl& tree = GetTreeCtrl();
	HTREEITEM hAnimals = tree.InsertItem("Animals");
	HTREEITEM hVerts = tree.InsertItem("Vertibrates",hAnimals);
	tree.InsertItem("Whales",hVerts,TVI_SORT);
	tree.InsertItem("Dogs",hVerts,TVI_SORT);
	tree.InsertItem("Humans",hVerts,TVI_SORT);
	HTREEITEM hInverts = tree.InsertItem("Invertibrates",hAnimals);
	tree.InsertItem("JellyFish",hInverts,TVI_SORT);
	tree.InsertItem("Worms",hInverts,TVI_SORT);
	tree.InsertItem("Snails",hInverts,TVI_SORT);
	HTREEITEM hPlants = tree.InsertItem("Plants",TVI_ROOT,hAnimals);
	HTREEITEM hFruit = tree.InsertItem("Fruit",hPlants);
	tree.InsertItem("Apples",hFruit,TVI_SORT);
	tree.InsertItem("Plums",hFruit,TVI_SORT);
	tree.InsertItem("Pears",hFruit,TVI_SORT);
	HTREEITEM hCereal = tree.InsertItem("Cereal",hPlants);
	tree.InsertItem("Wheat",hCereal,TVI_SORT);
	tree.InsertItem("Rye",hCereal,TVI_SORT);
	tree.InsertItem("Rice",hCereal,TVI_SORT);
	DWORD dwStyle = GetWindowLong(GetTreeCtrl().GetSafeHwnd(),GWL_STYLE);
	dwStyle |= TVS_HASLINES + TVS_HASBUTTONS + TVS_LINESATROOT + TVS_EDITLABELS;
	SetWindowLong(GetTreeCtrl().GetSafeHwnd(),GWL_STYLE, dwStyle);
	SetRedraw(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// CTreeVView printing

BOOL CTreeVView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTreeVView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTreeVView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTreeVView diagnostics

#ifdef _DEBUG
void CTreeVView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTreeVView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CTreeVDoc* CTreeVView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTreeVDoc)));
	return (CTreeVDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTreeVView message handlers

void CTreeVView::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	
	HTREEITEM hSelected = GetTreeCtrl().GetSelectedItem();
	if (hSelected >= 0) 
	{
		CString strSelected = GetTreeCtrl().GetItemText(hSelected);
		GetDocument()->SetTitle(strSelected);
	}
	*pResult = 0;
}

void CTreeVView::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	
	GetTreeCtrl().GetEditControl()->LimitText(20);
	*pResult = 0;
}

void CTreeVView::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	CString strText;
	GetTreeCtrl().GetEditControl()->GetWindowText(strText);
	if (strText.GetLength()>0)
	{
		HTREEITEM hSelected = pTVDispInfo->item.hItem;
		GetTreeCtrl().SetItemText(hSelected,strText);
	}
	*pResult = 0;
}
