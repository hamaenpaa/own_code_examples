/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Mar 15 11:22:29 2000
 */
/* Compiler settings for D:\iio222\Esimerkit\DCOM_Client_Server\TheServer\TheServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __TheServer_h__
#define __TheServer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ITheServerComObject_FWD_DEFINED__
#define __ITheServerComObject_FWD_DEFINED__
typedef interface ITheServerComObject ITheServerComObject;
#endif 	/* __ITheServerComObject_FWD_DEFINED__ */


#ifndef ___ITheServerComObjectEvents_FWD_DEFINED__
#define ___ITheServerComObjectEvents_FWD_DEFINED__
typedef interface _ITheServerComObjectEvents _ITheServerComObjectEvents;
#endif 	/* ___ITheServerComObjectEvents_FWD_DEFINED__ */


#ifndef __TheServerComObject_FWD_DEFINED__
#define __TheServerComObject_FWD_DEFINED__

#ifdef __cplusplus
typedef class TheServerComObject TheServerComObject;
#else
typedef struct TheServerComObject TheServerComObject;
#endif /* __cplusplus */

#endif 	/* __TheServerComObject_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ITheServerComObject_INTERFACE_DEFINED__
#define __ITheServerComObject_INTERFACE_DEFINED__

/* interface ITheServerComObject */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ITheServerComObject;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("575AB60F-FA3E-11D3-8F29-00A024A7C6AA")
    ITheServerComObject : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE HelloWorld( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AcceptNewValue( 
            /* [in] */ long lNewValue,
            /* [retval][out] */ long __RPC_FAR *lpFormerValue) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITheServerComObjectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITheServerComObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITheServerComObject __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITheServerComObject __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITheServerComObject __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITheServerComObject __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITheServerComObject __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITheServerComObject __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *HelloWorld )( 
            ITheServerComObject __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AcceptNewValue )( 
            ITheServerComObject __RPC_FAR * This,
            /* [in] */ long lNewValue,
            /* [retval][out] */ long __RPC_FAR *lpFormerValue);
        
        END_INTERFACE
    } ITheServerComObjectVtbl;

    interface ITheServerComObject
    {
        CONST_VTBL struct ITheServerComObjectVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITheServerComObject_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITheServerComObject_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITheServerComObject_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ITheServerComObject_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ITheServerComObject_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ITheServerComObject_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ITheServerComObject_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ITheServerComObject_HelloWorld(This)	\
    (This)->lpVtbl -> HelloWorld(This)

#define ITheServerComObject_AcceptNewValue(This,lNewValue,lpFormerValue)	\
    (This)->lpVtbl -> AcceptNewValue(This,lNewValue,lpFormerValue)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ITheServerComObject_HelloWorld_Proxy( 
    ITheServerComObject __RPC_FAR * This);


void __RPC_STUB ITheServerComObject_HelloWorld_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ITheServerComObject_AcceptNewValue_Proxy( 
    ITheServerComObject __RPC_FAR * This,
    /* [in] */ long lNewValue,
    /* [retval][out] */ long __RPC_FAR *lpFormerValue);


void __RPC_STUB ITheServerComObject_AcceptNewValue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ITheServerComObject_INTERFACE_DEFINED__ */



#ifndef __THESERVERLib_LIBRARY_DEFINED__
#define __THESERVERLib_LIBRARY_DEFINED__

/* library THESERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_THESERVERLib;

#ifndef ___ITheServerComObjectEvents_DISPINTERFACE_DEFINED__
#define ___ITheServerComObjectEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ITheServerComObjectEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__ITheServerComObjectEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("575AB611-FA3E-11D3-8F29-00A024A7C6AA")
    _ITheServerComObjectEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ITheServerComObjectEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _ITheServerComObjectEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _ITheServerComObjectEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _ITheServerComObjectEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _ITheServerComObjectEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _ITheServerComObjectEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _ITheServerComObjectEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _ITheServerComObjectEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _ITheServerComObjectEventsVtbl;

    interface _ITheServerComObjectEvents
    {
        CONST_VTBL struct _ITheServerComObjectEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ITheServerComObjectEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _ITheServerComObjectEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _ITheServerComObjectEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _ITheServerComObjectEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _ITheServerComObjectEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _ITheServerComObjectEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _ITheServerComObjectEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ITheServerComObjectEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_TheServerComObject;

#ifdef __cplusplus

class DECLSPEC_UUID("575AB610-FA3E-11D3-8F29-00A024A7C6AA")
TheServerComObject;
#endif
#endif /* __THESERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
