// TheServerComObject.cpp : Implementation of CTheServerComObject
#include "stdafx.h"
#include "TheServer.h"
#include "TheServerComObject.h"

/////////////////////////////////////////////////////////////////////////////
// CTheServerComObject

CTheServerComObject::CTheServerComObject()
{
  m_pUnkMarshaler = NULL;
  m_lCurrentValue = 0;
}


STDMETHODIMP CTheServerComObject::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITheServerComObject
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CTheServerComObject::HelloWorld()
{
	return S_OK;
}

STDMETHODIMP CTheServerComObject::AcceptNewValue(long lNewValue, long *lpFormerValue)
{
	// TODO: Add your implementation code here
    if (lNewValue > 0 && lNewValue <= 2)
    {
       *lpFormerValue = m_lCurrentValue;
       m_lCurrentValue = lNewValue;
	   return S_OK;
    }
	return S_FALSE;
}
