// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "ThePusher.h"
#include "DlgProxy.h"
#include "ThePusherDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThePusherDlgAutoProxy

IMPLEMENT_DYNCREATE(CThePusherDlgAutoProxy, CCmdTarget)

CThePusherDlgAutoProxy::CThePusherDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CThePusherDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CThePusherDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CThePusherDlgAutoProxy::~CThePusherDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CThePusherDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CThePusherDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CThePusherDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CThePusherDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CThePusherDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IThePusher to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {575AB618-FA3E-11D3-8F29-00A024A7C6AA}
static const IID IID_IThePusher =
{ 0x575ab618, 0xfa3e, 0x11d3, { 0x8f, 0x29, 0x0, 0xa0, 0x24, 0xa7, 0xc6, 0xaa } };

BEGIN_INTERFACE_MAP(CThePusherDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CThePusherDlgAutoProxy, IID_IThePusher, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {575AB616-FA3E-11D3-8F29-00A024A7C6AA}
IMPLEMENT_OLECREATE2(CThePusherDlgAutoProxy, "ThePusher.Application", 0x575ab616, 0xfa3e, 0x11d3, 0x8f, 0x29, 0x0, 0xa0, 0x24, 0xa7, 0xc6, 0xaa)

/////////////////////////////////////////////////////////////////////////////
// CThePusherDlgAutoProxy message handlers
