	
// TheServerComObject.h : Declaration of the CTheServerComObject

#ifndef __THESERVERCOMOBJECT_H_
#define __THESERVERCOMOBJECT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTheServerComObject
class ATL_NO_VTABLE CTheServerComObject : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CTheServerComObject, &CLSID_TheServerComObject>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CTheServerComObject>,
	public IDispatchImpl<ITheServerComObject, &IID_ITheServerComObject, &LIBID_THESERVERLib>
{
public:
	CTheServerComObject();

DECLARE_REGISTRY_RESOURCEID(IDR_THESERVERCOMOBJECT)
DECLARE_GET_CONTROLLING_UNKNOWN()

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CTheServerComObject)
	COM_INTERFACE_ENTRY(ITheServerComObject)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_AGGREGATE(IID_IMarshal, m_pUnkMarshaler.p)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CTheServerComObject)
END_CONNECTION_POINT_MAP()


	HRESULT FinalConstruct()
	{
		return CoCreateFreeThreadedMarshaler(
			GetControllingUnknown(), &m_pUnkMarshaler.p);
	}

	void FinalRelease()
	{
		m_pUnkMarshaler.Release();
	}

	CComPtr<IUnknown> m_pUnkMarshaler;

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ITheServerComObject
public:
	STDMETHOD(AcceptNewValue)(/*[in]*/ long lNewValue, /*[out, retval]*/ long *lpFormerValue);
	STDMETHOD(HelloWorld) ();
private:
	long m_lCurrentValue;
};

#endif //__THESERVERCOMOBJECT_H_
