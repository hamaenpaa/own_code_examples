/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Mar 15 11:22:29 2000
 */
/* Compiler settings for D:\iio222\Esimerkit\DCOM_Client_Server\TheServer\TheServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ITheServerComObject = {0x575AB60F,0xFA3E,0x11D3,{0x8F,0x29,0x00,0xA0,0x24,0xA7,0xC6,0xAA}};


const IID LIBID_THESERVERLib = {0x575AB603,0xFA3E,0x11D3,{0x8F,0x29,0x00,0xA0,0x24,0xA7,0xC6,0xAA}};


const IID DIID__ITheServerComObjectEvents = {0x575AB611,0xFA3E,0x11D3,{0x8F,0x29,0x00,0xA0,0x24,0xA7,0xC6,0xAA}};


const CLSID CLSID_TheServerComObject = {0x575AB610,0xFA3E,0x11D3,{0x8F,0x29,0x00,0xA0,0x24,0xA7,0xC6,0xAA}};


#ifdef __cplusplus
}
#endif

