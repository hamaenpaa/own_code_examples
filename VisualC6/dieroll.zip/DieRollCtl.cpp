// DieRollCtl.cpp : Implementation of the CDieRollCtrl ActiveX Control class.

#include "stdafx.h"
#include "DieRoll.h"
#include "DieRollCtl.h"
#include "DieRollPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CDieRollCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDieRollCtrl, COleControl)
	//{{AFX_MSG_MAP(CDieRollCtrl)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_EDIT, OnEdit)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CDieRollCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CDieRollCtrl)
	DISP_PROPERTY_NOTIFY(CDieRollCtrl, "Number", m_number, OnNumberChanged, VT_I2)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CDieRollCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CDieRollCtrl, COleControl)
	//{{AFX_EVENT_MAP(CDieRollCtrl)
	EVENT_STOCK_CLICK()
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CDieRollCtrl, 1)
	PROPPAGEID(CDieRollPropPage::guid)
END_PROPPAGEIDS(CDieRollCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDieRollCtrl, "DIEROLL.DieRollCtrl.1",
	0x781fdf19, 0x1e92, 0x11d4, 0xb4, 0xe3, 0xb0, 0x6d, 0x9d, 0xcd, 0x6, 0x36)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CDieRollCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DDieRoll =
		{ 0x781fdf17, 0x1e92, 0x11d4, { 0xb4, 0xe3, 0xb0, 0x6d, 0x9d, 0xcd, 0x6, 0x36 } };
const IID BASED_CODE IID_DDieRollEvents =
		{ 0x781fdf18, 0x1e92, 0x11d4, { 0xb4, 0xe3, 0xb0, 0x6d, 0x9d, 0xcd, 0x6, 0x36 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwDieRollOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CDieRollCtrl, IDS_DIEROLL, _dwDieRollOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::CDieRollCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CDieRollCtrl

BOOL CDieRollCtrl::CDieRollCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegInsertable | afxRegApartmentThreading to afxRegInsertable.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_DIEROLL,
			IDB_DIEROLL,
			afxRegInsertable | afxRegApartmentThreading,
			_dwDieRollOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::CDieRollCtrl - Constructor

CDieRollCtrl::CDieRollCtrl()
{
	InitializeIIDs(&IID_DDieRoll, &IID_DDieRollEvents);
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::~CDieRollCtrl - Destructor

CDieRollCtrl::~CDieRollCtrl()
{
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::OnDraw - Drawing function

void CDieRollCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	pdc->FillRect(rcBounds,CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
/*
	CString val;
	val.Format("%d", m_number );
	pdc->TextOut(0,0,ETO_OPAQUE, rcBounds, val, NULL );
*/
	int Xunit = rcBounds.Width()  /16;
	int Yunit = rcBounds.Height() /16;
	int Xleft = rcBounds.Width()  %16;
	int Yleft = rcBounds.Height() %16;

	int Top = rcBounds.top + Yleft/2;
	int Left = rcBounds.left + Xleft/2;
	CBrush Black;
	Black.CreateSolidBrush(RGB(0x00,0x00,0x00));
	CBrush* savebrush = pdc->SelectObject(&Black);
	switch(m_number)
	{
		case 1 : 
			pdc->Ellipse(Left+6*Xunit , Top+6*Yunit  ,Left+10*Xunit, Top+10*Yunit); // center
			break;
		case 2 : 
			pdc->Ellipse(Left+Xunit   , Top+Yunit    ,Left+5*Xunit , Top+5*Yunit); // upper left
			pdc->Ellipse(Left+11*Xunit, Top+11*Yunit ,Left+15*Xunit, Top+15*Yunit); // lower right
			break;
		case 3 : 
			pdc->Ellipse(Left+Xunit   , Top+Yunit    ,Left+5*Xunit , Top+5*Yunit); // upper left
			pdc->Ellipse(Left+6*Xunit , Top+6*Yunit  ,Left+10*Xunit, Top+10*Yunit); // center
			pdc->Ellipse(Left+11*Xunit, Top+11*Yunit ,Left+15*Xunit, Top+15*Yunit); // lower right
			break;
		case 4 : 
			pdc->Ellipse(Left+Xunit   , Top+Yunit    ,Left+5*Xunit , Top+5*Yunit); // upper left
			pdc->Ellipse(Left+11*Xunit, Top+Yunit    ,Left+15*Xunit, Top+5*Yunit); // upper right
			pdc->Ellipse(Left+Xunit   , Top+11*Yunit ,Left+5*Xunit , Top+15*Yunit); // lower left
			pdc->Ellipse(Left+11*Xunit, Top+11*Yunit ,Left+15*Xunit, Top+15*Yunit); // lower right
			break;
		case 5 : 
			pdc->Ellipse(Left+Xunit   , Top+Yunit    ,Left+5*Xunit , Top+5*Yunit); // upper left
			pdc->Ellipse(Left+11*Xunit, Top+Yunit    ,Left+15*Xunit, Top+5*Yunit); // upper right
			pdc->Ellipse(Left+6*Xunit , Top+6*Yunit  ,Left+10*Xunit, Top+10*Yunit); // center
			pdc->Ellipse(Left+Xunit   , Top+11*Yunit ,Left+5*Xunit , Top+15*Yunit); // lower left
			pdc->Ellipse(Left+11*Xunit, Top+11*Yunit ,Left+15*Xunit, Top+15*Yunit); // lower right
			break;
		case 6 : 
			pdc->Ellipse(Left+Xunit   , Top+Yunit    ,Left+5*Xunit , Top+5*Yunit); // upper left
			pdc->Ellipse(Left+11*Xunit, Top+Yunit    ,Left+15*Xunit, Top+5*Yunit); // upper right
			pdc->Ellipse(Left+Xunit   , Top+6*Yunit  ,Left+5*Xunit , Top+10*Yunit); // center left
			pdc->Ellipse(Left+11*Xunit, Top+6*Yunit  ,Left+15*Xunit, Top+10*Yunit); // center right
			pdc->Ellipse(Left+Xunit   , Top+11*Yunit ,Left+5*Xunit , Top+15*Yunit); // lower left
			pdc->Ellipse(Left+11*Xunit, Top+11*Yunit ,Left+15*Xunit, Top+15*Yunit); // lower right
			break;
	}
	pdc->SelectObject(savebrush);
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::DoPropExchange - Persistence support

void CDieRollCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);
	srand( (unsigned)time (NULL) );
	PX_Short( pPX, "Number", m_number, Roll() );
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::OnResetState - Reset control to default state

void CDieRollCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl::AboutBox - Display an "About" box to the user

void CDieRollCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_DIEROLL);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl message handlers

void CDieRollCtrl::OnNumberChanged() 
{
	SetModifiedFlag();
}

void CDieRollCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_number = Roll();
	InvalidateControl();
	COleControl::OnLButtonDown(nFlags, point);
}

short CDieRollCtrl::Roll()
{
	double number = rand();
	number /= RAND_MAX + 1;
	number *= 6;
	return (short)number + 1;
}
