#if !defined(AFX_DIEROLL_H__781FDF1F_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_)
#define AFX_DIEROLL_H__781FDF1F_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// DieRoll.h : main header file for DIEROLL.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDieRollApp : See DieRoll.cpp for implementation.

class CDieRollApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIEROLL_H__781FDF1F_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED)
