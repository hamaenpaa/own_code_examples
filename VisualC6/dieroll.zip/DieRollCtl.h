#if !defined(AFX_DIEROLLCTL_H__781FDF27_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_)
#define AFX_DIEROLLCTL_H__781FDF27_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// DieRollCtl.h : Declaration of the CDieRollCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CDieRollCtrl : See DieRollCtl.cpp for implementation.

class CDieRollCtrl : public COleControl
{
	DECLARE_DYNCREATE(CDieRollCtrl)

// Constructor
public:
	CDieRollCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDieRollCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CDieRollCtrl();

	DECLARE_OLECREATE_EX(CDieRollCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CDieRollCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CDieRollCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CDieRollCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CDieRollCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CDieRollCtrl)
	short m_number;
	afx_msg void OnNumberChanged();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CDieRollCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	short Roll();
	enum {
	//{{AFX_DISP_ID(CDieRollCtrl)
	dispidNumber = 1L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIEROLLCTL_H__781FDF27_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED)
