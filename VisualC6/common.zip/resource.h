//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Common.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_PROGRESSBAR                 101
#define IDC_TRACKBAR                    102
#define IDC_BUDDYEDIT                   103
#define IDC_UPDOWN                      104
#define IDC_LISTVIEW                    105
#define IDC_LISTVIEW_SMALL              106
#define IDC_LISTVIEW_LARGE              107
#define IDC_LISTVIEW_LIST               108
#define IDC_LISTVIEW_REPORT             109
#define IDC_RICHEDIT_ULINE              110
#define IDC_RICHEDIT_LEFT               111
#define IDC_RICHEDIT_CENTER             112
#define IDC_RICHEDIT_RIGHT              113
#define IDC_IPADDRESS                   114
#define IDC_DATE                        115
#define IDC_MONTH                       116
#define IDC_RICHEDIT                    117
#define IDC_TREEVIEW                    118
#define IDR_MAINFRAME                   128
#define IDR_COMMONTYPE                  129
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDI_ICON5                       134

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           119
#endif
#endif
