// CntrItem.h : interface of the CRichVCntrItem class
//

#if !defined(AFX_CNTRITEM_H__781FDEB7_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_)
#define AFX_CNTRITEM_H__781FDEB7_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRichVDoc;
class CRichVView;

class CRichVCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CRichVCntrItem)

// Constructors
public:
	CRichVCntrItem(REOBJECT* preo = NULL, CRichVDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CRichVDoc* GetDocument()
		{ return (CRichVDoc*)CRichEditCntrItem::GetDocument(); }
	CRichVView* GetActiveView()
		{ return (CRichVView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRichVCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CRichVCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__781FDEB7_1E92_11D4_B4E3_B06D9DCD0636__INCLUDED_)
