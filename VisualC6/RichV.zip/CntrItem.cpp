// CntrItem.cpp : implementation of the CRichVCntrItem class
//

#include "stdafx.h"
#include "RichV.h"

#include "RichVDoc.h"
#include "RichVView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRichVCntrItem implementation

IMPLEMENT_SERIAL(CRichVCntrItem, CRichEditCntrItem, 0)

CRichVCntrItem::CRichVCntrItem(REOBJECT* preo, CRichVDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CRichVCntrItem::~CRichVCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CRichVCntrItem diagnostics

#ifdef _DEBUG
void CRichVCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CRichVCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
