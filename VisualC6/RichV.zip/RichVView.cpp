// RichVView.cpp : implementation of the CRichVView class
//

#include "stdafx.h"
#include "RichV.h"

#include "RichVDoc.h"
#include "CntrItem.h"
#include "RichVView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRichVView

IMPLEMENT_DYNCREATE(CRichVView, CRichEditView)

BEGIN_MESSAGE_MAP(CRichVView, CRichEditView)
	//{{AFX_MSG_MAP(CRichVView)
	ON_WM_DESTROY()
	ON_COMMAND(ID_ALIGNCENTER, OnAligncenter)
	ON_COMMAND(ID_ALIGNLEFT, OnAlignleft)
	ON_COMMAND(ID_ALIGNRIGHT, OnAlignright)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRichEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRichVView construction/destruction

CRichVView::CRichVView()
{
	// TODO: add construction code here

}

CRichVView::~CRichVView()
{
}

BOOL CRichVView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CRichVView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();


	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

/////////////////////////////////////////////////////////////////////////////
// CRichVView printing

BOOL CRichVView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CRichVView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   CRichEditView::OnDestroy();
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
}


/////////////////////////////////////////////////////////////////////////////
// CRichVView diagnostics

#ifdef _DEBUG
void CRichVView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CRichVView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CRichVDoc* CRichVView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRichVDoc)));
	return (CRichVDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRichVView message handlers

void CRichVView::OnAligncenter() 
{
	PARAFORMAT pf;
	pf.dwMask = PFM_ALIGNMENT;
	pf.wAlignment = PFA_CENTER;
	SetParaFormat(pf);
}

void CRichVView::OnAlignleft() 
{
	PARAFORMAT pf;
	pf.dwMask = PFM_ALIGNMENT;
	pf.wAlignment = PFA_LEFT;
	SetParaFormat(pf);
}

void CRichVView::OnAlignright() 
{
	PARAFORMAT pf;
	pf.dwMask = PFM_ALIGNMENT;
	pf.wAlignment = PFA_RIGHT;
	SetParaFormat(pf);
}
