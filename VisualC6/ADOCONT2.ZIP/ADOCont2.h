// ADOCont2.h : main header file for the ADOCONT2 application
//

#if !defined(AFX_ADOCONT2_H__473B52F6_E3FA_11D3_A899_A9D5BDB87019__INCLUDED_)
#define AFX_ADOCONT2_H__473B52F6_E3FA_11D3_A899_A9D5BDB87019__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CADOCont2App:
// See ADOCont2.cpp for the implementation of this class
//

class CADOCont2App : public CWinApp
{
public:
	CADOCont2App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADOCont2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CADOCont2App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADOCONT2_H__473B52F6_E3FA_11D3_A899_A9D5BDB87019__INCLUDED_)
