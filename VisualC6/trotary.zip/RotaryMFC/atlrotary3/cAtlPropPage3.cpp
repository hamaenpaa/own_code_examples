// cAtlPropPage3.cpp : Implementation of CcAtlPropPage3
#include "stdafx.h"
#include "Atlrotary3.h"
#include "cAtlPropPage3.h"

/////////////////////////////////////////////////////////////////////////////
// CcAtlPropPage3

