// cAtlRotaryProp.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "cAtlRotaryProp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// cAtlRotaryProp dialog


cAtlRotaryProp::cAtlRotaryProp(CWnd* pParent /*=NULL*/)
	: CDialog(cAtlRotaryProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(cAtlRotaryProp)
	m_bEnableTicks = FALSE;
	m_sNoTicks = 0;
	//}}AFX_DATA_INIT
}


void cAtlRotaryProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(cAtlRotaryProp)
	DDX_Check(pDX, IDC_ENABLETICKS, m_bEnableTicks);
	DDX_Text(pDX, IDC_NOTICKS, m_sNoTicks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(cAtlRotaryProp, CDialog)
	//{{AFX_MSG_MAP(cAtlRotaryProp)
	ON_BN_CLICKED(IDC_ENABLETICKS, OnEnableticks)
	ON_EN_CHANGE(IDC_NOTICKS, OnChangeNoticks)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// cAtlRotaryProp message handlers

void cAtlRotaryProp::OnEnableticks() 
{
	// TODO: Add your control notification handler code here
    SetDirty();
}

void cAtlRotaryProp::OnChangeNoticks() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
    SetDirty();
}
