// AtlRotaryCtl3.h : Declaration of the CAtlRotaryCtl3

#ifndef __ATLROTARYCTL3_H_
#define __ATLROTARYCTL3_H_


#include "resource.h"       // main symbols
#include <atlctl.h>
#include <math.h>
#include "atlrotary3CP.h"

/////////////////////////////////////////////////////////////////////////////
// CAtlRotaryCtl3
class ATL_NO_VTABLE CAtlRotaryCtl3 : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CAtlRotaryCtl3, IAtlRotaryCtl3, &IID_IAtlRotaryCtl3, &LIBID_ATLROTARY3Lib>,
	public CComControl<CAtlRotaryCtl3>,
	public IPersistStreamInitImpl<CAtlRotaryCtl3>,
	public IOleControlImpl<CAtlRotaryCtl3>,
	public IOleObjectImpl<CAtlRotaryCtl3>,
	public IOleInPlaceActiveObjectImpl<CAtlRotaryCtl3>,
	public IViewObjectExImpl<CAtlRotaryCtl3>,
	public IOleInPlaceObjectWindowlessImpl<CAtlRotaryCtl3>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CAtlRotaryCtl3>,
	public IPersistStorageImpl<CAtlRotaryCtl3>,
	public ISpecifyPropertyPagesImpl<CAtlRotaryCtl3>,
	public IQuickActivateImpl<CAtlRotaryCtl3>,
	public IDataObjectImpl<CAtlRotaryCtl3>,
	public IProvideClassInfo2Impl<&CLSID_AtlRotaryCtl3, &DIID__IAtlRotaryCtl3Events, &LIBID_ATLROTARY3Lib>,
	public IPropertyNotifySinkCP<CAtlRotaryCtl3>,
	public CComCoClass<CAtlRotaryCtl3, &CLSID_AtlRotaryCtl3>,
	public CProxy_IAtlRotaryCtl3Events< CAtlRotaryCtl3 >
{
public:
	CAtlRotaryCtl3()
	{
		m_sNumTicks = 12;
		m_bTicks = TRUE;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ATLROTARYCTL3)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAtlRotaryCtl3)
	COM_INTERFACE_ENTRY(IAtlRotaryCtl3)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_PROP_MAP(CAtlRotaryCtl3)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("BackColor", DISPID_BACKCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("ForeColor", DISPID_FORECOLOR, CLSID_StockColorPage)
	PROP_ENTRY("EnableTicks", 1, CLSID_cAtlPropPage3)
	PROP_ENTRY("TickNo", 1, CLSID_cAtlPropPage3)
	// Example entries
	// PROP_ENTRY("Property Description", dispid, clsid)
	// PROP_PAGE(CLSID_StockColorPage)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CAtlRotaryCtl3)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
	CONNECTION_POINT_ENTRY(IID__IAtlRotaryCtl3Events)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CAtlRotaryCtl3)
	CHAIN_MSG_MAP(CComControl<CAtlRotaryCtl3>)
	DEFAULT_REFLECTION_HANDLER()
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid)
	{
		static const IID* arr[] = 
		{
			&IID_IAtlRotaryCtl3,
		};
		for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
		{
			if (InlineIsEqualGUID(*arr[i], riid))
				return S_OK;
		}
		return S_FALSE;
	}

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IAtlRotaryCtl3
public:
	STDMETHOD(get_EnableTicks)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_EnableTicks)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_TickNo)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_TickNo)(/*[in]*/ short newVal);

	HRESULT OnDraw(ATL_DRAWINFO& di)
	{
		RECT& rc = *(RECT*)di.prcBounds;
		CRect rcBounds = rc;
		HDC hdc = di.hdcDraw;
		COLORREF colBack;	// Background color (Stock property)
		COLORREF colFore;	// Foreground color (Custom property)
		COLORREF colFill;	// Fill color (Custom property)
		/* HBRUSH hBrushBack=NULL, hBrushFill=NULL, hBrushStock=NULL; */
		// Translate m_colBack into a COLORREF type
		OleTranslateColor(m_clrBackColor, NULL, &colBack);
		OleTranslateColor(m_clrForeColor, NULL, &colFore);
		OleTranslateColor(m_clrFillColor, NULL, &colFill);

		// ** Set up the background and foreground brushes
		HBRUSH ForeGnd = CreateSolidBrush(m_clrForeColor);
		HBRUSH BackGnd = CreateSolidBrush(m_clrBackColor);
/*		CBrush brForeGnd(m_clrForeColor);
		CBrush brBackGnd(m_clrBackColor); 
        HBRUSH ForeGnd = HBRUSH(brForeGnd);
		HBRUSH BackGnd = HBRUSH(brBackGnd);
*/
		// ** Draw the control background
		FillRect(hdc,rcBounds,BackGnd);

		HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc,ForeGnd);

		// ** Calculate the relative positions and mid point
		CPoint ptRelative = m_ptClicked - rcBounds.TopLeft();
		CPoint ptMid(rcBounds.Width()/2,rcBounds.Height()/2);

		double dRadX = (double)ptMid.x * 0.9;
		double dRadY = (double)ptMid.y * 0.9;
		ptMid = ptMid + rcBounds.TopLeft();

		// ** Finf offset from the middle
		double dRelX = ptRelative.x - ptMid.x;
		double dRelY = ptRelative.y - ptMid.y;

		// ** Use trig to find the angle by T=O/A
		double dAngle = atan2(dRelY, dRelX);
		
		// ** Find a point on the radius of the knob
		int dXPos = ptMid.x + (int)(cos(dAngle) * dRadX);
		int dYPos = ptMid.y + (int)(sin(dAngle) * dRadY);

		// ** Set the notch point position
		CPoint ptKnob = CPoint(dXPos,dYPos);

		// ** Set a rect and draw the notch circle
		CRect rcPoint(ptKnob-CSize(4,4),CSize(8,8));
		Ellipse(hdc,rcPoint.left,rcPoint.top, rcPoint.right,rcPoint.bottom); // pdc ?
        
		// ** Draw the main rotary circle
		Ellipse(	hdc,ptMid.x-(int)dRadX,ptMid.y-(int)dRadY,
					ptMid.x+(int)dRadX,ptMid.y+(int)dRadY);
		// ** Draw a line from the center to the knotch
		MoveToEx(hdc,ptMid.x,ptMid.y,NULL); // pdc ?
		LineTo(hdc,ptKnob.x,ptKnob.y); // pdc ? 

		SelectObject(hdc,hOldBrush);
		m_dCurrentPosition = dAngle >= 0 ? 360-dAngle*57.2978 : -dAngle*57.2978;

		// ** Check if the ticks are enabled
		if (m_bTicks)
		{
			// ** Iterate in radians from -2*PI to +2*PI
			const double dPi = 3.14185;
			double r = -2.0*dPi;
			for (int i=0;i<m_sNumTicks;i++)
			{
				// ** Move to a position outside the main circle
				int nXPos = ptMid.x + (int)(cos(r) * dRadX * 1.05);
				int nYPos = ptMid.y + (int)(sin(r) * dRadY * 1.05);
				MoveToEx(hdc,nXPos,nYPos,NULL);

				// ** Draw a line even further out for a tick mark
				nXPos = ptMid.x + (int)(cos(r) * dRadX * 1.15);
				nYPos = ptMid.y + (int)(sin(r) * dRadY * 1.15);
				LineTo(hdc,nXPos,nYPos);

				// ** Increment the angle
				r += dPi / (m_sNumTicks/2.0);
			}
		}
		
		return S_OK;
	}
	OLE_COLOR m_clrBackColor;
	OLE_COLOR m_clrForeColor;
	short m_sNumTicks;
	BOOL m_bTicks;
	double m_dCurrentPosition;
	CPoint m_ptClicked;
	LRESULT OnLButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// TODO : Add Code for message handler. Call DefWindowProc if necessary.
		WORD xPos = LOWORD(lParam);  // horizontal position of cursor
		WORD yPos = HIWORD(lParam);  // vertical position of cursor
        m_ptClicked.x = xPos;
		m_ptClicked.y = yPos;
		Invalidate();
		Fire_Click_In(xPos, yPos); 
		return 0;
	}
};

#endif //__ATLROTARYCTL3_H_
