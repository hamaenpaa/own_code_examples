//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by atlrotary3.rc
//
#define IDS_PROJNAME                    100
#define IDB_ATLROTARYCTL3               102
#define IDR_ATLROTARYCTL3               103
#define IDS_TITLEcAtlPropPage3          104
#define IDS_HELPFILEcAtlPropPage3       105
#define IDS_DOCSTRINGcAtlPropPage3      106
#define IDR_CATLPROPPAGE3               107
#define IDD_CATLPROPPAGE3               108
#define IDC_ENABLETICKS                 202
#define IDC_NOTICKS                     203

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         208
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
